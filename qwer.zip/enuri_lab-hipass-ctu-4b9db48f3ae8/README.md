# HIPASS-CTU #

### Requirements ###

* Gradle 6

  * Gradle Wrapper 가 포함 되어 있어서 반드시 사전에 설치 해야 할 필요는 없음(gradlew command 사용)

* JDK 8

### Test ###

* `build.gradle` 파일의 test 항목에 exclude line 이 주석 처리 되어 있으면 모든 test code 실행 가능

* include line 은 RestDocs 로 API 문서를 만들때 필요하므로 반드시 포함 
```
... more ...

test {
    useJUnitPlatform() {
        // RestDocs + Asciidoctor 실행을 위해 반드시 필요 
        include 'com/enuri/ctu/controller/CtuRestControllerTest'
        
        // 나머지 모든 테스트는 SKIP
        // 테스트 코드를 실행하고자 할때는 아래 line 을 주석 처리
        exclude '**'
    }
}

... more ...
```
* command

  * windows: `./gradlew.bat test`

  * linux/mac: `./gradlew test`

### Build ###

* command `./gradlew.bat build` or `./gradlew build`
* {project Directory}/build/lib/app.jar 파일 생성

### 로컬 실행 ###

* {project Directory}/build/lib/app.jar 파일을 적당한 위치로 옮긴 후
* command `java -jar app.jar`

### REST API Document ###

* http://배포IP:PORT/docs/index.html 접속
* 예) http://localhost:8080/docs/index.html

### 배포 ###

* TODO
