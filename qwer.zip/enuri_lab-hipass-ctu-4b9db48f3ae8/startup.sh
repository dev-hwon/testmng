#!/bin/sh

CID="$(basename $(cat /proc/1/cpuset))"
SHORTEN_CID=$(echo $CID | cut -c1-12)
HOST_NAME="$HOSTNAME-$SHORTEN_CID"

export HOSTNAME=$HOST_NAME
java -javaagent:/app/scouter/scouter.agent.jar -Dscouter.config=/app/scouter/scouter.conf -Dobj_name=$HOST_NAME -Djava.security.egd=file:/dev/./urandom -Duser.country=KR -Duser.language=ko -Duser.timezone=Asia/Seoul -jar /app/app.jar
