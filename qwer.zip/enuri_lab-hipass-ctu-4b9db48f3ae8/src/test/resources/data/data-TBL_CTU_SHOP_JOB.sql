insert into TBL_CTU_SHOP_JOB values (7861, 'Y', 'N', 'Y', 'Y', 'Y', 'Y', null);
insert into TBL_CTU_SHOP_JOB values (0, 'Y', 'N', 'N', 'N', 'Y', 'Y', null);
