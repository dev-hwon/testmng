drop all objects
