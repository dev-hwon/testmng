insert into TBL_SHOPLIST(SHOP_NO, SHOP_CODE, SHOP_NAME, URL) values (7886, 7861, '쿠팡', 'http://www.coupang.com/landingMulti.pang?sid=Enuri&src=1032035&spec=10305201&addtag=400&utm_source=EN&utm_medium=Enuri_PCS&utm_campaign=PC_EP&forceBypass=Y&synd_meta=ENURI&homeLanding=Y');
insert into TBL_SHOPLIST(SHOP_NO, SHOP_CODE, SHOP_NAME, URL) values (0, 0, '스마트스토어', 'SMART-STORE-TEST-URL');
