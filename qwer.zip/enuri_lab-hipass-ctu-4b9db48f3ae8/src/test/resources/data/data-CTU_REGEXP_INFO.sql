set mode Oracle;

insert into CTU_REGEXP_INFO values (25381, '로켓와우_가격', '<div class="prod-sale-price', '<span class="unit-price">', '<strong>(.*?)<span class="price-unit">원</span></strong></span><span class="unit-price">', 2, 1, 1, 7861, 23781, 1, 'admin_not_login', '58.234.199.10', '관리자_미로그인상태', CURRENT_DATE, 'admin_not_login', '58.234.199.10', '관리자_미로그인상태', CURRENT_DATE, null, null, null, null, 1, 'I5659407');
