set mode Oracle;

insert into CTU_PARSE_DIVIDE_INFO values (1, '판매가', 'NormalPrice', 1, 'ADMIN', 'ADMIN', CURRENT_DATE, null, null, null, null, null, null, 2);
