-- TB_CRWL_CONNECT_PROXY_LIST
insert into TB_CRWL_CONNECT_PROXY_LIST values (1, '255.255.255.255', '9999', 'TEST-ID', 'TEST-PW', 'TEST-COMPANY', 'EL', 10, 9, 1, 'Y', 'Y', now());
insert into TB_CRWL_CONNECT_PROXY_LIST values (2, '0.0.0.0', '9001', 'TEST-ID', 'TEST-PW', 'TEST-COMPANY', 'EL', 11, 10, 1, 'Y', 'Y', now());
