set mode Oracle;

insert into CTU_SHOP_DIVIDE_MAP values (14961, 23781, 1, 1, 'ADMIN', '관리자_미로그인상태', CURRENT_DATE, null, null, null, null, null, null);
