set mode Oracle;

create table if not exists TBL_SHOPLIST
(
    SHOP_NO	integer,
    SHOP_CODE	integer,
    SHOP_NAME	varchar(60),
    URL varchar(250)
    --- more ---
);
