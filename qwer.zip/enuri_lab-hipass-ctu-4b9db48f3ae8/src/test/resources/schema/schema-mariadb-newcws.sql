set mode MariaDB;

create table if not exists TB_CRWL_CONNECT_PROXY_LIST
(
    PROXY_SEQ           bigint auto_increment primary key,
    PROXY_IP            varchar(20)     null,
    PROXY_PORT          varchar(10)     null,
    PROXY_ID            varchar(100)    null,
    PROXY_PW            varchar(100)    null,
    PROXY_COMPANY_NM    varchar(100)    null,
    PROXY_COMPANY_CD    varchar(10)     null,
    USE_CNT             integer         DEFAULT 0   not null,
    SUCCESS_CNT         integer         DEFAULT 0   not null,
    FAIL_CNT            integer         DEFAULT 0   not null,
    USE_STATUS          varchar(1)      DEFAULT 'N' not null,
    PAUSE_STATUS        varchar(1)      DEFAULT 'P' not null,
    INT_DT              datetime        null
);

create table if not exists TB_CRWL_PROXY_DAILY_COUNT_LOG
(
    DATE_NO             varchar(50) not null,
    IP                  varchar(50) not null,
    SERVICE_TYPE        integer     not null,
    ACCESS_COUNT        integer     null,
    SUCCESS_COUNT       integer     default 0 null,
    SOFT_FAIL_COUNT     integer     default 0 null,
    HARD_FAIL_COUNT     integer     default 0 null,
    CPN_CD              varchar(10) null,
    PRIMARY KEY (DATE_NO, IP, SERVICE_TYPE)
);
