set mode MariaDB;

-- maria-ctu-log
create table if not exists CTU_FAIL_LOG
(
    LOG_SEQ      bigint auto_increment primary key,
    DEVICE       varchar(50)   null,
    SERVICE      varchar(50)   null,
    SHOP_CODE    varchar(50)   null,
    GOODS_CODE   varchar(50)   null,
    PL_NO        varchar(50)   null,
    URL          varchar(1000) null,
    CRAWLING_URL varchar(1000) null,
    TIME_VALUE   integer       null,
    ADD_DATE     datetime      null,
    SEND_DATE    datetime      null,
    SEND_ONLYME  datetime      null,
    FAIL_TYPE    integer        null
);

create table if not exists CTU_SUBSCRIBE_FAIL_LOG
(
    seq             bigint auto_increment primary key,
    modelno         integer     not null,
    goods_code      varchar(50) not null,
    shop_code       integer     not null,
    request_date    datetime    not null,
    response_date   datetime    not null
);

