set mode Oracle;

create table if not exists  CTU_GATHERING_INFO
(
    GTR_CODE            integer,
    GTR_NAME            varchar(1000),
    GTR_URL             varchar(1000),
    GTR_TIME_OUT        integer,
    GTR_LANG            varchar(100),
    CTU_DEVICE          varchar(50),
    CTU_SERVICE         varchar(50),
    SHOP_CODE           integer,
    STATUS              varchar(10),
    ADD_ID              varchar(50),
    ADD_IP              varchar(50),
    ADD_NAME            varchar(100),
    ADD_DATE            date,
    MOD_ID              varchar(50),
    MOD_IP              varchar(50),
    MOD_NAME            varchar(100),
    MOD_DATE            date,
    DEL_ID              varchar(50),
    DEL_IP              varchar(50),
    DEL_NAME            varchar(100),
    DEL_DATE            date,
    GTR_URL_REGEXP      varchar(1000),
    REGEXP_VER          integer,
    GTR_SHOP_CODE_REGEXP varchar(500),
    PRIMARY KEY (GTR_CODE)
);
