set mode Oracle;

create table if not exists CTU_HEADER_SET_INFO
(
    HEADER_CODE	        integer,
    HEADER_KEY	        varchar(400),
    HEADER_VALUE	    varchar(4000),
    HEADER_ORDER	    integer,
    SHOP_CODE	        integer,
    GTR_CODE	        integer,
    STATUS	            integer,
    ADD_ID	            varchar(50),
    ADD_IP	            varchar(50),
    ADD_NAME	        varchar(100),
    ADD_DATE	        date,
    MOD_ID	            varchar(50),
    MOD_IP	            varchar(50),
    MOD_NAME	        varchar(100),
    MOD_DATE	        date,
    DEL_ID	            varchar(50),
    DEL_IP	            varchar(50),
    DEL_NAME	        varchar(100),
    DEL_DATE	        date
);

