set mode Oracle;

create table if not exists TBL_CTU_SHOP_JOB
(
    SHOP_CODE	integer not null,
    PRICE_YN	char(1) null,
    CARD_PRICE_YN	char(1) null,
    DELIVERY_YN	char(1) default 'Y',
    COUPON_YN	char(1) default 'Y',
    MOBILE_YN	char(1) default 'Y',
    SOLD_YN	char(1) default 'Y',
    OPTION_YN	char(1) null
);

create table if not exists TBL_SHOPLIST
(
    SHOP_NO	integer,
    SHOP_CODE	integer,
    SHOP_NAME	varchar(60),
    URL varchar(250)
    --- more ---
);
