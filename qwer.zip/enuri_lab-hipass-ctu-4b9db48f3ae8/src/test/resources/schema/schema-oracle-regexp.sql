set mode Oracle;

create table if not exists CTU_REGEXP_INFO
(
    REGEXP_CODE	integer,
    REGEXP_NAME	varchar(300),
    REGEXP_START_STR	varchar(3000),
    REGEXP_END_STR	varchar(3000),
    REGEXP_ALL_STR	varchar(3000),
    REGEXP_RET_TYPE	varchar(10),
    REGEXP_DIVIS	varchar(10),
    REGEXP_ORDER	integer,
    SHOP_CODE	integer,
    GTR_CODE	integer,
    STATUS	varchar(10),
    ADD_ID	varchar(50),
    ADD_IP	varchar(50),
    ADD_NAME	varchar(100),
    ADD_DATE	DATE,
    MOD_ID	varchar(50),
    MOD_IP	varchar(50),
    MOD_NAME	varchar(100),
    MOD_DATE	DATE,
    DEL_ID	varchar(50),
    DEL_IP	varchar(50),
    DEL_NAME	varchar(100),
    DEL_DATE	DATE,
    REGEXP_GET_TYPE	varchar(10),
    REGEXP_TEST_CODE	varchar(100)
);

create table if not exists CTU_PARSE_DIVIDE_INFO
(
    DIVIDE_CODE	varchar(10),
    DIVIDE_NAME	varchar(200),
    DIVIDE_KEY_NAME	varchar(200),
    STATUS	varchar(10),
    ADD_ID	varchar(50),
    ADD_NAME	varchar(100),
    ADD_DATE	DATE,
    MOD_ID	varchar(50),
    MOD_NAME	varchar(100),
    MOD_DATE	DATE,
    DEL_ID	varchar(50),
    DEL_NAME	varchar(100),
    DEL_DATE	DATE,
    FUNC_CODE	varchar(50)
);

create table if not exists CTU_SHOP_DIVIDE_MAP
(
    MAP_NO	integer,
    GTR_CODE	integer,
    DIVIDE_CODE	varchar(50),
    STATUS	varchar(10),
    ADD_ID	varchar(50),
    ADD_NAME	varchar(100),
    ADD_DATE	DATE,
    MOD_ID	varchar(50),
    MOD_NAME	varchar(100),
    MOD_DATE	DATE,
    DEL_ID	varchar(50),
    DEL_NAME	varchar(100),
    DEL_DATE	DATE
);

create table if not exists TBL_CTU_SHOP_JOB
(
    SHOP_CODE	integer not null,
    PRICE_YN	char(1) null,
    CARD_PRICE_YN	char(1) null,
    DELIVERY_YN	char(1) default 'Y',
    COUPON_YN	char(1) default 'Y',
    MOBILE_YN	char(1) default 'Y',
    SOLD_YN	char(1) default 'Y',
    OPTION_YN	char(1) null
);

create alias if not exists TO_NUMBER for "com.enuri.ctu.config.test.H2CustomFunction.oracleToNumber"
