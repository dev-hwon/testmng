package com.enuri.ctu.dao;

import com.enuri.ctu.config.datasource.OracleMainDataSourceConfig;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dao.oracle.OracleGatheringDao;
import com.enuri.ctu.vo.GatheringInfoVO;
import org.junit.jupiter.api.DisplayName;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@MybatisTest
@Import(OracleMainDataSourceConfig.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class ElocGatheringMyBatisTest {

    @Autowired
    private OracleGatheringDao oracleGatheringDao;

//    @Test
    @DisplayName("fetchGatheringInfoForTest MyBatis 테스트")
    void fetchGatheringInfoForTest_test() {
        final long givenShopCode = 0L;
        final String givenCtuDevice = DeviceType.PC.getCode();
        final String givenCtuService = RequestService.HOMEPAGE.getCode();

        GatheringInfoVO actual = this.oracleGatheringDao.fetchGatheringInfoForTest(givenShopCode,
                givenCtuDevice, givenCtuService).get(0);

        assertAll(
                () -> assertNotNull(actual),
                () -> assertEquals(23801L, actual.getGtrCode()),
                () -> assertEquals(5000, actual.getGtrTimeOut()),
                () -> assertEquals("https://smartstore.naver.com/GTR_MALL_NAME/products/GTR_GOODS_CODE",
                        actual.getGtrUrl()),
                () -> assertNull(actual.getGtrUrlRegexp())
        );
    }
}
