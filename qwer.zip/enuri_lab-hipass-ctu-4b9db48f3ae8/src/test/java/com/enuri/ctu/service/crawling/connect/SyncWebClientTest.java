package com.enuri.ctu.service.crawling.connect;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import io.netty.channel.ChannelOption;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith({SpringExtension.class, MockitoExtension.class})
@SpringBootTest
class SyncWebClientTest {

    @Autowired
    private SyncWebClient syncWebClient;

    @Test
    void proxyWebClientTest() {
        final String url = "https://front.wemakeprice.com/product/2328588901";
        ProxyConnectInfoVO proxyInfo = mock(ProxyConnectInfoVO.class);
        CrawlingUnit unit = mock(CrawlingUnit.class);

        GatheringInfo gatheringInfo = GatheringInfo.builder()
                .gtrTimeOut(5000)
                .shopCode(ShopCode.WEMAP.getCode())
                .gtrCode(789L)
                .gtrUrl(url)
                .ctuService(RequestService.HOMEPAGE.getCode())
                .build();
        ReplacedUrlLink replacedUrlLink = ReplacedUrlLink.builder()
                .gtrGoodsCode("C482121409")
                .urlLink(url)
                .build();

        when(proxyInfo.getProxyIp()).thenReturn("211.254.68.22");
        when(proxyInfo.getProxyPort()).thenReturn("2022");
        when(proxyInfo.getProxyId()).thenReturn("jinroh");
        when(proxyInfo.getProxyPw()).thenReturn("shin2017");
        when(proxyInfo.getProxyCompanyCd()).thenReturn("EL");
        when(unit.getGatheringInfo()).thenReturn(gatheringInfo);
        when(unit.getReplacedUrlLink()).thenReturn(replacedUrlLink);
        when(unit.getParamCtuTest()).thenReturn(CtuTest.REAL_TEST);

        CrawlingResponse actual = this.syncWebClient.connectWithProxy(proxyInfo, unit);

        assertNotNull(actual);
    }

    @Nested
    class ProxyHttpCallTest {
        private static final String URL_G_MARKET = "http://item.gmarket.co.kr/DetailView/Item.asp?goodscode=1723472897&GoodsSale=Y&jaehuid=200002673";

        private static final String PROXY_IP = "125.57.214.189";
        private static final int PROXY_PORT = 3089;
        private static final String PROXY_USER = "jinroh";
        private static final String PROXY_PW = "shin2017";

        private ExchangeStrategies exchangeStrategies = ExchangeStrategies.builder()
                .codecs(conf -> conf.defaultCodecs().maxInMemorySize(-1))
                .build();

        @Test
        void restTemplateWithoutProxy() {
            RestTemplate restTemplate = new RestTemplate();
            StopWatch sw = new StopWatch();
            sw.start();

            ResponseEntity<String> forEntity = restTemplate.getForEntity(URL_G_MARKET, String.class);
            sw.stop();

            System.out.println("restTemplateWithoutProxy elapsed : " + sw.getTotalTimeSeconds());

            assertAll(
                    () -> assertNotNull(forEntity),
                    () -> assertNotNull(forEntity.getBody())
            );
        }

        @Test
        void webClientWithoutProxy(){
            ReactorClientHttpConnector connector = new ReactorClientHttpConnector(
                    HttpClient.create()
                            .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 1000)
                            .responseTimeout(Duration.of(3000, ChronoUnit.MILLIS))
            );

            WebClient webClient = WebClient.builder()
                    .exchangeStrategies(exchangeStrategies)
                    .clientConnector(connector)
                    .build();

            StopWatch sw = new StopWatch();

            sw.start();
            ResponseEntity<String> forEntity = webClient.get()
                    .uri(URL_G_MARKET)
                    .retrieve()
                    .toEntity(String.class)
                    .block();

            sw.stop();
            System.out.println("webClientWithoutProxy elapsed : " + sw.getTotalTimeSeconds());

            assertAll(
                    () -> assertNotNull(forEntity),
                    () -> assertNotNull(forEntity.getBody())
            );
        }

        @Test
        void webClientWithProxy() {
            HttpClient httpClient = HttpClient.create()
                    .proxy(addressSpec -> addressSpec.type(ProxyProvider.Proxy.SOCKS5)
                            .host(PROXY_IP)
                            .port(PROXY_PORT)
                            .username(PROXY_USER)
                            .password(u -> PROXY_PW)
                    );

            ReactorClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
            WebClient webClient = WebClient.builder()
                    .exchangeStrategies(exchangeStrategies)
                    .clientConnector(connector)
                    .build();

            StopWatch sw = new StopWatch();
            sw.start();
            ResponseEntity<String> forEntity = webClient.get()
                    .uri(URL_G_MARKET)
                    .retrieve()
                    .toEntity(String.class)
                    .block();

            sw.stop();
            System.out.println("webClientWithProxy elapsed : " + sw.getTotalTimeSeconds());

            assertAll(
                    () -> assertNotNull(forEntity),
                    () -> assertNotNull(forEntity.getBody())
            );
        }

        @Test
        void urlConnectionWithProxy() throws IOException {

            StopWatch sw = new StopWatch();
            sw.start();

            System.setProperty("socksProxyHost", PROXY_IP);
            System.setProperty("socksProxyPort", String.valueOf(PROXY_PORT));
            Authenticator.setDefault(new Authenticator(){
                @Override
                protected PasswordAuthentication getPasswordAuthentication(){
                    return new PasswordAuthentication(PROXY_USER, PROXY_PW.toCharArray());
                }
            });

            URL url = new URL(URL_G_MARKET);
            HttpURLConnection httpsUrlConn = (HttpURLConnection) url.openConnection();
            httpsUrlConn.setUseCaches(false);
            HttpURLConnection.setFollowRedirects(false);

            InputStream inputStream = httpsUrlConn.getInputStream();
            StringBuilder htmlData = new StringBuilder();
            String inputLine;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Charset.defaultCharset()));
            htmlData.delete(0, htmlData.length());
            while ((inputLine = bufferedReader.readLine()) != null){
                htmlData.append(inputLine.trim());
            }
            inputStream.close();

            sw.stop();
            System.out.println("urlConnectionWithProxy elapsed : " + sw.getTotalTimeSeconds());

            assertAll(
                    () -> assertNotNull(inputStream),
                    () -> assertNotNull(htmlData)
            );
        }
    }



}
