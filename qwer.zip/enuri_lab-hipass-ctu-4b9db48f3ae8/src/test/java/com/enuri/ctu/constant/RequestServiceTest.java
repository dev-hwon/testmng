package com.enuri.ctu.constant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class RequestServiceTest extends AbstractEnumCacheTest {

    @Test
    @DisplayName("RequestService Cache 테스트")
    @Override
    void cacheTest() {
        assertAll(
                () -> assertEquals(RequestService.HOMEPAGE, RequestService.getRequestService("1")),
                () -> assertEquals(RequestService.FOREIGN_MALL_TARGET, RequestService.getRequestService("3")),
                () -> assertEquals(RequestService.DEAL, RequestService.getRequestService("6"))
        );
    }

    @Test
    @DisplayName("RequestService Cache null 을 return 하는 테스트")
    @Override
    void nullReturnTest() {
        assertAll(
                () -> assertNull(RequestService.getRequestService(null)),
                () -> assertNull(RequestService.getRequestService("NOT_EXIST_TEMP_CODE"))
        );
    }
}