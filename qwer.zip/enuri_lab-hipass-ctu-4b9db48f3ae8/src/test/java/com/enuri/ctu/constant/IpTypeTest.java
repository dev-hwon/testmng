package com.enuri.ctu.constant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IpTypeTest {

    @ParameterizedTest
    @MethodSource("ipTypeArgumentSources")
    @DisplayName("IP:PORT 패턴으로 IpType 취득 테스트")
    void patternMapTest(String ipWithPort, IpType expectedIpType) {
        assertEquals(expectedIpType, IpType.getIpType(ipWithPort));
    }

    private static Stream<Arguments> ipTypeArgumentSources() {
        return Stream.of(
                Arguments.of("127.0.0.1:8080", IpType.LOCAL),
                Arguments.of("10.10.10.13:8080", IpType.LOCAL),
                Arguments.of("192.168.213.173:8098", IpType.DEVELOPMENT),
                Arguments.of("192.168.213.173:8088", IpType.PRODUCTION),
                Arguments.of("192.168.213.228:8088", IpType.PRODUCTION),
                Arguments.of("192.168.213.228:8098", IpType.DEVELOPMENT),
                Arguments.of("192.168.213.10:8098", IpType.NOT_ALLOWED_IP_TYPE),
                Arguments.of("1.1.1.1", IpType.NOT_ALLOWED_IP_TYPE),
                Arguments.of("", IpType.NOT_ALLOWED_IP_TYPE),
                Arguments.of(null, IpType.NOT_ALLOWED_IP_TYPE)
        );
    }
}