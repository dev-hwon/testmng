package com.enuri.ctu.constant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class DivideCodeTest extends AbstractEnumCacheTest {

    @Test
    @DisplayName("DivideCode Cache 테스트")
    @Override
    void cacheTest() {
        assertAll(
                () -> assertEquals(DivideCode.NORMAL_PRICE, DivideCode.getDivideCode("1")),
                () -> assertEquals(DivideCode.SALE_PRICE, DivideCode.getDivideCode("2")),
                () -> assertEquals(DivideCode.DELIVERY_PRICE, DivideCode.getDivideCode("5")),
                () -> assertEquals(DivideCode.SOLD_OUT, DivideCode.getDivideCode("6"))
        );
    }

    @Test
    @DisplayName("DivideCode Cache null 을 return 하는 테스트")
    @Override
    void nullReturnTest() {
        assertAll(
                () -> assertNull(DivideCode.getDivideCode(null)),
                () -> assertNull(DivideCode.getDivideCode("NOT_EXIST_TEMP_CODE"))
        );
    }
}