package com.enuri.ctu.dao.ctulog;

import com.enuri.ctu.config.test.CtuLogTestConfig;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.vo.GoodsCodeVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Import(CtuLogTestConfig.class)
class CtuLogDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private CtuLogDao ctuLogDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-mariadb-ctulog.sql");
    }

    @Test
    void insertFailLogTest() {
        FailLog failLog = FailLog.builder()
                .url("TEST-URL")
                .service("TEST-SERVICE")
                .shopCode(0L)
                .goodsCode("TEST-GOODS-CODE")
                .plNo("TEST-PL-NO")
                .crawlingUrl("TEST-CRAWLING-URL")
                .failType(0)
                .build();

        int result = this.ctuLogDao.insertFailLog(failLog);

        assertEquals(1, result);
    }

    @Test
    void insertSubscribeModelFailLogTest() {
        GoodsCodeVO goodsCodeVO = new GoodsCodeVO(0, "TEST-GOODS-CODE", 999, "4");
        LocalDateTime requestAt = LocalDateTime.now();
        LocalDateTime responseAt = requestAt.plusMinutes(1L);

        int result = this.ctuLogDao.insertSaveGoodsResult(goodsCodeVO, requestAt, responseAt, "", CtuTest.ONLY_FOR_CRAWLER_TEST.getCode());

        assertEquals(1, result);
    }
}
