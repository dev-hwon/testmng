package com.enuri.ctu.exception;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.controller.CtuRestController;
import com.enuri.ctu.vo.CtuParamVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    @Mock
    private CtuRestController ctuRestController;
    private MockMvc mockMvc;

    @BeforeEach
    void testSetup() {
        // mockMvc에 GlobalExceptionHandler 등록
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.ctuRestController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    /**
     * <pre>
     *     1. CtuController 를 mocking 하여 호출시 CtuException 이 발생하도록 설정
     *     2. mockMvc 로 uri를 호출하였을때 1번에서 설정한 CtuException 이 발생되고 
     *     3. GlobalExceptionHandler 에 의해 정의된 Response 를 응답 받음
     *     
     *     아래 테스트는 그 Response 가 Sample 과 일치하는지 확인
     * </pre>
     */
    @Test
    @DisplayName("CtuException 이 발생 했을때 Exception Handler 테스트")
    void cutExceptionMockTest() throws Exception {
        String samplePath = "src/test/resources/sample/no_querystring_response.json";
        Path path = Paths.get(samplePath);
        String json = String.join("", Files.readAllLines(path));

        String uri = "/ctuApi/getCtuData.enuri";

        when(this.ctuRestController.getCtuData(any(CtuParamVO.class), any(BindingResult.class)))
                .thenThrow(new CtuException(ResultMessageCode.FAIL, "EXCEPTION_HANDLER_TEST"));

        this.mockMvc.perform(get(uri))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(json))
                .andDo(print());
    }
}
