package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.vo.GatheringInfoVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OracleGatheringDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OracleGatheringDao oracleGatheringDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-gathering.sql");
        super.executeSql("data/data-CTU_GATHERING_INFO.sql");
    }

    @Test
    @DisplayName("fetchGatheringInfoForTest 테스트")
    void forTest() {
        final ShopCode shopCode = ShopCode.COUPANG;
        final DeviceType deviceType = DeviceType.MOBILE;
        final RequestService service = RequestService.HOMEPAGE;

        GatheringInfoVO gatheringInfoVO = this.oracleGatheringDao
                .fetchGatheringInfoForTest(shopCode.getCode(), deviceType.getCode(), service.getCode()).get(0);

        assertAll(
                () -> assertNotNull(gatheringInfoVO),
                () -> assertEquals(23795, gatheringInfoVO.getGtrCode()),
                () -> assertEquals("http://m.coupang.com/vm/products/GTR_GOODS_CODE",
                        gatheringInfoVO.getGtrUrl())
        );
    }

    @Test
    @DisplayName("fetchGatheringInfoForReal 테스트")
    void forReal() {
        final ShopCode shopCode = ShopCode.COUPANG;
        final DeviceType deviceType = DeviceType.PC;
        final RequestService service = RequestService.HOMEPAGE;

        GatheringInfoVO gatheringInfoVO = this.oracleGatheringDao
                .fetchGatheringInfoForReal(shopCode.getCode(), deviceType.getCode(), service.getCode()).get(0);

        assertAll(
                () -> assertNotNull(gatheringInfoVO),
                () -> assertEquals(23781, gatheringInfoVO.getGtrCode()),
                () -> assertEquals("https://www.coupang.com/vp/products/GTR_PAGE_KEY?itemId=GTR_ITEM_ID&vendorItemId=GTR_VENDOR_ITEM_ID&lptag=GTR_GOODS_CODE&isAddedCart=",
                        gatheringInfoVO.getGtrUrl())
        );
    }
}
