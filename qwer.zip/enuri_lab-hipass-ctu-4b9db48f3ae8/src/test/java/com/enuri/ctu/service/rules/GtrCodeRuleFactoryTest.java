package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.lotte.LotteRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class GtrCodeRuleFactoryTest {

    @Autowired
    private GtrCodeRuleFactory gtrCodeRuleFactory;

    @Test
    void defaultGtrCodeRuleTest() {
        final long gtrCode = 0L;
        final long shopCode = 99999L;
        final DeviceType deviceType = DeviceType.PC;

        long actual = this.gtrCodeRuleFactory.getGtrCodeRule(null).replaceGtrCode(gtrCode, shopCode, deviceType.getCode());

        assertEquals(gtrCode, actual);
    }

    @Test
    void getGtrCodeRuleImplementTest() {
        assertAll(
                () -> assertTrue(this.gtrCodeRuleFactory.getGtrCodeRule(ShopCode.EL_LOTTE) instanceof LotteRule),
                () -> assertTrue(this.gtrCodeRuleFactory.getGtrCodeRule(ShopCode.LOTTE_MART_MALL) instanceof LotteRule),
                () -> assertTrue(this.gtrCodeRuleFactory.getGtrCodeRule(ShopCode.LOTTE_ON) instanceof LotteRule),
                () -> assertTrue(this.gtrCodeRuleFactory.getGtrCodeRule(ShopCode.SSG_DEPT) instanceof SsgRule)
        );
    }

    @ParameterizedTest
    @MethodSource("gtrCodeTestArguments")
    void getGtrCodeTest(long gtrCode, ShopCode shopCode, DeviceType device, long expect) {
        ShopRule gtrCodeRule = this.gtrCodeRuleFactory.getGtrCodeRule(shopCode);

        assertEquals(expect, gtrCodeRule.replaceGtrCode(gtrCode, shopCode.getCode(), device.getCode()));
    }

    private static Stream<Arguments> gtrCodeTestArguments() {
        final long defaultGtrCode = 9999L;
        final long lotteReplaceGtrCode = 401L;
        final long ssgMobileReplaceGtrCode = 2461;
        final long ssgPcReplaceGtrCode = 811;

        return Stream.of(
                Arguments.of(defaultGtrCode, ShopCode.EL_LOTTE, DeviceType.PC, lotteReplaceGtrCode),
                Arguments.of(defaultGtrCode, ShopCode.LOTTE_MART_MALL, DeviceType.PC, lotteReplaceGtrCode),
                Arguments.of(defaultGtrCode, ShopCode.LOTTE_ON, DeviceType.PC, defaultGtrCode),
                Arguments.of(defaultGtrCode, ShopCode.LOTTE_ON, DeviceType.MOBILE,lotteReplaceGtrCode),
                Arguments.of(defaultGtrCode, ShopCode.SSG_DEPT, DeviceType.PC, ssgPcReplaceGtrCode),
                Arguments.of(defaultGtrCode, ShopCode.SSG_DEPT, DeviceType.MOBILE, ssgMobileReplaceGtrCode)
        );
    }
}
