package com.enuri.ctu.util;

import org.junit.jupiter.api.Test;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RegExpUtilTest {

    @Test
    void getBelowDecimalPlaceTest() {
        String val1 = "12.3456";
        double expected = 0.3456;
        assertEquals(expected, RegExpUtils.getBelowDecimalPlace(val1));
    }

    @Test
    void getRegExpDataTest() {
        String source = "alse,\"stockStatusDescription\":[{\"text\":\"재고있음\",\"color\":\"#00891A\",\"bold\":false,\"size\":0,\"strikethrough\":false}],\"subscribeMaximumBuyableQuantity\":2}],\"selectedPosition\":0,\"isTravelDaysOption\":false},\"optionContainer\":null,\"vendorItemDetail\":{\"item\":{\"productId\":4624314798,\"itemId\":5735614447,\"itemName\":\"스포츠리서치 트리플 스트렝스 오메가-3 피쉬 오일 1250mg 소프트젤, 180캡슐, 1개\",\"vendorItemId\":4765824657,\"vendorItemName\":\"\",\"vendorId\":\"C00051747\",\"vendor\":{\"vendorId\":\"C00051747\",\"name\":\"Coupang Global LLC\",\"nickname\":null,\"score\":null,\"rate\":null,\"resource\":null,\"bizNumber\":\"1236004\",\"representiveName\":\"James Roe\",\"representivePhone\":\"02-1577-7011\",\"representiveZipCode\":\"92507\",\"representiveAddress\":\"1560 Sierra Ridge Dr. Riverside, California, USA -\",\"representiveEmail\":\"support@USjikgu.com\",\"representiveHompageURL\":\"\",\"representivePersonName\":null,\"vendorShippingPlaceList\":[]},\"soldOut\":false,\"buyableQuantity\":6,\"coupangSrl\":-1,\"optionSrl\":4765824657,\"deliveryCharge\":100,\"deliveryChargeType\":\"CONDITIONAL_FREE\",\"deliveryBadge\":{\"iconUrl\":\"https://image10.coupangcdn.com/image/delivery_badge/sdp_normal/android/global_b/hdpi/global_b.png\",\"iconWidth\":64,\"iconHeight\":16},\"deliveryTypeBadgeList\":[{\"iconUrl\":\"https://image10.coupangcdn.com/image/delivery_badge/sdp_normal/android/global_b/hdpi/global_b.png\",\"iconWidth\":64,\"iconHeight\":16}],\"defaultDeliverTitle\":\"쿠팡직구\",\"freeShipOverAmount\":29800,\"logisticsType\":false,\"rocketPlus2\":false,\"batchShipment\":true,\"coupangFreeShippingApplicable\":false,\"coupangFreeShippingFee\":9800,\"detailContent\":{\"url\":\"https://m.coupang.com/vm/api/v1/vendor-items/4765824657?pageType=enhancedpdp&bundleId=0&enableQnA=false&showQnAButtons=false&categoryUIType=false\",\"viewType\":\"URL\"},\"deliveryDescriptions\":[{\"text\":\"무료배송\",\"color\":\"#6fb000\",\"bold\":false,\"size\":0,\"strikethrough\":false}],\"outboundShippingPlaceId\":0,\"productName\":\"스포츠리서치 트리플 스트렝스 오메가-3 피쉬 오일 1250mg 소프트젤\",\"bundleId\":0,\"originalPrice\":56840,\"couponPrice\":48310,\"couponPriceTitle\":\"즉시할인가\",\"unitPrice\":\"1정당 316원\",\"discountRate\":15,\"wowInstant\":false,\"wowCoupon\":false,\"gppuPricePolicy\":[{\"originalPrice\":null,\"salePrice\":\"56,840원\",\"discountRate\":\"15%\",\"description\":\"쿠팡이 실제로 최근 90일이내에 판매하였던 가격 중에서, 주요 온라인 경쟁사 가격과 동일하거나 낮은 수준으로 판매가를 설정하기 위한 기준가격입니다.\"}],\"showAppLink\":false,\"buyTipTitle\":\"구매 팁\",\"moreDetailContent\":{\"url\":\"https://m.coupang.com/vm/api/v1/vendor-item-details/4765824657\",\"viewType\":\"URL\"},\"checkoutUrl\":\"https://capi.coupang.com/v3/checkout/products/4624314798\",\"badgeMap\":{},\"giftCard\":false,\"forceHide3pWarningBanner\":false,\"ce\":false,\"categoryId\":8540,\"commonPopupPage\":";
        String pattern = "\"couponPrice\":(.*?),\"couponPriceTitle\":\"즉시할인가\",";

        String regExpData = RegExpUtils.getRegExpData(source, pattern);
        String legacyData = this.legacyGetRegExpData(source, pattern);
        assertEquals(legacyData, regExpData);

        System.out.println(legacyData);
        System.out.println(regExpData);
    }

    private String legacyGetRegExpData(String htmlData, String regExpPattern) {
        String resultData = "";
        Pattern pt = Pattern.compile(regExpPattern);
        Matcher mc = pt.matcher(htmlData);
        while (mc.find() && resultData=="") {
            resultData = mc.group(1);
            if(StringUtils.hasText(resultData)){
                return resultData;
            }else{
            }
        }
        return resultData;
    }
}
