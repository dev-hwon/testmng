package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.vo.CtuShopJobVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Import(OracleElocTestConfig.class)
class OracleShopJobDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OracleShopJobDao oracleShopJobDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-shopjob.sql");
        super.executeSql("data/data-TBL_CTU_SHOP_JOB.sql");
        super.executeSql("data/data-TBL_SHOPLIST.sql");
    }

    @Test
    void fetchShopJobTest() {
        final ShopCode shopCode = ShopCode.COUPANG;
        CtuShopJobVO ctuShopJobVO = this.oracleShopJobDao.fetchShopJob(shopCode.getCode());

        assertAll(
                () -> assertNotNull(ctuShopJobVO),
                () -> assertTrue(ctuShopJobVO.getPriceYn())
        );
    }

    @Test
    void fetchSmartStoreShopJobTest() {
        final int smartStoreShopCode = 0;
        CtuShopJobVO ctuShopJobVO = this.oracleShopJobDao.fetchSmartStoreShopJob(smartStoreShopCode);

        assertAll(
                () -> assertNotNull(ctuShopJobVO),
                () -> assertTrue(ctuShopJobVO.getPriceYn())
        );
    }
}
