package com.enuri.ctu.constant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class DeviceTypeTest extends AbstractEnumCacheTest {

    @Test
    @DisplayName("DeviceType Cache 테스트")
    @Override
    void cacheTest() {
        assertAll(
                () -> assertEquals(DeviceType.PC, DeviceType.getDeviceType("1")),
                () -> assertEquals(DeviceType.MOBILE, DeviceType.getDeviceType("2"))
        );
    }

    @Test
    @DisplayName("DeviceType Cache null 을 return 하는 테스트")
    @Override
    void nullReturnTest() {
        assertAll(
                () -> assertNull(DeviceType.getDeviceType(null)),
                () -> assertNull(DeviceType.getDeviceType("NOT_EXIST_TEMP_CODE"))
        );
    }
}