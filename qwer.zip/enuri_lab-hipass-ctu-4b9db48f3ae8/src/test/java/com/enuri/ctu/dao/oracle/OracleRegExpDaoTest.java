package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.vo.CtuRegExpVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OracleRegExpDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OracleRegExpDao oracleRegExpDao;

    // gtrCode = 23781 coupang
    private final long givenGtrCode = 23781;
    private final long givenShopCode = ShopCode.COUPANG.getCode();
    private final String givenRegexpDivis = "1";
    private final String testCk = CtuTest.ONLY_FOR_CRAWLER_TEST.getCode();

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-regexp.sql");
        super.executeSql("data/data-CTU_REGEXP_INFO.sql");
        super.executeSql("data/data-CTU_PARSE_DIVIDE_INFO.sql");
        super.executeSql("data/data-CTU_SHOP_DIVIDE_MAP.sql");
        super.executeSql("data/data-TBL_CTU_SHOP_JOB.sql");
    }

    @Test
    void fetchRegExpListTest() {
        List<CtuRegExpVO> ctuRegExpVOList = this.oracleRegExpDao.fetchRegExpList(givenGtrCode, givenRegexpDivis, testCk);

        assertAll(
                () -> assertNotNull(ctuRegExpVOList),
                () -> assertFalse(ctuRegExpVOList.isEmpty())
        );
    }

    @Test
    void fetchRegExpListForPcTest() {
        List<CtuRegExpVO> ctuRegExpVOList = this.oracleRegExpDao
                .fetchRegExpListForPc(givenShopCode, givenGtrCode, givenRegexpDivis, testCk);

        assertAll(
                () -> assertNotNull(ctuRegExpVOList),
                () -> assertFalse(ctuRegExpVOList.isEmpty())
        );
    }

    @Test
    void fetchRegExpListForMobileYTest() {
        List<CtuRegExpVO> ctuRegExpVOList = this.oracleRegExpDao
                .fetchRegExpListForMobileY(givenShopCode, givenGtrCode, givenRegexpDivis, CtuTest.REAL_TEST.getCode());

        assertAll(
                () -> assertNotNull(ctuRegExpVOList),
                () -> assertFalse(ctuRegExpVOList.isEmpty())
        );
    }

    @Test
    void fetchRegExpListForMobileNTest() {
        List<CtuRegExpVO> ctuRegExpVOList = this.oracleRegExpDao
                .fetchRegExpListForMobileN(givenShopCode, givenGtrCode, givenRegexpDivis, CtuTest.REAL_TEST.getCode());

        assertAll(
                () -> assertNotNull(ctuRegExpVOList),
                () -> assertFalse(ctuRegExpVOList.isEmpty())
        );
    }
}
