package com.enuri.ctu.controller;

import com.enuri.ctu.constant.MinibotResult;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.exception.GlobalExceptionHandler;
import com.enuri.ctu.service.CtuProcess;
import com.enuri.ctu.vo.CtuParamVO;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;

import static com.enuri.ctu.controller.RestDocsTestUtil.getDocumentRequest;
import static com.enuri.ctu.controller.RestDocsTestUtil.getDocumentResponse;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.payload.PayloadDocumentation.subsectionWithPath;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.requestParameters;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Tag("rest-docs")
@ExtendWith({RestDocumentationExtension.class, MockitoExtension.class})
@WebMvcTest(CtuRestController.class)
class CtuRestControllerTest {

    @Mock
    private CtuRestController ctuRestController;

    @MockBean
    private CtuProcess ctuProcess;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp(RestDocumentationContextProvider restDocumentation) {
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.ctuRestController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .apply(documentationConfiguration(restDocumentation))
                .build();
    }

    @Test
    void getCtuDataTest() throws Exception {
        final String queryString = "?ctu_test=RT&divis=&shop_code=4027&goods_code=C628865722&device=1&service=1&pl_no=&user_ip=&goods_seq=&system_type=3";
        String uri = "/ctuApi/getCtuData.enuri" + queryString;

        CommonResponse givenResponseDto = CommonResponse.builder()
                .resultMsg(ResultMessageCode.SUCCESS)
                .resultData(
                        ResultDataSub.builder()
                                .salePrice("18600")
                                .deliveryPrice("2500")
                                .build()
                )
                .modelMinPrice(18600L)
                .goodsCategory("24020804")
                .goodsCode("955601227")
                .minibotResult(MinibotResult.MINIBOT_Z)
                .shopCode(536L)
                .goodsUrl("http://item2.gmarket.co.kr/Item/detailview/Item.aspx?goodscode=955601227&GoodsSale=Y&jaehuid=200002673")
                .build();

        ResponseEntity<CommonResponse> givenReturnEntity = ResponseEntity.ok(givenResponseDto);

        when(this.ctuRestController.getCtuData(any(CtuParamVO.class), any(BindingResult.class)))
                .thenReturn(givenReturnEntity);

        // Request performing
        ResultActions result = this.mockMvc.perform(get(uri))
                .andDo(print());

        // Response
        result.andExpect(status().isOk())
                .andDo(
                        document("getCtuData",
                                getDocumentRequest(),
                                getDocumentResponse(),
                                requestParameters(
                                        parameterWithName("ctu_test").description("TEST 유무(Y:테스트, N:정상)"),
                                        parameterWithName("shop_code").description("타겟몰 업체 코드"),
                                        parameterWithName("goods_code").description("타겟몰 기준 상품 코드"),
                                        parameterWithName("pl_no").description("에누리 기준 PriceList 코드").optional(),
                                        parameterWithName("divis").description("테스트 구분값\n(1:판매가, 2:할인가... CTU_PARSE_DIVIDE_INFO 참조").optional(),
                                        parameterWithName("device").description("디바이스 구분\n(1:PC, 2:모바일)"),
                                        parameterWithName("service").description("CTU호출 출발지 서비스 구분\n( 1:홈페이지, 2:소셜비교, 3:해외몰타겟, 4:ETC, 5: SDUL서비스, 6:DEAL, 7:알툴바 가격백신, 8:DW크롤링)"),
                                        parameterWithName("user_ip").description("사용자 IP").optional(),
                                        parameterWithName("server_ip").description("서버 IP").optional(),
                                        parameterWithName("system_type").description("시스템 타입\n(1:MiniBot, 2:MP, 3:wwwCtu, 4:MobileCtu, 5:SDUL, 6:Etc-미정, 8:miniMP)").optional(),
                                        parameterWithName("user_id").description("사용자 ID").optional(),
                                        parameterWithName("user_name").description("사용자 이름").optional(),
                                        parameterWithName("goods_url").description("상품 상세 링크 (해당 타겟몰 기준 상세 링크 - Deal서비스 목적으로 새로 생성됨)").optional(),
                                        parameterWithName("goods_seq").description("Deal 상품 전용 유니크 코드").optional(),
                                        parameterWithName("shop_type").description("스마트스토어 : 4").optional()
                                ),
                                responseFields(
                                        fieldWithPath("resultMsg").description("CTU처리 성공여부"),
                                        subsectionWithPath("resultData").description("응답 데이터").type(JsonNodeType.OBJECT).optional(),
                                        fieldWithPath("resultData.NormalPrice").description("판매가").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.SalePrice").description("할인가").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.SaleRate").description("할인율").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.CardPrice").description("카드가").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.DeliveryPrice").description("배송비").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.SoldOut").description("품절").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.Coupon").description("쿠폰").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.InstChargePrice").description("설치비").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultData.Adult").description("성인인증").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("modelMinPrice").description("모델 최저가").type(JsonFieldType.NUMBER).optional(),
                                        fieldWithPath("goodsCategory").description("상품 카테고리").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("GoodsCode").description("상품 코드").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultMinibotMsg")
                                                .description("미니봇 처리용 응답\n(MINIBOT_X: 초기상태, MINIBOT_Z: 크롤링 성공, MINIBOT_D: 품절, MINIBOT_Y: 가격 업데이트")
                                                .type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("ShopCode").description("쇼핑몰 코드").type(JsonFieldType.NUMBER).optional(),
                                        fieldWithPath("GoodsUrl").description("호출타겟 URL").type(JsonFieldType.STRING).optional(),
                                        subsectionWithPath("resultDataPromotion").description("호출타겟 URL").type(JsonNodeType.OBJECT).optional(),
                                        fieldWithPath("resultDataPromotion.resultMsg").description("성공여부").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultDataPromotion.PromotionRate").description("프로모션 할인율").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultDataPromotion.PromotionPrice").description("프로모션 적용가").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("resultDataPromotion.PromotionCardPrice").description("프로모션 적용 카드가").type(JsonFieldType.STRING).optional(),
                                        fieldWithPath("hasBeenPer").description("단종비율\n(ex 설정값/실제비율: 0.8/0.43103448)").type(JsonFieldType.NUMBER).optional(),
                                        fieldWithPath("hasBeenCk").description("단종3").type(JsonFieldType.BOOLEAN).optional()
                                )
                        )
                );
    }
}
