package com.enuri.ctu.constant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class SystemTypeTest extends AbstractEnumCacheTest {

    @Test
    @DisplayName("SystemType Cache 테스트")
    @Override
    void cacheTest() {
        assertAll(
                () -> assertEquals(SystemType.MINI_BOT, SystemType.getSystemType("1")),
                () -> assertEquals(SystemType.WEB_CTU, SystemType.getSystemType("3")),
                () -> assertEquals(SystemType.SDUL, SystemType.getSystemType("5"))
        );
    }

    @Test
    @DisplayName("SystemType Cache null 을 return 하는 테스트")
    @Override
    void nullReturnTest() {
        assertAll(
                () -> assertNull(SystemType.getSystemType(null)),
                () -> assertNull(SystemType.getSystemType("NOT_EXIST_TEMP_CODE"))
        );
    }
}
