package com.enuri.ctu.dao;

import com.enuri.ctu.config.datasource.MariaCtuLogDataSourceConfig;
import com.enuri.ctu.config.datasource.MariaCwsDataSourceConfig;
import com.enuri.ctu.config.datasource.MariaNewCwsDataSourceConfig;
import com.enuri.ctu.config.datasource.MsElocDataSourceConfig;
import com.enuri.ctu.config.datasource.MsLogDataSourceConfig;
import com.enuri.ctu.config.datasource.MsMartDataSourceConfig;
import com.enuri.ctu.config.datasource.OracleMainDataSourceConfig;
import com.enuri.ctu.dao.ctulog.MariaCtuLogTestDao;
import com.enuri.ctu.dao.cws.MariaCwsTestDao;
import com.enuri.ctu.dao.eloc.ElocTestDao;
import com.enuri.ctu.dao.mslog.MsLogTestDao;
import com.enuri.ctu.dao.newcws.MariaNewCwsTestDao;
import com.enuri.ctu.dao.oracle.OracleTestDao;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import({
        OracleMainDataSourceConfig.class,
        MsElocDataSourceConfig.class,
        MsLogDataSourceConfig.class,
        MariaCtuLogDataSourceConfig.class,
        MariaCwsDataSourceConfig.class,
        MariaNewCwsDataSourceConfig.class,
        MsMartDataSourceConfig.class
})
class ConnectionTest {

    @Autowired
    private OracleTestDao oracleTestDao;
    @Autowired
    private MsLogTestDao msLogTestDao;
    @Autowired
    private ElocTestDao elocTestDao;
    @Autowired
    private MariaCtuLogTestDao mariaCtuLogTestDao;
    @Autowired
    private MariaCwsTestDao mariaCwsTestDao;
    @Autowired
    private MariaNewCwsTestDao mariaNewCwsTestDao;
//    @Autowired
//    private MsMartTestDao msMartTestDao;


//    @Test
    void connectTest() {
        assertAll(
                () -> assertEquals(1, oracleTestDao.connectTest()),
                () -> assertEquals(2, elocTestDao.connectElocTest()),
                () -> assertEquals(3, msLogTestDao.connectMsLogTest()),
                () -> assertEquals(4, mariaCtuLogTestDao.connectCtuLogTest()),
                () -> assertEquals(5, mariaCwsTestDao.connectCwsTest()),
                () -> assertEquals(6, mariaNewCwsTestDao.connectNewCwsTest())
//                () -> assertEquals(7, msMartTestDao.connectMartTest())
        );
    }
}
