package com.enuri.ctu.dto;

import com.enuri.ctu.constant.ResultMessageCode;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.json.JsonContent;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;

@JsonTest
class CommonResponseTest {

    @Autowired
    private JacksonTester<CommonResponse> tester;

    @Test
    void serializeTest() throws IOException {
        CommonResponse commonResponse = CommonResponse.builder()
                .resultMsg(ResultMessageCode.CATEGORY_DENY)
                .build();

        JsonContent<CommonResponse> jsonContent = tester.write(commonResponse);

        assertThat(jsonContent)
                .extractingJsonPathStringValue("@.resultMsg")
                .isEqualTo(ResultMessageCode.CATEGORY_DENY.getMessage());
    }
}
