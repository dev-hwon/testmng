package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.vo.TblPriceListDataVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OraclePriceListDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OraclePriceListDao oraclePriceListDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-pricelist.sql");
        super.executeSql("data/data-TBL_PRICELIST.sql");
    }

    @Test
    void fetchTblPriceListDataTest() {

        TblPriceListDataVO vo = this.oraclePriceListDao.fetchTblPriceListData(7861L, "I10000006131", "12464724930");

        assertNotNull(vo);
    }
}
