package com.enuri.ctu.dao;

import org.junit.jupiter.api.AfterEach;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;

import javax.sql.DataSource;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.fail;

@MybatisTest(properties = "classpath:resources/application-test.yaml")
public abstract class AbstractCtuDaoTest {

    @Autowired
    protected DataSource dataSource;

    protected abstract void init();

    protected void executeSql(String sqlFilePath) {
        ClassPathResource classPathResource = new ClassPathResource(sqlFilePath);
        try {
            ScriptUtils.executeSqlScript(this.dataSource.getConnection(), classPathResource);
        } catch (SQLException e) {
            fail(e);
        }
    }

    @AfterEach
    protected void cleanData() {
        this.executeSql("data/clean-all.sql");
    }
}
