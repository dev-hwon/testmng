package com.enuri.ctu.config.test;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@MapperScan(
        basePackages = "com.enuri.ctu.dao.oracle",
        sqlSessionFactoryRef = "oraTestSqlSessionFactory"
)
public class OracleElocTestConfig extends AbstractH2Config {

    @Bean("oraDataSource")
    @Override
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl("jdbc:log4jdbc:h2:mem:testdb;MODE=Oracle;DB_CLOSE_DELAY=-1;");
        dataSource.setDriverClassName("net.sf.log4jdbc.sql.jdbcapi.DriverSpy");
        dataSource.setUsername("sa");

        return dataSource;
    }

    @Bean("oraTestSqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("oraDataSource") DataSource dataSource,
                                               ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        bean.setMapperLocations(applicationContext.getResources("classpath:mapper/oracle/**/*.xml"));

        return bean.getObject();
    }

    @Bean("oraTestSqlSessionTemplate")
    public SqlSessionTemplate sqlSessionTemplate(
            @Qualifier("oraTestSqlSessionFactory") SqlSessionFactory sessionFactory) {
        return new SqlSessionTemplate(sessionFactory);
    }
}
