package com.enuri.ctu.service.rules.shop.wemap;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class WeMapRuleTest {

    @Autowired
    private WeMapRule weMapRule;

    @ParameterizedTest
    @MethodSource("isSkipCateArguments")
    void isSkipCateTest(String cateCode, boolean expect) {
        boolean actual = weMapRule.isSkipCate(cateCode);
        assertEquals(expect, actual);
    }

    private static Stream<Arguments> isSkipCateArguments() {
        return Stream.of(
                Arguments.of("09301111", false),
                Arguments.of("08999", false),
                Arguments.of("09999", false),
                Arguments.of("10321", false),
                Arguments.of("12309", false),
                Arguments.of("21309", false),
                Arguments.of("99999", true)
        );
    }
}
