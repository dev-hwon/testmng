package com.enuri.ctu.dao;

import com.enuri.ctu.config.datasource.OracleMainDataSourceConfig;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.oracle.OracleShopJobDao;
import com.enuri.ctu.vo.CtuShopJobVO;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@MybatisTest
@Import(OracleMainDataSourceConfig.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class ElocShopJobMyBatisTest {

    @Autowired
    private OracleShopJobDao oracleShopJobDao;

//    @Test
    void fetchSmartStoreShopJobTest() {
        CtuShopJobVO actual = this.oracleShopJobDao.fetchSmartStoreShopJob(ShopCode.SMART_STORE.getCode());

        assertAll(
                () -> assertNotNull(actual),
                () -> assertEquals(0, actual.getShopCode()),
                () -> assertTrue(actual.getPriceYn()),
                () -> assertFalse(actual.getCardPriceYn()),
                () -> assertNull(actual.getAdultYn()),
                () -> assertNull(actual.getShopName())
        );
    }

//    @Test
    void fetchShopJobTest() {
        CtuShopJobVO actual = this.oracleShopJobDao.fetchShopJob(ShopCode.GALLERIA_MALL.getCode());

        assertAll(
                () -> assertNotNull(actual),
                () -> assertEquals(ShopCode.GALLERIA_MALL.getCode(), actual.getShopCode()),
                () -> assertEquals("갤러리아몰", actual.getShopName()),
                () -> assertTrue(actual.getPriceYn()),
                () -> assertFalse(actual.getCardPriceYn()),
                () -> assertNull(actual.getAdultYn())
        );
    }
}
