package com.enuri.ctu.dao;

import com.enuri.ctu.dao.redis.CtuParamRedisRepository;
import com.enuri.ctu.entity.CtuParamEntity;
import com.enuri.ctu.util.CommonUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class RedisConnectionTest {

    private final CtuParamRedisRepository ctuParamRedisRepository;

    @Autowired
    RedisConnectionTest(CtuParamRedisRepository ctuParamRedisRepository) {
        this.ctuParamRedisRepository = ctuParamRedisRepository;
    }

    @Test
    @DisplayName("CtuParamEntity Redis save/find 테스트")
    void redisSetGetTest() {
        String id = "shop_code_123/goods_code_xyz/device_mobile";
        String value = CommonUtil.getLocalDateTime();

        CtuParamEntity entity = new CtuParamEntity(id, value);
        this.ctuParamRedisRepository.save(entity);

        Optional<CtuParamEntity> optionalSaveEntity = this.ctuParamRedisRepository.findById(id);
        if (!optionalSaveEntity.isPresent()) {
            fail();
        }

        assertEquals(value, optionalSaveEntity.get().getValue());

        this.ctuParamRedisRepository.deleteById(id);
    }
}
