package com.enuri.ctu.service.savegoods;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.service.savegoods.preprocess.SaveGoodsPreProcess;
import com.enuri.ctu.vo.GoodsCodeVO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class, SpringExtension.class})
@SpringBootTest
class ScheduledSaveGoodsServiceTest {
    @Autowired
    private ScheduledSaveGoodsService service;

    @MockBean
    private SaveGoodsDataHandler dataHandler;

    @MockBean
    private SaveGoodsPreProcess preProcess;

    @Test
    void saveGoodsProcessTest() {
        List<Long> givenModelList = Collections.singletonList(8553187L);
        List<GoodsCodeVO> givenGoodsCode = Arrays.asList(
                new GoodsCodeVO(8553187,"P5381202047", 7861, "4")
        );

        doNothing().when(this.preProcess).initWorkingTable();
        when(this.dataHandler.getAllModelNo()).thenReturn(givenModelList);
        when(this.dataHandler.getGoodsCode(any(Long.class))).thenReturn(givenGoodsCode);

        assertDoesNotThrow(() -> this.service.saveGoodsProcess(CtuTest.ONLY_FOR_CRAWLER_TEST, IpType.LOCAL));
    }
}
