package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OracleSmartStoreDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OracleSmartStoreDao oracleSmartStoreDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-smartstore.sql");
        super.executeSql("data/data-TBL_SHOPLIST.sql");
    }

    @Test
    void fetchSmartStoreUrlTest() {
        final ShopCode shopCode = ShopCode.SMART_STORE;
        String storeUrl = this.oracleSmartStoreDao.fetchSmartStoreUrl(shopCode.getCode());

        assertNotNull(storeUrl);
    }
}
