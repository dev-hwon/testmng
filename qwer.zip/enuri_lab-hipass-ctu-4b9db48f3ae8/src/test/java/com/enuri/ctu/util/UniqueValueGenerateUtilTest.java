package com.enuri.ctu.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class UniqueValueGenerateUtilTest {
    
    @ParameterizedTest
    @ValueSource(ints = {5, 8, 10, 16})
    @DisplayName("유니크 문자열 길이 테스트")
    void generateUniqueCharLengthTest(final int size) {
        final String generatedValue = UniqueValueGenerateUtil.generateUniqueChar(size);

        assertEquals(size, generatedValue.length());
    }

    @ParameterizedTest
    @ValueSource(strings = {":", ";", "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`"})
    @DisplayName("특수 문자 제외 테스트")
    void excludeSpecialSymbolTest(final String specialSymbol) {
        final int defaultSize = 24;
        final String generatedValue = UniqueValueGenerateUtil.generateUniqueChar(defaultSize);

        assertFalse(generatedValue.contains(specialSymbol));
    }

}
