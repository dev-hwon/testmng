package com.enuri.ctu.constant;

import org.junit.jupiter.api.Test;

abstract class AbstractEnumCacheTest {
    @Test
    abstract void cacheTest();

    @Test
    abstract void nullReturnTest();
}
