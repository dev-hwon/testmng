package com.enuri.ctu.dao.newcws;

import com.enuri.ctu.config.test.NewCwsTestConfig;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.dto.logging.ProxyAccessLog;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Import(NewCwsTestConfig.class)
class NewCwsProxyInfoDaoTest extends AbstractCtuDaoTest {

    // mybatis - "insert on duplicate update" query 에서 insert 시 result=1, update 시 result=2 반환
    protected static final int EXPECTED_INSERT_RESULT = 1;
    protected static final int EXPECTED_UPDATE_RESULT = 2;

    @Autowired
    private NewCwsProxyInfoDao newCwsProxyInfoDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-mariadb-newcws.sql");
    }

    @Nested
    class ProxyInfoTest {
        @BeforeEach
        void dataInit() {
            executeSql("data/data-TB_CRWL_CONNECT_PROXY_LIST.sql");
        }

        @Test
        void fetchRandomProxyInfoTest() {
            ProxyConnectInfoVO proxyConnectInfoVO = newCwsProxyInfoDao.fetchRandomProxyInfo();
            assertAll(
                    () -> assertNotNull(proxyConnectInfoVO),
                    () -> assertTrue(proxyConnectInfoVO.getProxySeq() > 0)
            );
        }
    }

    @Nested
    class ProxyAccessLogTest {

        @BeforeEach
        void dataInit() throws SQLException {
            executeSql("data/data-TB_CRWL_PROXY_DAILY_COUNT_LOG.sql");
        }

        @Test
        @DisplayName("PK에 해당하는게 없어서 INSERT 실행 테스트")
        void insertWhenKeyNotExist() {
            // new log
            ProxyAccessLog proxyAccessLog = ProxyAccessLog.builder()
                    .dateNo("20990101")
                    .ip("255.255.255.255")
                    .serviceType("1")
                    .cpnCd("CC")
                    .build();

            int successProxyAccessLog = newCwsProxyInfoDao.insertSuccessProxyAccessLog(proxyAccessLog);

            assertEquals(EXPECTED_INSERT_RESULT, successProxyAccessLog);
        }
        
        @Test
        @DisplayName("PK에 해당하는게 있어서 UPDATE 실행 테스트")
        void updateWhenKeyExist() {
            // exist log
            // sample: 20221129,115.144.106.40,1,617,598,19,0,CC
            ProxyAccessLog proxyAccessLog = ProxyAccessLog.builder()
                    .dateNo("20221129")
                    .ip("115.144.106.40")
                    .serviceType("1")
                    .cpnCd("CC")
                    .build();

            int successProxyAccessLog = newCwsProxyInfoDao.insertSuccessProxyAccessLog(proxyAccessLog);
            int failProxyAccessLog = newCwsProxyInfoDao.insertFailProxyAccessLog(proxyAccessLog);

            assertAll(
                    () -> assertEquals(EXPECTED_UPDATE_RESULT, successProxyAccessLog),
                    () -> assertEquals(EXPECTED_UPDATE_RESULT, failProxyAccessLog)
            );
        }
    }

}
