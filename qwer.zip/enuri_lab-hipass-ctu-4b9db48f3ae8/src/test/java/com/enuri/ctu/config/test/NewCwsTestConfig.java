package com.enuri.ctu.config.test;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import javax.sql.DataSource;

@MapperScan(basePackages = "com.enuri.ctu.dao.newcws", sqlSessionFactoryRef = "newCwsTestSqlSessionFactory")
public class NewCwsTestConfig extends AbstractH2Config {

    @Bean("h2DataSource")
    @Override
    public DataSource dataSource() {
        return new HikariDataSource(h2HikariConfig());
    }

    @Bean("newCwsTestSqlSessionFactory")
    @Override
    public SqlSessionFactory sqlSessionFactory(@Qualifier("h2DataSource") DataSource dataSource,
                                                         ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        bean.setMapperLocations(applicationContext.getResources("classpath:mapper/maria-new-cws/**/*.xml"));

        return bean.getObject();
    }

    @Bean("newCwsTestSqlSessionTemplate")
    public SqlSessionTemplate sqlSessionTemplate(@Qualifier("newCwsTestSqlSessionFactory") SqlSessionFactory sessionFactory) {
        return new SqlSessionTemplate(sessionFactory);
    }
}
