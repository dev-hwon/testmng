package com.enuri.ctu.config.test;

import com.zaxxer.hikari.HikariConfig;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public abstract class AbstractH2Config {

    @Bean("h2HikariConfig")
    @ConfigurationProperties(prefix = "spring.datasource.hikari")
    public HikariConfig h2HikariConfig() {
        return new HikariConfig();
    }

    public abstract DataSource dataSource();

    public abstract SqlSessionFactory sqlSessionFactory(DataSource dataSource,
                                                         ApplicationContext applicationContext) throws Exception;

    public abstract SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sessionFactory);
}
