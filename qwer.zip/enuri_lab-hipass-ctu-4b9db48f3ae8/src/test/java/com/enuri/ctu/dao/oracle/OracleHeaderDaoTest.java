package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.vo.CtuHeaderVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OracleHeaderDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OracleHeaderDao oracleHeaderDao;

    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-header.sql");
        super.executeSql("data/data-CTU_HEADER_SET_INFO.sql");

    }

    @Test
    void fetchHeadersTest() {
        final CtuTest ctuTest = CtuTest.ONLY_FOR_CRAWLER_TEST;
        final long givenShopCode = ShopCode.COUPANG.getCode();
        final long givenGtrCode = 23781;

        List<CtuHeaderVO> ctuHeaderVOS = this.oracleHeaderDao.fetchHeaders(givenGtrCode, givenShopCode, ctuTest.getCode());

        assertAll(
                () -> assertNotNull(ctuHeaderVOS),
                () -> assertFalse(ctuHeaderVOS.isEmpty())
        );
    }
}
