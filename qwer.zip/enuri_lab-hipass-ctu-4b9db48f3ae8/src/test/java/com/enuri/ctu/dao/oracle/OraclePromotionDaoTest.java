package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.config.test.OracleElocTestConfig;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.AbstractCtuDaoTest;
import com.enuri.ctu.dto.promotion.CtuPromotionParam;
import com.enuri.ctu.vo.CtuPromotionVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Import(OracleElocTestConfig.class)
class OraclePromotionDaoTest extends AbstractCtuDaoTest {

    @Autowired
    private OraclePromotionDao oraclePromotionDao;

    private CtuPromotionParam param = CtuPromotionParam.builder()
            .shopCode(ShopCode.SSG.getCode())
            .ctuDevice(DeviceType.PC.getCode())
            .ctuService(RequestService.HOMEPAGE.getCode())
            .testCk(CtuTest.REAL_TEST.getCode())
            .build();


    @BeforeEach
    @Override
    protected void init() {
        super.executeSql("schema/schema-oracle-promotion.sql");
        super.executeSql("schema/schema-oracle-gathering.sql");
        super.executeSql("data/data-CTU_GATHERING_INFO.sql");
        super.executeSql("data/data-CTU_PROMOTION.sql");
    }

    @Test
    void saleInfoTest() {
        CtuPromotionVO saleInfo = this.oraclePromotionDao.getDbPromotionSaleInfo(this.param);

        assertAll(
                () -> assertNotNull(saleInfo),
                () -> assertEquals(303, saleInfo.getPromotionCode())
        );
    }

    @Test
    void saleRateTest() {
        CtuPromotionVO saleInfo = this.oraclePromotionDao.getDbPromotionSaleInfo(this.param);

        assertAll(
                () -> assertNotNull(saleInfo),
                () -> assertEquals(303, saleInfo.getPromotionCode())
        );
    }
}
