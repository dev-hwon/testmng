package com.enuri.ctu.config.test;

public class H2CustomFunction {

    public static Integer oracleToNumber(String value) {
        return Integer.parseInt(value);
    }
}
