package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.enuri.ctu.util.RegExpUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@RequiredArgsConstructor
public class AkMallRule implements ShopRule {

    private final SimpleWebClient simpleWebClient;

    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (deliveryMessage.contains("이상")) {
            String goodsCode = deliveryInfoParam.getOriginalPriceList().getGoodsCode();
            return this.deliveryInfoCall(goodsCode);
        }
        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    private DeliveryInfoClass deliveryInfoCall(String goodsCode) {
        String targetUrl = "https://m.akmall.com/goods/GoodsDetail.do?goods_id=" + goodsCode;
        ResponseEntity<String> responseEntity = this.simpleWebClient.get(targetUrl, null);

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        if (StringUtils.hasText(responseEntity.getBody())) {
            String htmlAkMallMobile = responseEntity.getBody();
            String regExpData = RegExpUtils
                    .getRegExpData(htmlAkMallMobile, "<li>배송비<span id=\"delivValue\">(.*?)<i>원");
            String delvPrice = regExpData.replace(",", "");
            deliveryInfoClass.setDeliveryInfo(delvPrice);
            deliveryInfoClass.setDeliveryInfo2(delvPrice);
            deliveryInfoClass.setDeliveryType2("1");
            deliveryInfoClass.setRightnLeft("2");
        }

        return deliveryInfoClass;
    }
}
