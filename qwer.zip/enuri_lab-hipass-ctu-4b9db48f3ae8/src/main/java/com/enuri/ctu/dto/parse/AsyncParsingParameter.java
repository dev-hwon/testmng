package com.enuri.ctu.dto.parse;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.vo.CtuRegExpVO;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AsyncParsingParameter {

    private ShopCode shopCode;

    private ResultDataSub resultDataSub;
    private RequestService service;
    private int interParkType;
    private DeviceType deviceType;
    private String htmlData;
    private CtuRegExpVO regExpVO;
}
