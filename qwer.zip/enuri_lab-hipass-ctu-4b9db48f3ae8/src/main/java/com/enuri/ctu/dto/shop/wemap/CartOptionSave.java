package com.enuri.ctu.dto.shop.wemap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CartOptionSave {
    private Long optNo;
    private Integer qty;
    @Builder.Default
    private String topt1Title = "";
    @Builder.Default
    private String topt1Val = "";
    @Builder.Default
    private String topt2Title = "";
    @Builder.Default
    private String topt2Val = "";

}
