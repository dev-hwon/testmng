package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.Serializable;

@Getter
@AllArgsConstructor
public class CtuHeaderVO implements Serializable {
    private Long headerCode;
    private String headerKey;
    private String headerValue;
    private Long headerOrder;
    private Long gtrCode;
    private Long shopCode;
}
