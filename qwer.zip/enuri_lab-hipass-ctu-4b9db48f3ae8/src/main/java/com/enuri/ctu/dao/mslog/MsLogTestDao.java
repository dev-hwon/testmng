package com.enuri.ctu.dao.mslog;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MsLogTestDao {

    int connectMsLogTest();
}
