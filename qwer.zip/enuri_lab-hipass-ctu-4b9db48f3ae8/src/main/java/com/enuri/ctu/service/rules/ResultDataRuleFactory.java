package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.G9Rule;
import com.enuri.ctu.service.rules.shop.HomePlusRule;
import com.enuri.ctu.service.rules.shop.InterParkRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import com.enuri.ctu.service.rules.shop.coupang.CoupangRule;
import com.enuri.ctu.service.rules.shop.timon.TimonRule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ResultDataRuleFactory {
    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;
    private final ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        InterParkRule interParkRule = this.applicationContext.getBean(InterParkRule.class);
        CoupangRule coupangRule = this.applicationContext.getBean(CoupangRule.class);
        G9Rule g9Rule = this.applicationContext.getBean(G9Rule.class);
        SsgRule ssgRule = this.applicationContext.getBean(SsgRule.class);
        TimonRule timonRule = this.applicationContext.getBean(TimonRule.class);
        HomePlusRule homePlusRule = this.applicationContext.getBean(HomePlusRule.class);

        // interpark
        RULE_MAP.put(ShopCode.INTERPARK, interParkRule);

        // coupang
        RULE_MAP.put(ShopCode.COUPANG, coupangRule);

        // g9
        RULE_MAP.put(ShopCode.G9, g9Rule);

        // ssg
        RULE_MAP.put(ShopCode.SSG_MALL, ssgRule);
        RULE_MAP.put(ShopCode.SSG_DEPT, ssgRule);

        // tmon
        RULE_MAP.put(ShopCode.TIMON, timonRule);

        // homeplus
        RULE_MAP.put(ShopCode.HOMEPLUS_DELIVERY_MALL, homePlusRule);
    }

    public ShopRule getResultDataRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            return this.defaultShopRule;
        }
        return shopRule;
    }
}
