package com.enuri.ctu.service.rules.shop.lotte;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.service.rules.shop.ShopRule;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class LotteIMallRule implements ShopRule {
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (deliveryMessage.contains("이상")) {
            Pattern pt = Pattern.compile("^(\\d+)");
            Matcher mc = pt.matcher(deliveryMessage);

            DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
            while (mc.find()) {
                String group0 = mc.group(0);
                if (group0 != null && Long.parseLong(group0) > deliveryInfoParam.getOriginalPriceList().getPrice()) {
                    Pattern ptDelvPrice = Pattern.compile("배송비(\\d+)");
                    Matcher mcDelvPrice = ptDelvPrice.matcher(deliveryMessage);

                    while (mcDelvPrice.find()) {
                        String delvPriceCondition = group0 + "원 미만 " + mcDelvPrice.group(1) + "원";
                        deliveryInfoClass.setDeliveryInfo(delvPriceCondition);
                        deliveryInfoClass.setDeliveryInfo2(mcDelvPrice.group(1));
                        deliveryInfoClass.setDeliveryType2("1");
                        deliveryInfoClass.setRightnLeft("2");
                    }

                } else {
                    deliveryInfoClass.setDeliveryInfo("무료배송");
                    deliveryInfoClass.setDeliveryInfo2("0");
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("1");
                }
            }

            return deliveryInfoClass;
        }

        // default
        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }
}
