package com.enuri.ctu.dto.parse;

import com.enuri.ctu.constant.RequestService;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ParsingDataParameter {
    private String startStr;
    private String endStr;
    private String allStr;
    private String sourceHtml;
    private RequestService service;
    private String regExpRetType;
}
