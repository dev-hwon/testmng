package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.GatheringInfoVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OracleGatheringDao {

    List<GatheringInfoVO> fetchGatheringInfoForTest(Long shopCode, String ctuDevice, String ctuService);

    List<GatheringInfoVO> fetchGatheringInfoForReal(Long shopCode, String ctuDevice, String ctuService);

}
