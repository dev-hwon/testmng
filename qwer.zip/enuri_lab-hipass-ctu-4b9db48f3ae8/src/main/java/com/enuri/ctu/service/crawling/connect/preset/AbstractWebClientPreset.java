package com.enuri.ctu.service.crawling.connect.preset;

import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.service.crawling.header.HeaderService;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;


@RequiredArgsConstructor
public abstract class AbstractWebClientPreset {
    protected static final int DEFAULT_CONNECT_TIMEOUT_MILLS = 45000;

    protected final ConnectionProvider connectionProvider;
    protected final ExchangeStrategies exchangeStrategies;
    protected final HeaderService ctuHeaderService;

    public abstract WebClient getWebClient(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, boolean isHttps);

    protected WebClient webClientConfig(HttpClient httpClient, CrawlingUnit unit){
        // set proxy connector
        ReactorClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);

        // connect with WebClient
        return WebClient.builder()
                .exchangeStrategies(this.exchangeStrategies)
                .clientConnector(connector)
                .defaultHeaders(httpHeaders -> httpHeaders.addAll(this.ctuHeaderService.getReplacedHttpHeaders(unit)))
                .build();
    }
}
