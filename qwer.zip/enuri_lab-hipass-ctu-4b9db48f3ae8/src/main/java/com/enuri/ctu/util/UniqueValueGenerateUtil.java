package com.enuri.ctu.util;

import lombok.extern.slf4j.Slf4j;

import java.security.SecureRandom;

@Slf4j
public class UniqueValueGenerateUtil {

    private UniqueValueGenerateUtil() {
        throw new IllegalStateException("Util class");
    }

    /**
     * <pre>
     *     SecureRandom 으로 생성된 정수들을 ascii 값에 대응하는 문자로 치환하여 조합
     *     filter 에서 제외된 i의 값은 ascii 코드에서 특수문자에 해당함
     *     - 58 ~ 64 : ":, ;, <, =, >, ?, @"
     *     - 91 ~ 96 : "[, \, ], ^, _, `"
     * </pre>
     * @param targetLength 만들 문자열 길이
     * @return random string
     */
    public static String generateUniqueChar(int targetLength) {
        int asciiNumeralZero = 48;
        int asciiLowerZ = 122;

        return new SecureRandom()
                .ints(asciiNumeralZero, asciiLowerZ + 1)
                .filter(i -> (i < 58 || i > 64) && (i < 91 || i > 96))
                .limit(targetLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
    }

}
