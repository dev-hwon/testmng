package com.enuri.ctu.service.crawling.connect;

import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.vo.ProxyConnectInfoVO;

public interface CtuWebClient {
    CrawlingResponse connectWithProxy(ProxyConnectInfoVO proxyConnectInfoVO, CrawlingUnit unit);

    CrawlingResponse connect(CrawlingUnit unit);
}
