package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;

class OthersConverter implements WeMapUrlConverter {
    @Override
    public ReplacedUrlLink refine(CrawlingParameter param, GatheringInfo gatheringInfo) {
        return ReplacedUrlLink.builder()
                .gtrGoodsCode("")
                .urlLink("")
                .build();
    }
}
