package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.constant.RequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class DbRegExpFactory {
    private static final Map<RequestService, DbRegExpService> SERVICE_MAP = new EnumMap<>(RequestService.class);

    private final HomePageDbRegExpService homePageDbRegExpService;
    private final OtherDbRegExpService otherDbRegExpService;

    @PostConstruct
    public void init() {
        SERVICE_MAP.put(RequestService.HOMEPAGE, this.homePageDbRegExpService);
        SERVICE_MAP.put(RequestService.OTHER, this.otherDbRegExpService);
    }

    public static DbRegExpService getService(RequestService key) {
        DbRegExpService service = SERVICE_MAP.get(key);
        if (service == null) {
            return SERVICE_MAP.get(RequestService.OTHER);
        }
        return service;
    }
}
