package com.enuri.ctu.constant;

import lombok.Getter;

@Getter
public enum ShopType {
    SMART_STORE("4", 0L);

    private final String typeCode;
    private final Long shopCode;

    ShopType(String typeCode, Long shopCode) {
        this.typeCode = typeCode;
        this.shopCode = shopCode;
    }

    public static boolean isSmartStore(String typeCode) {
        return SMART_STORE.typeCode.equals(typeCode);
    }
}
