package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.dao.oracle.OracleGatheringDao;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.vo.GatheringInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Component
public class GatheringDataHandler {

    private final OracleGatheringDao oracleGatheringDao;
    private final CtuLogDao ctuLogDao;

    @Cacheable(
            value = "GATHERING_INFO",
            key = "'fetchGatheringInfo:' + #gatheringInfo.shopCode + #gatheringInfo.ctuDevice + #gatheringInfo.ctuService"
    )
    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 2,
            backoff = @Backoff(delay = 200)
    )
    public GatheringInfoVO fetchGatheringInfo(GatheringInfo gatheringInfo, CrawlingParameter crawlingParam) {
        GatheringInfoVO gatheringInfoVO = this.fetch(gatheringInfo, crawlingParam.getCtuTest());

        if (gatheringInfoVO == null) {
            log.error("ctuGathering Not Found shopCode: {} /goodsCode: {} /service: {} /ctuDevice: {}",
                    gatheringInfo.getShopCode(), crawlingParam.getGoodsCode(), gatheringInfo.getCtuService(),
                    gatheringInfo.getCtuDevice());

            FailLog failLog = FailLog.ofCrawlingPrepare(crawlingParam);
            failLog.setCrawlingUrl("");
            failLog.setFailType(4);

            this.ctuLogDao.insertFailLog(failLog);
            throw new CtuDataNotFoundException(ResultMessageCode.FAIL_4);
        }

        return gatheringInfoVO;
    }

    private GatheringInfoVO fetch(GatheringInfo gatheringInfo, CtuTest ctuTest) {
        Long shopCode = gatheringInfo.getShopCode();
        String device = gatheringInfo.getCtuDevice();
        String service = gatheringInfo.getCtuService();

        List<GatheringInfoVO> list;
        if (CtuTest.ONLY_FOR_CRAWLER_TEST == ctuTest) {
            list = this.oracleGatheringDao.fetchGatheringInfoForTest(shopCode,device, service);


        } else {
            list = this.oracleGatheringDao.fetchGatheringInfoForReal(shopCode, device, service);
        }

        if (list.size() != 1) {
            log.error("Expected one result But found {}", list.size());
            log.error("SHOP_CODE[{}], DEVICE[{}], SERVICE[{}]", shopCode, device, service);
            return null;
        }

        return list.get(0);
    }

}
