package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.cjmall.CjMallRule;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.HomeAndShoppingRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.lotte.LotteRule;
import com.enuri.ctu.service.rules.shop.timon.TimonRule;
import com.enuri.ctu.service.rules.shop.wemap.WeMapRule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class PreParsingRuleFactory {

    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;

    private final ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        WeMapRule weMapRule = this.applicationContext.getBean(WeMapRule.class);
        LotteRule lotteRule = this.applicationContext.getBean(LotteRule.class);
        TimonRule timonRule = this.applicationContext.getBean(TimonRule.class);
        HomeAndShoppingRule homeAndShoppingRule = this.applicationContext.getBean(HomeAndShoppingRule.class);
        CjMallRule cjMallRule = this.applicationContext.getBean(CjMallRule.class);

        // wemap(6508)
        RULE_MAP.put(ShopCode.WEMAP, weMapRule);

        // lotte
        RULE_MAP.put(ShopCode.LOTTE_ON, lotteRule);
        RULE_MAP.put(ShopCode.EL_LOTTE, lotteRule);
        RULE_MAP.put(ShopCode.LOTTE_MART_MALL, lotteRule);

        // tmon(6641)
        RULE_MAP.put(ShopCode.TIMON, timonRule);

        // 홈앤쇼핑(6588)
        RULE_MAP.put(ShopCode.HOME_AND_SHOPPING, homeAndShoppingRule);

        // CJ Mall(806)
        RULE_MAP.put(ShopCode.CJ_MALL, cjMallRule);
    }

    public ShopRule getPreParseRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            shopRule = this.defaultShopRule;
        }

        return shopRule;
    }
}
