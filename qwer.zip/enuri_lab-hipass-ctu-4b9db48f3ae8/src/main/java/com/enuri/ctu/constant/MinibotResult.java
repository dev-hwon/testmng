package com.enuri.ctu.constant;

public enum MinibotResult {
    MINIBOT_X,      // 초기 상태
    MINIBOT_Z,      // 크롤링 성공 상태
    MINIBOT_D,      // 품절
    MINIBOT_Y       // 가격 업데이트
}
