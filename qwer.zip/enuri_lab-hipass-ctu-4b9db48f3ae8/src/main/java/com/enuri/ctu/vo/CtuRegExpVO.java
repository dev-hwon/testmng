package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.io.Serializable;

@Builder
@Getter
@AllArgsConstructor
public class CtuRegExpVO implements Serializable {
    private long regexpCode;
    private String regexpName;
    private String divideName;
    private String divideKeyName;
    private String divideCode;
    private String regexpStartStr;
    private String regexpEndStr;
    private String regexpAllStr;
    private String regexpRetType;
    private String regexpGetType;
    private String regexpDivis;
    private String regexpOrder;
}
