package com.enuri.ctu.exception;

import com.enuri.ctu.dto.CommonResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({CtuException.class, CtuDataNotFoundException.class})
    public <T extends CtuException> ResponseEntity<CommonResponse> handleCtuException(T e) {
        log.error("Error occurs : {}", e.getCommonResponse().getResultData());
        return ResponseEntity
                .status(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .body(e.getCommonResponse());
    }

    @ExceptionHandler(CtuRawMessageException.class)
    public String handleRawMessageException(CtuRawMessageException e) {
        log.error("Error occurs : ", e);
        return e.getResponseMessage();
    }
}
