package com.enuri.ctu.service.rules.shop.coupang;

import com.enuri.ctu.util.RegExpUtils;

class CoupangUrlConverter {
    private CoupangUrlConverter() {
        throw new IllegalStateException("util class");
    }

    static String convertUrl(String gtrUrl, String url, String goodsCode) {
        String pageKey = RegExpUtils.getRegExpData(url, "pageKey=([0-9]{1,20}.*?)&");
        String itemId = RegExpUtils.getRegExpData(url, "itemId=([0-9]{1,20}.*?)&");
        String vendorItemId = RegExpUtils.getRegExpData(url, "vendorItemId=([0-9]{1,20}.*?)");

        if ("".equals(pageKey)) {
            pageKey = RegExpUtils.getRegExpData(url, "ctag=([0-9]{1,20}.*?)&");
        }

        String urlLink = gtrUrl.replace("GTR_PAGE_KEY", pageKey);
        urlLink = urlLink.replace("GTR_ITEM_ID", itemId);
        urlLink = urlLink.replace("GTR_VENDOR_ITEM_ID", vendorItemId);
        urlLink = urlLink.replace("GTR_GOODS_CODE", goodsCode);

        return urlLink;
    }
}
