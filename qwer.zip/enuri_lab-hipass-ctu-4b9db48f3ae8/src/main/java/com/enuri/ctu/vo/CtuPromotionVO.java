package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CtuPromotionVO {
    private Long promotionCode;
    private String promotionName;
    private String priceMaxPercent;
    private String priceMinPercent;
    private String priceRegexpStr;
    private String priceCalculation;
    private String cardMaxPercent;
    private String cardMinPercent;
    private String cardRegexpStr;
    private String cardCalculation;
    private String updatePrice;
    private String updateCardPrice;
    private String updateDelvPrice;
    private String updateCoupon;
    private Long gtrCode;
    private String shopCode;
    private String status;
    private String addId;
    private String addIp;
    private String addName;
    private String addDate;
    private String modId;
    private String modIp;
    private String modName;
    private String modDate;
    private String delId;
    private String delIp;
    private String delName;
    private String delDate;
    private String promotionDivide;
    private Long promotionOrder;
    private String testCk;
    private String ctuDevice;
    private String ctuService;
    private String roundLength;
    private String roundDivide;
}
