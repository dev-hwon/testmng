package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.dao.oracle.OracleRegExpDao;
import com.enuri.ctu.dto.crawling.RegExpObj;
import com.enuri.ctu.dto.crawling.RegExpParameter;
import com.enuri.ctu.vo.CtuRegExpVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OtherDbRegExpService implements DbRegExpService {

    private final OracleRegExpDao oracleRegExpDao;

    /**
     * line: 308
     */
    @Override
    @Cacheable(
            value = "REG_EXP_LIST",
            key = "'fetchRegExpList:' + #param.gtrCode + #param.regexpDivis"
    )
    public RegExpObj fetchRegExpList(RegExpParameter param) {
        List<CtuRegExpVO> ctuRegExpVOList = this.oracleRegExpDao.fetchRegExpList(param.getGtrCode(), param.getRegexpDivis(), param.getTestCk());
        log.info("CTU REG_EXP size : {}", ctuRegExpVOList.size());

        return new RegExpObj(ctuRegExpVOList, null);
    }
}
