package com.enuri.ctu.service.pricelist.pricelimit;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.PriceListCollection;

public interface PriceLimitProcessService {
    void process(CrawlingParameter param, PriceListCollection priceListCollection, ResultDataSub resultDataSub,
                 NuriBotLog nuriBotLog, Long modelMinPrice);
}
