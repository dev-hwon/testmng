package com.enuri.ctu.dto.shop.wemap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WeMapPayload {
    @Builder.Default
    private String selectionYn = "Y";
    @Builder.Default
    private String dealYn = "N";
    private List<ProdCartSave> prodCartSave;
}
