package com.enuri.ctu.service.goods;

import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.GoodsInfoVO;
import com.enuri.ctu.vo.TblPriceListDataVO;

import java.util.List;

public interface GoodsService {

    GoodsInfoVO getMinPriceGoodsInfo(Long modelNo);

    Long getModelPopularRank(TblPriceListDataVO original);

    List<String> getExceptionPlDate(TblPriceList priceList);
}
