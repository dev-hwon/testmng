package com.enuri.ctu.service.rules.shop.lotte;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.shop.LottePayload;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor
public class LotteRuleHelper {

    private static final String LOTTE_FALLBACK_URL = "https://pbf.lotteon.com/promotion/v1/api/product/selectProductMaxFavorInforList";

    private final SimpleWebClient simpleWebClient;
    private final ObjectMapper objectMapper;

    public String fallbackCall(LottePayload payload) {
        String jsonPayload;
        try {
             jsonPayload = this.objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            log.error("Lotte Fallback payload serialize failed: {}", e.getMessage());
            throw new CtuException(ResultMessageCode.FAIL);
        }

        return this.simpleWebClient
                .post(LOTTE_FALLBACK_URL, jsonPayload, this.lotteFallbackHeaders())
                .getBody();
    }

    private HttpHeaders lotteFallbackHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36");
        httpHeaders.add("X-Requested-With", "XMLHttpRequest");
        httpHeaders.add("Content-Type", "application/json;charset=UTF-8");
        httpHeaders.add("Cookie", "_gcl_au=1.1.1947558129.1588030772; _ga=GA1.1.314679392.1588030772; _fbp=fb.1.1588030771957.1568454260; site_no=1; infw_mdia_cd=PC; infw_mall_no=4; at_check=true; AMCVS_443A1C095C0A82400A495E92%40AdobeOrg=1; aam_seg=aam_seg%3D18443080%7C18443079%7C18443078%7C18416774%7C18441945%7C18416621%7C18416620%7C18416637%7C18416629%7C18416635%7C18205142; ch_csf_cd=PA; ch_typ_cd=PA08; pcs_grp=ENRI; AMCV_443A1C095C0A82400A495E92%40AdobeOrg=-408604571%7CMCIDTS%7C18391%7CMCMID%7C09538387032373331533073741400558131489%7CMCAAMLH-1589514209%7C11%7CMCAAMB-1589514209%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1588916609s%7CNONE%7CvVersion%7C4.6.0%7CMCCIDH%7C1517268723; ch_dtl_no=1000235; ch_no=100077; crss_ntm=17; fnl_crss_rte_nm=LE; mall_no=1; mbox=PC#0a1b758dde424251bdd8456a58224d2c.28_0#1652057699|session#c34a7d52eb224cd290b139cc9f0a4f30#1588915309; _ga_4D4NCCP4FX=GS1.1.1588909409.32.1.1588913458.48");
        httpHeaders.add("referer", "https://www.lotteon.com/");

        return httpHeaders;
    }
}
