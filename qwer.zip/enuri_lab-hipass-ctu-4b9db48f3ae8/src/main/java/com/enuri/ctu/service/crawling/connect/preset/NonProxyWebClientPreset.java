package com.enuri.ctu.service.crawling.connect.preset;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.header.HeaderService;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import javax.net.ssl.SSLException;
import java.time.Duration;
import java.time.temporal.ChronoUnit;

@Component
public class NonProxyWebClientPreset extends AbstractWebClientPreset {

    @Autowired
    public NonProxyWebClientPreset(ConnectionProvider connectionProvider, ExchangeStrategies exchangeStrategies,
                                   HeaderService ctuHeaderService) {
        super(connectionProvider, exchangeStrategies, ctuHeaderService);
    }

    @Override
    public WebClient getWebClient(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, boolean isHttps) {
        final int timeOut = unit.getGatheringInfo().getGtrTimeOut();
        HttpClient httpClient = HttpClient.create(this.connectionProvider)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, DEFAULT_CONNECT_TIMEOUT_MILLS)
                .responseTimeout(Duration.of(timeOut, ChronoUnit.MILLIS))
                .httpResponseDecoder(spec -> spec.maxHeaderSize(32 * 1024))
                .secure(sslContextSpec -> {
                    if (isHttps) {
                        try {
                            SslContext sslContext = SslContextBuilder
                                    .forClient()
                                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                                    .build();
                            sslContextSpec.sslContext(sslContext);
                        } catch (SSLException e) {
                            throw new CtuException(ResultMessageCode.FAIL, "SSL Context Setting error");
                        }
                    }
                });
        return this.webClientConfig(httpClient, unit);
    }
}
