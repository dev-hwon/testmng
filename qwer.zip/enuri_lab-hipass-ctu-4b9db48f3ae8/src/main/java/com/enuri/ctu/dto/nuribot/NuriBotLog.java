package com.enuri.ctu.dto.nuribot;

import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NuriBotLog {
    private String caCode;
    private Long shopCode;
    private String regdate;
    private Long orgPrice;
    private Long upPrice;
    private Long plNo;
    private Long modelno;
    private String goodscode;
    private String url;
    private String errorCode;
    private String pageType;
    private String jobType;
    private String orgDelinfo;
    private String upDelinfo;
    private Long orgCardPrice;
    private Long upCardPrice;
    private String logoType;
    private String delFlag;
    private String priceCheck;
    private String procType;
    private String serviceDivis;
    private String serviceType;
    private Long minPrice;
    private float hasbeenPercent;
    private float hasbeenSetPercent;
    private String srvflag;
    private String regdateYmd;
    private Long popular;
    //ems 발송용
    private String shopList;
    private Long logCnt;

    public static NuriBotLog ofOriginalPriceList(TblPriceListDataVO original) {
        return NuriBotLog.builder()
                .caCode(original.getCaCode())
                .shopCode(original.getShopCode())
                .plNo(original.getPlNo())
                .modelno(original.getModelNo())
                .goodscode(original.getGoodsCode())
                .url(original.getUrl())
                .build();
    }
}
