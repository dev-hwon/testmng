package com.enuri.ctu.service.parse;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;

public interface ParsingService {

    ResultDataSub parse(CrawlingParameter param, CrawlingUnit unit, String crawlingResult);
}
