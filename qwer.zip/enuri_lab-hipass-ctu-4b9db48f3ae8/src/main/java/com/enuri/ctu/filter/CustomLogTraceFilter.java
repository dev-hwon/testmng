package com.enuri.ctu.filter;

import com.enuri.ctu.util.UniqueValueGenerateUtil;
import org.slf4j.MDC;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

public class CustomLogTraceFilter implements Filter {

    private static final String TRACE_ID = "TRACE-ID";
    private static final int TRACE_ID_SIZE = 12;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        // before
        final String traceId = UniqueValueGenerateUtil.generateUniqueChar(TRACE_ID_SIZE);
        MDC.put(TRACE_ID, traceId);

        // do
        chain.doFilter(request, response);

        // after
        MDC.clear();
    }
}
