package com.enuri.ctu.config.datasource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * <pre>
 *      MS Log DataSource
 *      property : spring.datasource.hikari.ms-log
 *      mapper : resources/mapper/ms-log
 *      dao : com.enuri.ctu.dao.mslog
 * </pre>
 */
@Configuration
@MapperScan(basePackages = "com.enuri.ctu.dao.mslog", sqlSessionFactoryRef = "msLogSqlSessionFactory")
public class MsLogDataSourceConfig {
    @Bean
    @Qualifier("msLogHikariConfig")
    @ConfigurationProperties(prefix = "spring.datasource.hikari.ms-log")
    public HikariConfig msLogHikariConfig() {
        return new HikariConfig();
    }

    @Bean
    @Qualifier("msLogDataSource")
    public DataSource msLogDataSource() {
        return new HikariDataSource(msLogHikariConfig());
    }

    @Bean
    @Qualifier("msLogSqlSessionFactory")
    public SqlSessionFactory msLogSqlSessionFactory(@Qualifier("msLogDataSource") DataSource dataSource,
                                                   ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        factoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        factoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/ms-log/**/*.xml"));
        factoryBean.setVfs(SpringBootVFS.class);

        return factoryBean.getObject();
    }

    @Bean
    @Qualifier("msLogSqlSessionTemplate")
    public SqlSessionTemplate msLogSqlSessionTemplate(
            @Qualifier("msLogSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
