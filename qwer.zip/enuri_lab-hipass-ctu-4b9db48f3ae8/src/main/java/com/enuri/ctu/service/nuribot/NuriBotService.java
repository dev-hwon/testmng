package com.enuri.ctu.service.nuribot;

import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.vo.TblPriceListDataVO;

public interface NuriBotService {

    void setSoldOutLog(NuriBotLog nuriBotLog, boolean isEqualPrice);

    void setPriceLog(NuriBotLog nuriBotLog, MsSqlPriceList priceListLog, TblPriceListDataVO originalPriceList,
                     Long cardPrice);
}
