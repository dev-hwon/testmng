package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.GoodsInfoVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleGoodsDao {

    // getDbTblGoodsInfo
    GoodsInfoVO fetchMinPriceGoodsInfo(long modelNo);

    Long fetchModelRank(String caCode, long modelNo);
}
