package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.constant.ShopType;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.vo.AutoTestLogVO;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.Builder;
import lombok.Data;
import org.springframework.util.StringUtils;

/**
 * (enuriCTU_v2.1) CtuProcessLog.java
 */
@Data
@Builder
public class CrawlingParameter {
    private Long logSeq;
    private CtuTest ctuTest;
    private DeviceType device;
    private RequestService service;
    private String systemType;
    private Long shopCode;
    private String shopName;
    private String goodsCode;
    private String plNo;
    private String oldValue;
    private String newValue;
    private String divis;
    private String divideName;
    private String cateCode1;
    private String cateCode2;
    private String cateCode3;
    private String cateCode4;
    private String cateName1;
    private String cateName2;
    private String cateName3;
    private String cateName4;
    private String regexpText;
    private String returnData;
    private String agentCode;
    private String procStatus;
    private String logYmd;
    private String logTime;
    private String logIp;
    private String status;
    private String addId;
    private String addName;
    private String addDate;
    private String url;
    private String cpSection1; //#SR 31231
    private String shopType;
    private Long modelNo; //SR41238
    private String goodsNm; //SR41476

    // 아래는 개발상 필요하여 추가
    private IpType ipType;
    private AutoTestLogDto autoTestLog;
    private AutoTestLogVO autoTestTbl;
    private TblPriceListDataVO tblPriceListData;

    public static CrawlingParameter of(CtuParamVOWrapper vo, TblPriceListDataVO pl, AutoTestLogDto autoTestLog,
                                       AutoTestLogVO autoTestTbl) {
        long paramShopCode = Long.parseLong(vo.getShopCode());
        ShopCode shop = ShopCode.getShopCode(paramShopCode);

        // 일치하는 shop_code가 없고 shop_type == 4 이면 smart store
        if (ShopType.isSmartStore(vo.getShopType())) {
            shop = ShopCode.SMART_STORE;
        }

        if (StringUtils.hasText(pl.getUrl()) && pl.getUrl().contains("department.ssg.com")) {
            shop = ShopCode.SSG_DEPT;
        }

        String divideCode = null;
        if (vo.getDivis() != null) {
            divideCode = vo.getDivis().getCode();
        }

        CrawlingParameter crawlingParameter = CrawlingParameter.builder()
                .shopCode(paramShopCode)
                .goodsCode(vo.getGoodsCode())
                .goodsNm(pl.getGoodsNm())
                .plNo(vo.getPriceListNo())
                .service(vo.getServiceFrom())
                .device(vo.getDevice())
                .ctuTest(vo.getCtuTest())
                .divis(divideCode)
                .logIp(vo.getUserIp())
                .url(pl.getUrl())
                .shopType(vo.getShopType())
                .systemType(vo.getSystemType())
                .ipType(vo.getIpType())
                .autoTestLog(autoTestLog)
                .autoTestTbl(autoTestTbl)
                .tblPriceListData(pl)
                .build();

        if (ShopCode.WEMAP == shop) {
            crawlingParameter.setModelNo(pl.getModelNo());
        }

        if (Boolean.TRUE.equals(IpType.isLocal(vo.getIpType())) && ShopCode.SMART_STORE == shop) {
            crawlingParameter.setShopType(ShopType.SMART_STORE.getTypeCode());
            crawlingParameter.setShopCode(pl.getShopCode());
        }

        if (StringUtils.hasText(pl.getCaCode())) {
            crawlingParameter.setCateCode1(pl.getCaCode());
        }

        return crawlingParameter;
    }

    public boolean isRealTest() {
        return CtuTest.REAL_TEST == this.ctuTest;
    }
}
