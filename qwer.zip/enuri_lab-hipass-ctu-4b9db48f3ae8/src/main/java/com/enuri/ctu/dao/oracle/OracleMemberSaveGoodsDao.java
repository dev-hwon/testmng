package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.GoodsCodeVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OracleMemberSaveGoodsDao {

    List<Long> fetchMemberModelNo(int from, int to);
    List<Long> fetchAllMemberModelNo();

    int truncateWorkingTable();

    int insertModelNoToWorkingTable();

    List<GoodsCodeVO> fetchGoodsCodeByModelNo(long modelNo);

    List<Long> fetchModelNoByRegDate(int days);
}
