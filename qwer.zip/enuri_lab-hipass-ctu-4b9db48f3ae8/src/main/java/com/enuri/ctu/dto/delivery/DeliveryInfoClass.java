package com.enuri.ctu.dto.delivery;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class DeliveryInfoClass {
    private String deliveryInfo;
    private String deliveryInfo2;
    private String deliveryType2;
    private String rightnLeft;
}
