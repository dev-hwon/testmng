package com.enuri.ctu.service.parse;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.service.rules.PreParsingRuleFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * line: 485 ~ 556
 * </pre>
 * 
 * 파싱결과를 가지고 쇼핑몰별 사전 예외 처리 작업
 */
@Service
@RequiredArgsConstructor
public class PreParsingByShopCodeService implements PreParsingService {

    private final PreParsingRuleFactory preParsingRuleFactory;

    @Override
    public ParsingResult preParse(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        final ShopCode shopCode = ShopCode.getShopCode(param.getShopCode());
        return this.preParsingRuleFactory
                .getPreParseRule(shopCode)
                .beforeParsing(param, unit, crawlingResult);
    }
}
