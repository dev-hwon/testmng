package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class GsShopRule implements ShopRule {

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 221 ~ 266
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (!deliveryMessage.contains("이상") || !deliveryMessage.contains("미만")) {
            return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
        }

        Pattern pattern = Pattern.compile("(?:\\d*\\.)?\\d+");
        Matcher matcher = pattern.matcher(deliveryMessage);

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        while (matcher.find()) {
            String delvFreePrice = matcher.group(0);

            if (delvFreePrice != null && Long.parseLong(delvFreePrice) > deliveryInfoParam.getOriginalPriceList().getPrice()) {
                Pattern delvPricePattern = Pattern.compile("미만배송비(\\d+)\\)");
                Matcher delvPriceMatcher = delvPricePattern.matcher(deliveryMessage);

                while (delvPriceMatcher.find()) {
                    if (Long.parseLong(delvFreePrice) > deliveryInfoParam.getOriginalPriceList().getPrice()) {
                        deliveryInfoClass.setDeliveryInfo(delvPriceMatcher.group(1));
                        deliveryInfoClass.setDeliveryInfo2(delvPriceMatcher.group(1));
                        deliveryInfoClass.setDeliveryType2("1");
                        deliveryInfoClass.setRightnLeft("2");
                    }
                }

            } else {
                deliveryInfoClass.setDeliveryInfo("무료배송");
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("1");
            }
        }

        return deliveryInfoClass;
    }
}
