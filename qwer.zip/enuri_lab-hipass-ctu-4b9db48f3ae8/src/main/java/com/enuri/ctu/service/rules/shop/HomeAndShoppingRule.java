package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.util.RegExpUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class HomeAndShoppingRule implements ShopRule {

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 541 ~ 544
     * </pre>
     */
    @Override
    public ParsingResult beforeParsing(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        DeviceType deviceType = param.getDevice();
        boolean isSoldOut;
        if (DeviceType.PC == deviceType) {
            // pc
            isSoldOut = this.isPcSoldOut(crawlingResult);
        } else {
            //mobile
            isSoldOut = this.isMobileSoldOut(crawlingResult);
        }

        ResultDataSub resultDataSub = new ResultDataSub();
        if (isSoldOut) {
            resultDataSub.setSoldOut("1");
        }

        return ParsingResult.builder()
                .ctuHtmlData(crawlingResult)
                .resultDataSub(resultDataSub)
                .build();
    }

    private boolean isPcSoldOut(String crawlingResult) {
        final String startTag = "<div class=\"select_box\" id=\"selGoods\"><span>상품을 선택해주세요.</span>";
        final String endTag = "<div class=\"select_box type2\" id=\"selGoodsDt\" style=\"display:none;\">";

        if (crawlingResult.contains(startTag)) {
            String sub = crawlingResult.substring(crawlingResult.indexOf(startTag), crawlingResult.indexOf(endTag));
            int optionCount = sub.split("<a herf=").length - 1;
            int soldOutCount = sub.split("unit=\"soldOut\"").length - 1;

            return this.compare(soldOutCount, optionCount);
        }

        return false;
    }

    private boolean isMobileSoldOut(String crawlingResult) {
        final String startTag = "<div class=\"select_list hns_select_option_list\" id=\"selGoodsList\">";
        final String endTag = "<div class=\"layer_price\" id=\"orderPriceElement2\" style=\"display:none;\">";

        if (crawlingResult.contains(startTag)) {
            String sub = crawlingResult.substring(crawlingResult.indexOf(startTag), crawlingResult.indexOf(endTag));
            String optionCountStr = RegExpUtils.getRegExpData(crawlingResult, "\"goodsNumber\":\"(.*?)\"");

            int soldOutCount = sub.split("unit=\"soldOut\"").length - 1;
            int optionCount = 1;
            if (StringUtils.hasText(optionCountStr)) {
                optionCount = Integer.parseInt(optionCountStr);
            }

            return this.compare(soldOutCount, optionCount);
        }

        return false;
    }

    private boolean compare(int soldOutCount, int optionCount) {
        return soldOutCount > 0 && (optionCount == soldOutCount);
    }
}
