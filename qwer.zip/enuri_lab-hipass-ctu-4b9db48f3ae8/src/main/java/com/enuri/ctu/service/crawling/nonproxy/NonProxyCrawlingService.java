package com.enuri.ctu.service.crawling.nonproxy;

import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.service.crawling.CrawlingService;
import com.enuri.ctu.service.crawling.connect.CtuWebClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class NonProxyCrawlingService implements CrawlingService {

    private final CtuWebClient webClient;

    @Override
    public CrawlingResponse crawling(CrawlingUnit unit) {
        // call
        return this.webClient.connect(unit);
    }
}
