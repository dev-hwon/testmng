package com.enuri.ctu.service.savegoods;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;

public interface SaveGoodsService {
    void saveGoodsProcess(CtuTest ctuTest, IpType ipType);
}
