package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MsSqlPriceListVO {

    private Long plNo;
    private Long plModelNo;
    private String plStatus;
}
