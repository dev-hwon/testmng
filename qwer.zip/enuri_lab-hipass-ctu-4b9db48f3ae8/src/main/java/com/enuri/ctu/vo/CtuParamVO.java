package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;


@Data
@Builder
@AllArgsConstructor
@SuppressWarnings("java:S116")
public class CtuParamVO {

    @NotBlank(message = "ctu_test param NotFound")
    private String ctu_test;   	    // TEST 유무 ( Y: 테스트 , N: 정상 )

    @NotBlank(message = "shop_code param NotFound")
    private String shop_code;	        // 타겟몰 업체 코드

    @NotBlank(message = "goods_code param NotFound")
    private String goods_code;	    // 타겟몰 기준 상품 코드

    private String pl_no;		        // 에누리 기준 pricelist 코드

    private String divis;		        // 테스트 구분값 (1:판매가, 2:할인가... CTU_PARSE_DIVIDE_INFO 참조

    @NotBlank(message = "device param NotFound")
    private String device;		    // 디바이스 구분 ( 1:PC, 2:모바일 )

    @NotBlank(message = "service param NotFound")
    private String service;		    // CTU호출 출발지 서비스 구분 (  1:홈페이지, 2:소셜비교, 3:해외몰타겟,4:ETC, 5: SDUL서비스, 6:DEAL, 7:알툴바 가격백신, 8:DW크롤링 )

    private String user_ip;		    // 사용자 아이피

    private String server_ip;	        // 서버 아이피

    private String system_type;       // 시스템 타입 ( 1:MiniBot, 2:MP, 3:wwwCtu, 4:MobileCtu, 5:SDUL, 6:Etc-미정, 8:miniMP )

    private String user_id;

    private String user_name;

    private String goods_url;	        // 상품 상세 링크 ( 해당 타겟몰 기준 상세 링크 정 - Deal서비스 목적으로 새로 생성됨 )

    private String goods_seq;         // Deal 상품 전용 유니크 코드

    private String shop_type;         // 스마트스토어 : 4

    @NotEmpty(message = "not allowed ip_type")
    private String ip_type;            // ipType

    private String cp_pid;

    private String cp_id;

}
