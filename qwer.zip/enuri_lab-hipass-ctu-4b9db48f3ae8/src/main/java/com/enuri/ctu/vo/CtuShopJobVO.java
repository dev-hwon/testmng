package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CtuShopJobVO {
    private Long shopCode;
    private String shopName;
    private Boolean priceYn;
    private Boolean cardPriceYn;
    private Boolean deliveryYn;
    private Boolean couponYn;
    private Boolean mobileYn;
    private Boolean soldYn;
    private Boolean adultYn;
}
