package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.util.CommonUtil;
import com.enuri.ctu.util.RegExpUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class HomePlusRule implements ShopRule {

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        final String targetWord = "GTR_STORE_TYPE";
        final String str = "storeType%3D";

        String replaced = gatheringInfo.getGtrUrl()
                .replace(targetWord, param.getUrl().substring(param.getUrl().indexOf(str) + str.length()));

        return ReplacedUrlLink.builder()
                .urlLink(replaced)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 86 ~ 100
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        if (deliveryInfoParam.getDeliveryMessage().equals("0")) {
            return DeliveryInfoClass.builder()
                    .deliveryInfo("무료배송")
                    .deliveryInfo2("0")
                    .deliveryType2("1")
                    .rightnLeft("1")
                    .build();
        }
        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service, CrawlingUnit unit) {
        if (resultDataSub.getSoldOut() == null && resultDataSub.getInstChargePrice() != null) {
            String instChargePrice = (String) resultDataSub.getInstChargePrice();

            try {
                long saleUnit = Long.parseLong(RegExpUtils.getRegExpData(instChargePrice, "\"saleUnit\":(.*?)\""));
                long stockQty = Long.parseLong(RegExpUtils.getRegExpData(instChargePrice, "\"stockQty\":(.*?)\""));
                long purchaseMinQty = this.getPurchaseQty(instChargePrice);

                if (stockQty < saleUnit || stockQty < purchaseMinQty) {
                    resultDataSub.setSoldOut("1");
//                resultDataSub.setLog ?
                }
            } catch (NumberFormatException nfe) {
                log.error("HomePlus instChargePrice Number Format Error : {}", instChargePrice);
            }
        }
    }

    private long getPurchaseQty(String str) {
        String extractPurchaseMinQty = RegExpUtils.getRegExpData(str, "\"purchaseMinQty\":(.*?)\"");
        if (CommonUtil.isNumeric(extractPurchaseMinQty)) {
            return Long.parseLong(extractPurchaseMinQty);
        }

        extractPurchaseMinQty = RegExpUtils.getRegExpData(str, "\"purchaseMinQty\":(.*?)");
        if (CommonUtil.isNumeric(extractPurchaseMinQty)) {
            return Long.parseLong(extractPurchaseMinQty);
        }

        return 0L;
    }
}
