package com.enuri.ctu.config.datasource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * <pre>
 *      MariaDb New-CWS DataSource
 *      property : spring.datasource.hikari.maria-new-cws
 *      mapper : resources/mapper/maria-new-cws
 *      dao : com.enuri.ctu.dao.newcws
 * </pre>
 */
@Configuration
@MapperScan(basePackages = "com.enuri.ctu.dao.newcws", sqlSessionFactoryRef = "newCwsSqlSessionFactory")
public class MariaNewCwsDataSourceConfig {
    @Bean
    @Qualifier("newCwsHikariConfig")
    @ConfigurationProperties(prefix = "spring.datasource.hikari.maria-new-cws")
    public HikariConfig newCwsHikariConfig() {
        return new HikariConfig();
    }

    @Bean
    @Qualifier("newCwsDataSource")
    public DataSource newCwsDataSource() {
        return new HikariDataSource(newCwsHikariConfig());
    }

    @Bean
    @Qualifier("newCwsSqlSessionFactory")
    public SqlSessionFactory newCwsSqlSessionFactory(@Qualifier("newCwsDataSource") DataSource dataSource,
                                                   ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        factoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        factoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/maria-new-cws/**/*.xml"));
        factoryBean.setVfs(SpringBootVFS.class);

        return factoryBean.getObject();
    }

    @Bean
    @Qualifier("newCwsSqlSessionTemplate")
    public SqlSessionTemplate newCwsSqlSessionTemplate(
            @Qualifier("newCwsSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
