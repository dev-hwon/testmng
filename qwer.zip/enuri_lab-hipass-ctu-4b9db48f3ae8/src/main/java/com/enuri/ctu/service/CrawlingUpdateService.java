package com.enuri.ctu.service;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dao.oracle.OraclePriceListDataHandler;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.dto.CrawlProcessResult;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.exception.CtuRawMessageException;
import com.enuri.ctu.service.autotest.AutoTestService;
import com.enuri.ctu.service.cache.CacheService;
import com.enuri.ctu.service.crawling.ResultCheckService;
import com.enuri.ctu.service.crawling.proxy.ProxyCrawlingService;
import com.enuri.ctu.service.crawling.proxy.ProxyPrepareService;
import com.enuri.ctu.service.parse.ParsingService;
import com.enuri.ctu.service.rules.CheckPriceListRuleFactory;
import com.enuri.ctu.vo.AutoTestLogVO;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * <pre>
 * package: com.enuri.service
 * class file: CtuService.java
 * </pre>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CrawlingUpdateService implements ClickToUpdateService {

    private final ProxyCrawlingService proxyCrawlingService;
    private final ProxyPrepareService proxyPrepareService;
    private final ResultCheckService resultCheckService;
    private final ParsingService parsingService;
    private final CacheService cacheService;
    private final AutoTestService autoTestService;
    private final CheckPriceListRuleFactory checkPriceListRuleFactory;
    private final OraclePriceListDataHandler oraclePriceListDataHandler;

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 123 ~ 1081
     * </pre>
     */
    @Override
    public CrawlProcessResult crawling(CtuParamVOWrapper paramVO) {
        
        // 중복 호출 로직(line: 151 ~ 176)
        if (this.shouldCheckCache(paramVO.getIpType(), paramVO.getSystemType())) {
            log.info("Redis Check : IP_TYPE[{}], SYSTEM[{}]", paramVO.getIpType(), paramVO.getSystemType());
            if (this.cacheService.isDuplicated(paramVO)) {
                // throw duplicate result
                throw new CtuException(ResultMessageCode.DUPLICATE_CALL, paramVO.getValueForLogging());
            }

            this.cacheService.caching(paramVO);
        }

        // fetch TBL_PRICELIST
        CrawlingParameter crawlingParameter = this.getCrawlingParameter(paramVO);
        log.debug("CrawlingParameter : {}", crawlingParameter.toString());

        // pre-process before crawling
        CrawlingUnit crawlingUnit = this.proxyPrepareService.getCrawlingUnit(crawlingParameter);

        // crawling
        CrawlingResponse crawlingResponse = this.proxyCrawlingService.crawling(crawlingUnit);
        log.info("Crawling Result : HTTP_STATUS[{}]", crawlingResponse.getHttpStatus().toString());

        // crawlingResponse is empty?
        CommonResponse commonResponse = this.resultCheckService.checkCrawlingResponse(crawlingParameter, crawlingUnit,
                crawlingResponse);

        // parsing -> resultDataSub
        ResultDataSub resultDataSub = this.parsingService.parse(crawlingParameter, crawlingUnit,
                crawlingResponse.getHtmlContent());

        // check resultDataSub
        this.resultCheckService.checkResultDataSub(crawlingParameter, crawlingUnit, commonResponse, resultDataSub);
        return new CrawlProcessResult(crawlingParameter, commonResponse);
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 214
     *
     * 1. (oracle)TBL_PRICELIST 에서 데이터 조회
     * 2. request parameter vo -> dto
     * </pre>
     */
    public CrawlingParameter getCrawlingParameter(CtuParamVOWrapper paramVO) {
        final String goodsCode = paramVO.getGoodsCode();
        final String plNoString = paramVO.getPriceListNo();
        final Long shopCode = this.shopCodePreProcess(Long.parseLong(paramVO.getShopCode()), goodsCode);

        // fetch TBL_PRICELIST data
        log.info("Fetch TBL_PRICELIST : SHOP_CODE[{}], GOODS_CODE[{}], PL_NO[{}]", shopCode, goodsCode, plNoString);
        TblPriceListDataVO priceListData = this.oraclePriceListDataHandler
                .getOriginalPriceList(shopCode, goodsCode, plNoString);

        // default init
        AutoTestLogDto autoTestLog = AutoTestLogDto.builder()
                .testCode(0L)
                .build();
        AutoTestLogVO autoTestTbl = new AutoTestLogVO();
        if (CtuTest.REAL_TEST == paramVO.getCtuTest() && StringUtils.hasText(paramVO.getUserName())) {
            long testCode = Long.parseLong(paramVO.getUserName());

            if (priceListData == null) {
                log.info("Not found Data In Oracle TblPriceList shopCode: {}",paramVO.getValueForLogging());

                autoTestLog.setTestCode(testCode);
                autoTestTbl = this.autoTestService.fetchAutoTestTbl(testCode);
                this.autoTestService.updateAutoTestNoProduct(autoTestLog, autoTestTbl, paramVO.getDevice());
            }

            if (SystemType.isMiniBot(paramVO.getSystemType())) {
                throw new CtuRawMessageException("X");
            }
        }

        if (priceListData == null) {
            log.error("Not found Data In Oracle TblPriceLIst shopCode: {}, /plNo: {}, /goodsCode: {}",
                    shopCode, plNoString, goodsCode);
            throw new CtuDataNotFoundException(ResultMessageCode.FAIL_21);
        }

        this.checkOriginalPriceList(paramVO, priceListData);

        log.info("TBL_PRICELIST : {}", priceListData);

        // CtuParamVO -> CrawlingParameter
        return CrawlingParameter.of(paramVO, priceListData, autoTestLog, autoTestTbl);
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 151
     *
     * Redis Repository 실행 조건 판별
     * </pre>
     */
    private boolean shouldCheckCache(IpType ipType, String systemType) {
        return IpType.PRODUCTION == ipType && SystemType.WEB_TEST_PAGE != SystemType.getSystemType(systemType);
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 256 ~ 273
     * </pre>
     *
     */
    private void checkOriginalPriceList(CtuParamVOWrapper paramVO, TblPriceListDataVO originalPriceList) {
        ShopCode shopCode = ShopCode.getShopCode(Long.parseLong(paramVO.getShopCode()));

        log.debug("Original TBL_PRICELIST Check by Shop[{} - {}]", shopCode.name(), shopCode.getCode());
        ResultMessageCode resultMessageCode = this.checkPriceListRuleFactory.getCheckOriginalPriceListRule(shopCode)
                .checkOriginalPriceList(originalPriceList);

        if (resultMessageCode != null) {
            log.error("{} : {}", resultMessageCode.getMessage() ,paramVO.getValueForLogging());
            throw new CtuException(resultMessageCode);
        }

        log.debug("Original TBL_PRICELIST Check Passed");
    }

    private long shopCodePreProcess(long shopCode, String goodsCode) {
        if (ShopCode.SMART_STORE == ShopCode.getShopCode(shopCode) && StringUtils.hasText(goodsCode)) {
            Long smartStoreShopCode = this.oraclePriceListDataHandler.getSmartStoreShopCode(goodsCode);
            return smartStoreShopCode == null? 0L : smartStoreShopCode;
        }

        return shopCode;
    }
}
