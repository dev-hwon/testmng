package com.enuri.ctu.dto.pricelist;

import lombok.Getter;

@Getter
public class PriceListCollection {
    private final TblPriceList priceList;
    private final TblPriceList oraclePriceList;
    private final MsSqlPriceList sqlPriceList;
    private final MsSqlPriceList priceListLog;

    public PriceListCollection(TblPriceList priceList, TblPriceList oraclePriceList, MsSqlPriceList sqlPriceList,
                               MsSqlPriceList priceListLog) {
        this.priceList = priceList;
        this.oraclePriceList = oraclePriceList;
        this.sqlPriceList = sqlPriceList;
        this.priceListLog = priceListLog;
    }

}
