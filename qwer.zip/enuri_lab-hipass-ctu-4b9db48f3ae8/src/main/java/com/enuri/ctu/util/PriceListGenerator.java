package com.enuri.ctu.util;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.TblPriceListDataVO;
import org.springframework.util.StringUtils;

public class PriceListGenerator {
    private PriceListGenerator() {
        throw new IllegalStateException("Util Class");
    }

    public static TblPriceList ofParam(CrawlingParameter param, TblPriceListDataVO originalPriceList,
                                       ResultDataSub resultDataSub) {

        TblPriceList priceList = TblPriceList.builder()
                .shopCode(param.getShopCode())
                .build();

        if (StringUtils.hasText(param.getGoodsCode())) {
            priceList.setGoodscode(param.getGoodsCode());
        }

        if (StringUtils.hasText(param.getPlNo())) {
            priceList.setPlNo(Long.parseLong(param.getPlNo()));
        }

        if (resultDataSub.getNormalPrice() != null) {
            priceList.setPrice(Long.parseLong(resultDataSub.getNormalPrice().toString()));
        }

        if (resultDataSub.getSalePrice() != null) {
            priceList.setPrice(Long.parseLong(resultDataSub.getSalePrice().toString()));
        }

        if (resultDataSub.getCardPrice() != null) {
            Object cardPriceObj = resultDataSub.getCardPrice();
            priceList.setPriceCard(Long.parseLong(cardPriceObj.toString()));

            if (resultDataSub.getSalePrice() == null && resultDataSub.getNormalPrice() == null) {
                priceList.setPrice(originalPriceList.getPrice());
            }
        }

        if (resultDataSub.getDeliveryPrice() != null) {
            String deliveryPrice = resultDataSub.getDeliveryPrice().toString();
            priceList.setDelvValue(deliveryPrice);
        }

        if (resultDataSub.getSaleRate() != null) {
            priceList.setEtc(resultDataSub.getSaleRate().toString());
        }

        if (resultDataSub.getSoldOut() != null) {
            priceList.setSrvflag(resultDataSub.getSoldOut().toString());
        }

        if (resultDataSub.getCoupon() != null) {
            priceList.setCoupon(Long.parseLong(resultDataSub.getCoupon().toString()));
        }

        return priceList;
    }

    public static TblPriceList copyForOracle(TblPriceListDataVO origin) {
        return TblPriceList.builder()
                .srvflag(origin.getSrvflag())
                .plNo(origin.getPlNo())
                .shopCode(origin.getShopCode())
                .goodsbrand(origin.getGoodsCode())
                .coupon(origin.getCoupon())
                .build();
    }

    public static MsSqlPriceList copyForMsSql(TblPriceListDataVO origin) {
        return MsSqlPriceList.builder()
                .plNo(origin.getPlNo())
                .plGoodscode(origin.getGoodsCode())
                .plVcode(origin.getShopCode())
                .build();
    }
}
