package com.enuri.ctu.service.pricelist;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dao.eloc.MsSqlElocPriceListDao;
import com.enuri.ctu.dao.oracle.OracleNuriBotLogDao;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.autotest.AutoTestService;
import com.enuri.ctu.vo.MsSqlPriceListVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class CtuPriceListUpdateService implements PriceListUpdateService {

    private final MsSqlElocPriceListDao msPriceListDao;
    private final OracleNuriBotLogDao oracleNuribotLogDao;
    private final AutoTestService autoTestService;

    /**
     * <pre>
     * source: com.enuri.service.CtuService::NuribotElocLogDao.java
     * line: 1749 ~ 1790
     *
     * SR43750 - 크롤링 결과 품절이 아니고, 오라클 status와 eloc status 싱크가 맞지 않을때, 오라클 status값 기준으로 eloc status값 update
     * </pre>
     */
    @Override
    @LoggingProcessTime
    public void sync(TblPriceListDataVO originalPriceList, MsSqlPriceList priceListLog, NuriBotLog nuriBotLog) {
        if (originalPriceList.getPlNo() == null) {
            return;
        }

        MsSqlPriceListVO msSqlData = this.msPriceListDao.fetchPriceListData(originalPriceList.getPlNo());
        if (msSqlData == null) {
            log.error("MSSQL_PRICELIST is NULL : ORA_PL_NO[{}]", originalPriceList.getPlNo());
            return;
        }

        final String status = msSqlData.getPlStatus();
        if (status == null) {
            log.error("PL_STATUS is NULL : ORA_PL_NO[{}]", originalPriceList.getPlNo());
            return;
        }

        boolean isEqualStatus = originalPriceList.getStatus().equals(status);
        List<String> allowedStatus = Arrays.asList("0", "5");

        // 데이터 불일치할때만
        if (allowedStatus.contains(status) && !isEqualStatus) {
            MsSqlPriceList msSqlPriceList = MsSqlPriceList.builder()
                    .plGoodscode(originalPriceList.getGoodsCode())
                    .plStatus(originalPriceList.getStatus())
                    .plNo(originalPriceList.getPlNo())
                    .plModelno(originalPriceList.getModelNo())
                    .plVcode(originalPriceList.getShopCode())
                    .build();

            // 오라클데이터 기준으로 eloc 업데이트
            this.msPriceListDao.updateStatus(msSqlPriceList);

            if ("5".equals(status)) {
                nuriBotLog.setLogoType("6");
            } else {
                nuriBotLog.setLogoType("7");
            }

            // 히스토리 테이블 넣기
            if (priceListLog.validNotExceptionPlNo()) {
                this.msPriceListDao.setDbLogListProc(priceListLog);
            } else {
                Long logPlNo = priceListLog.getPlNo();
                Integer modelNoKey = this.msPriceListDao.fetchModelNoKey(logPlNo);
                if (modelNoKey != null && modelNoKey != 0) {
                    this.msPriceListDao.setDbLogProc(logPlNo, modelNoKey);
                }
            }
        }
    }

    @Override
    @LoggingProcessTime
    public void deliveryInfoUpdate(PriceListCollection priceListCollection, CrawlingParameter crawlingParameter,
                                   NuriBotLog nuriBotLog, ResultDataSub resultDataSub) {

        TblPriceListDataVO originalPriceList = crawlingParameter.getTblPriceListData();
        if (this.checkDeliveryInfo(priceListCollection, resultDataSub, crawlingParameter.getShopCode(), originalPriceList)) {
            return;
        }

        MsSqlPriceList sqlPriceList = priceListCollection.getSqlPriceList();
        MsSqlPriceList priceListLog = priceListCollection.getPriceListLog();
        TblPriceList oraclePriceList = priceListCollection.getOraclePriceList();

        this.msPriceListDao.setDbPriceListDelvUpdate(sqlPriceList);
        this.msPriceListDao.setDbPlDateUpdate(sqlPriceList);
        Long logPlNo = priceListLog.getPlNo();
        Integer modelNoKey = this.msPriceListDao.fetchModelNoKey(logPlNo);
        if (modelNoKey != null && modelNoKey != 0) {
            this.msPriceListDao.setDbLogProc(logPlNo, modelNoKey);
        }

        // 배송비 로그
        nuriBotLog.setOrgDelinfo(originalPriceList.getDeliveryInfo());
        nuriBotLog.setUpDelinfo(oraclePriceList.getDeliveryinfo());
        nuriBotLog.setLogoType("3");
        nuriBotLog.setServiceType("1");

        // system_type : /* 시스템 타입 ( 1:MiniBot, 2:MP, 3:wwwCtu, 4:MobileCtu, 5:SDUL, 6:Etc-미정 )
        String serviceDivis = SystemType.getServiceDivisBySystemType(crawlingParameter.getSystemType());
        nuriBotLog.setServiceDivis(serviceDivis);

        this.oracleNuribotLogDao.setDbNuribotDeliveryLogInsert(nuriBotLog);
    }

    @Override
    public void couponUpdate(PriceListCollection priceListCollection, CrawlingParameter crawlingParameter,
                             NuriBotLog nuriBotLog, ResultDataSub resultDataSub) {

        if (resultDataSub.getCoupon() == null) {
            return;
        }

        MsSqlPriceList sqlPriceList = priceListCollection.getSqlPriceList();
        MsSqlPriceList priceListLog = priceListCollection.getPriceListLog();
        sqlPriceList.setPlCoupon(priceListCollection.getPriceList().getCoupon());
        this.msPriceListDao.setDbCouponProc(sqlPriceList);
        Long logPlNo = priceListLog.getPlNo();
        Integer modelNoKey = this.msPriceListDao.fetchModelNoKey(logPlNo);
        if (modelNoKey != null && modelNoKey != 0) {
            this.msPriceListDao.setDbLogProc(logPlNo, modelNoKey);
        }

        nuriBotLog.setOrgPrice(crawlingParameter.getTblPriceListData().getCoupon());
        nuriBotLog.setUpPrice(priceListCollection.getPriceList().getCoupon());
        nuriBotLog.setLogoType("4");

        String divis = SystemType.getServiceDivisBySystemType(crawlingParameter.getSystemType());
        nuriBotLog.setServiceDivis(divis);
        if (resultDataSub.getCardPrice() != null && StringUtils.hasText(resultDataSub.getCardPrice().toString())) {
            nuriBotLog.setUpCardPrice(Long.parseLong(resultDataSub.getCardPrice().toString()));
        }
        nuriBotLog.setServiceType("1");

        this.oracleNuribotLogDao.setDbNuribotCouponLogInsert(nuriBotLog);

        this.autoTestCoupon(crawlingParameter, priceListCollection.getPriceList());
    }

    private boolean checkDeliveryInfo(PriceListCollection priceListCollection, ResultDataSub resultDataSub, long shopCode, TblPriceListDataVO originalPriceList) {
        boolean passShockingDeal = ShopCode.SHOCKING_DEAL.getCode() == shopCode &&
                StringUtils.hasText(originalPriceList.getCaCode()) &&
                "12".equals(originalPriceList.getCaCode().substring(0, 2));

        String priceListDeliveryInfo = priceListCollection.getPriceList().getDeliveryinfo();
        String originalDeliveryInfo = originalPriceList.getDeliveryInfo();
        boolean isEqualDeliveryInfo = Objects.equals(priceListDeliveryInfo, originalDeliveryInfo);

        return resultDataSub.getDeliveryPrice() == null ||
                !StringUtils.hasText(priceListCollection.getOraclePriceList().getDeliveryinfo()) ||
                passShockingDeal ||
                isEqualDeliveryInfo;
    }

    private void autoTestCoupon(CrawlingParameter param, TblPriceList priceList) {
        AutoTestLogDto autoTestLog = param.getAutoTestLog();
        if (param.isRealTest() && "7".equals(param.getDivis()) && autoTestLog.getTestCode() != 0) {
            this.autoTestService.updateCoupon(autoTestLog, param.getAutoTestTbl(), priceList);
            throw new CtuException(ResultMessageCode.REAL_TEST_COUPON, priceList.getCoupon().toString());
        }
    }
}
