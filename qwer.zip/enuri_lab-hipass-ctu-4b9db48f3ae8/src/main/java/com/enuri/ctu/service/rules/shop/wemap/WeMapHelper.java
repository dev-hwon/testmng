package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.shop.wemap.CartOptionSave;
import com.enuri.ctu.dto.shop.wemap.ProdCartSave;
import com.enuri.ctu.dto.shop.wemap.WeMapPayload;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.enuri.ctu.util.RegExpUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Slf4j
@Component
@RequiredArgsConstructor
public class WeMapHelper {

    private static final String BASE_URL = "https://front.wemakeprice.com/api/edge/cart/saveProdCart.json";

    private final SimpleWebClient simpleWebClient;
    private final ObjectMapper objectMapper;

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::wmpSoldOut
     * line: 1484 ~ 1494
     * </pre>
     */
    public boolean isSoldOut(String html) {
        boolean containsOptUseYn = html.contains("{\"optUseYn\":\"Y\"");
        boolean containsReqDelivery = html.contains("배송요청일 기재 바랍니다");
        boolean containsMartDelivery = html.contains("<strong class=\"store_name\">마트당일배송</strong>");

        if (!containsOptUseYn && !containsReqDelivery && !containsMartDelivery) {
            WeMapPayload payload = this.makePayload(html);

            String jsonPayload;
            try {
                jsonPayload = this.objectMapper.writeValueAsString(payload);
            } catch (JsonProcessingException e) {
                log.error("WeMap Fallback payload serialize failed: {}", e.getMessage());
                throw new CtuException(ResultMessageCode.FAIL);
            }

            ResponseEntity<String> responseEntity = this.simpleWebClient
                    .post(BASE_URL, jsonPayload, this.soldOutCheckHeaders());

            // status 422 : true
            return responseEntity.getStatusCode().equals(HttpStatus.UNPROCESSABLE_ENTITY);
        }

        return false;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::setPayload
     * line: 1326 ~ 1330
     * </pre>
     */
    private HttpHeaders soldOutCheckHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36");
        httpHeaders.add("X-Requested-With", "XMLHttpRequest");
        httpHeaders.add("Content-Type", "application/json");
        httpHeaders.add("Cookie", "SCOUTER=x6l0h7cnn2vr7j; tl_p_id=v01-b902337a-07f3-47f8-bc19-a9e23123bdf2-843413403; cto_lwid=4d968dbf-056c-497b-a4c2-a1768d0a4b4e; _AT_vid=6P3RAHTK89ULIUBATPL58SZVN9LZR2VB; _ga=GA1.3.244129020.1571114628; _fbp=fb.2.1571114628594.761900462; viewShow=yes; pmsrl=%23s%21om%2Bth8MPrFZqgwMFvnMTnlL5xByFnM0AIDZ%2FvO0vjxoUmmKnWC1OzQ%233D%233D; abtype_cookie=%7B%22v16%22%3A%22A%22%2C%22v18%22%3A%22A%22%2C%22v19%22%3A%22B%22%2C%22v100%22%3A%22A%22%2C%22v110%22%3A%22B%22%2C%22v111%22%3A%22A%22%2C%22v114%22%3A%22A%22%2C%22v123%22%3A%22B%22%2C%22v124%22%3A%22B%22%2C%22v134%22%3A%22B%22%2C%22v135%22%3A%22A%22%2C%22v137%22%3A%22C%22%2C%22v140%22%3A%22A%22%2C%22v141%22%3A%22B%22%2C%22v142%22%3A%22B%22%2C%22v144%22%3A%22A%22%2C%22v145%22%3A%22B%22%2C%22v146%22%3A%22A%22%2C%22v147%22%3A%22A%22%2C%22v148%22%3A%22A%22%2C%22v149%22%3A%22A%22%2C%22v150%22%3A%22A%22%2C%22v151%22%3A%22B%22%2C%22v153%22%3A%22A%22%7D; abtype_update_time=20191210095715; jp=80024; ln=205013; lnt=%EC%97%90%EB%88%84%EB%A6%AC_DB; _show_app_layer=no; tl_web=%7B%22tl_s_id%22%3A%22353aa35b-5697-45c9-a962-4f57fe0172c6%22%2C%22tl_ab%22%3A%7B%22v16%22%3A%22A%22%2C%22v18%22%3A%22A%22%2C%22v19%22%3A%22B%22%2C%22v100%22%3A%22A%22%2C%22v110%22%3A%22B%22%2C%22v111%22%3A%22A%22%2C%22v124%22%3A%22B%22%2C%22v144%22%3A%22A%22%2C%22v149%22%3A%22A%22%2C%22v150%22%3A%22A%22%2C%22v151%22%3A%22B%22%2C%22v153%22%3A%22A%22%7D%7D; session_area_v2=N4IgTAnAbAjAHGRB2ADCAXAbRAFQBIDCA8iALoC%2BQAA%3D; tl_pro_id=5223572a; recent_view_key=RECENTVIEW%3A02426d78-aef4-4347-8447-4309c78f7778; _AT_vid2=9ECRQ0X0B4YXKJGAHNSGUSXOE0FKCLAZ; _gid=GA1.3.93566852.1583125436; last_deal_srl=1490413894; seen_time_alerts=%5B%221212%ED%83%80%EC%9E%84%20%EB%B3%B4%EB%9F%AC%EA%B0%80%EA%B8%B0%22%2C%22%EC%98%A4%EB%8A%98%EC%9D%98%ED%8B%B0%EB%AA%AC%20%EB%B3%B4%EB%9F%AC%EA%B0%80%EA%B8%B0%22%5D; cto_bundle=lEHUf194TWRkMkNWZFdnMndUb1RlY3RqckJmQmIxa1YzJTJGNnVEVlhlJTJCQXl4dUZ4SEM0NnhVQXBmWkVHRDNEaGM4dWd5dGdUJTJCRjl3dXlYaSUyQnVSdDN5QVZpOEdwVXNreUl6UnphSjExOG9OQ0RKaUd2b3ZJOFRoQlMwOWhzY0pUM1RtWGFWY3NIMkxZTW5waFoxSFFrS2NKNGJIJTJCcjVpbmgxQzBWeTY4bjUlMkJVcjNQJTJCRSUzRA; refererURL=http%3A%2F%2Fwww.tmon.co.kr%2Fdeal%2F1490413894%3Fcoupon_srl%3D2501278%26utm_source%3Denuri%26utm_medium%3Daffiliate%26utm_term%3D%26utm_content%3D%26utm_campaign%3D%25EC%2597%2590%25EB%2588%2584%25EB%25A6%25AC_DB; tl_ti=8c2f222a; TS01f39fd0=01f7309d0aa8efe7bd4589db72a0e1475b68ba2aafd60ee703928b3561e638e84014f79c00a28bcc32373c0a951a34491c4d4163c7fb7907c36105e07557e2f4abd5f3038bb2697b859e4759729f1c047b28b2cec0c46a552aef66fba69b4d059721c5ef113c3bfb3aa4f7050113a7740bf1251609a2cd30abb19dd2b98ca43c800e7eab9d085828a653e4adc71ff2ead49979104c5d6811c17d6b0b7686da675376ec396e53fea4c2b98dfb9a5447986c16c5f03209dd387f20fcab68189bfa76f39b7a89c74970196641335616fbb9b90e744aa7; wcs_bt=e619fba40503b:1583375572|s_1a7f4dd73489:1574322266|s_3c274e946d59:1571128867; _gali=view-default-scene-default; JSESSIONID=D37C2FBCEC300BD3A4F9DEB98D990F5A; TS01fbbc39=01f7309d0a026d3c7eeb8fe98458607bcbb17874300c2ca66df6512bbc4e238ec025c96f1db5e1461f74c47ea1e493f86ba82b727940d4dceafefc3d5c3ae6e9690792cfe96754cb0db466ff3d0fc18e7616332bf1ad773bdb45075960fec458831789ae31; wmp_pcstamp=1572831929713634623; _fbp=fb.1.1572831945084.1632013393; _ga=GA1.2.619584799.1572831945; cto_lwid=d04b2134-ed38-49d7-af1a-2194ed3350e5; __utmv=122159757.|3=Female=25~29=1^4=m_id=4246612=1; cto_bundle=0wacFV8lMkIlMkZBTEMwNmJ2WHp6d2tiWVo0SHNSWmE3U3hVbERpN2lseGxmVmV6RlJiMHk5T2NTVlZLQldtekE2Vmk1MmRaSWRFV3lXVTM1RE04NlJVdTFUUUlDTWRkVEppVzF5OFBSSTFWNllBaldQNVAxSzJyRTRlVyUyQnQ3NjZVblR1N0VCUXA2d3dudkRLJTJGRTV1NUV0alNMWTBSazh6M3c0UTVlJTJCYm80aHFnSVd0S0tNJTNE; wmp_tracking=4611783.none.none%5E3463958.none.none%5E4177052.none.none%5E4394268.none.none%5E3239608.none.none%5E4375141.none.none%5E4344253.none.none%5E3463958.none.none%5E4483355.none.none%5E4483355.none.none; rp=http%3A%2F%2Ffront.wemakeprice.com%2Fproduct%2F515428698; __utmc=122159757; _gid=GA1.2.1510759314.1584319506; WemepAffiliate=%7B%22channelId%22%3A1000017%2C%22expirationDate%22%3A%222020-03-16T15%3A20%3A56.885%22%7D; affiliate_extra_no=enuri; WemepEdgeLatestView=%5B%7B%22type%22%3A%22PROD%22%2C%22value%22%3A412788448%2C%22adultLimitYn%22%3A%22N%22%2C%22imgUrl%22%3A%22https%3A%2F%2Fview01.wemep.co.kr%2Fwmp-product%2F8%2F844%2F412788448%2F412788448_thumbnail.jpg%22%7D%2C%7B%22type%22%3A%22PROD%22%2C%22value%22%3A515428698%2C%22adultLimitYn%22%3A%22N%22%2C%22imgUrl%22%3A%22https%3A%2F%2Fview01.wemep.co.kr%2Fwmp-product%2F8%2F869%2F515428698%2F515428698_thumbnail.jpg%22%7D%5D; __utma=122159757.619584799.1572831945.1584336182.1584337859.298; __utmz=122159757.1584337859.298.1.utmcsr=enuri|utmccn=null|utmcmd=PRICE_af; __utmt=1; setGM=fca5a09539bb02887bf7eaf9bb4de0e46002259a3679dc384a6ef83f4fc7581150278c51bdcf8792ff781134703052c9108e46a3b3202ac86c5b489b5ec162648567c506e786bf98d750fde5733070f6cc26247d7461bd96c821e2ce03e3a4c71ecf5962c090fbb19171ff462bc8554033f870199939749b41b85920e68dee98b8cd4e3dffe1fae614d93ac86b0f68cdbe9459912ca785200fb726527709ef395a472a83e0b27d0c7a96dd395d9b0463e1dca5ea6b1e4c768056e634045409f4e05a49b0975997af6cefd7b1fde9f6b08c20d5b9f036e75cc7bc671bd393c400; WemepEdgeSpecialClub=%7B%22isSpecialClub%22%3Afalse%2C%22regDate%22%3A%222020-03-16T14%3A54%3A18.586%22%7D; WemepCart=%7B%22cartNo%22%3A3223733%2C%22sessionId%22%3A%2284981e0223c811e8a1fd246e967f56d0%22%2C%22cartQty%22%3A1%7D; pwnone=dianaday; WMONID=Po0o9E0zM_0; __utmb=122159757.60.10.1584337859");
        httpHeaders.add("Host", "front.wemakeprice.com");

        return httpHeaders;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::setPayload
     * line: 1293 ~ 1337
     * </pre>
     */
    public WeMapPayload makePayload(String html) {
        String prodNm = RegExpUtils.getRegExpData(html, "\"prodNm\":\"(.*?)\",");
        String prodNo = RegExpUtils.getRegExpData(html, "\"prodNo\":(.*?),");
        String salePrice = RegExpUtils.getRegExpData(html, "\"salePrice\":(.*?),");
        String optNo = RegExpUtils.getRegExpData(html, "\"optNo\":(.*?),");
        String qty = RegExpUtils.getRegExpData(html, "\"purchaseMinCount\":(.*?),");

        CartOptionSave cartOptionSave = CartOptionSave.builder()
                .optNo(Long.parseLong(optNo))
                .qty(Integer.parseInt(qty))
                .build();

        ProdCartSave prodCartSave = ProdCartSave.builder()
                .prodNm(prodNm)
                .prodNo(Long.parseLong(prodNo))
                .salePrice(Long.parseLong(salePrice))
                .cartOptionSave(Collections.singletonList(cartOptionSave))
                .build();

        return WeMapPayload.builder()
                .prodCartSave(Collections.singletonList(prodCartSave))
                .build();
    }
}
