package com.enuri.ctu.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultDataSub {

    // 판매가
    @JsonProperty("NormalPrice")
    private Object normalPrice;

    // 할인가
    @JsonProperty("SalePrice")
    private Object salePrice;

    // 할인율
    @JsonProperty("SaleRate")
    private Object saleRate;

    // 카드가
    @JsonProperty("CardPrice")
    private Object cardPrice;

    // 배송비
    @JsonProperty("DeliveryPrice")
    private Object deliveryPrice;

    // 품절
    @JsonProperty("SoldOut")
    private Object soldOut;

    // 쿠폰
    @JsonProperty("Coupon")
    private Object coupon;

    // 설치비
    @JsonProperty("InstChargePrice")
    private Object instChargePrice;

    // 성인인증
    @JsonProperty("Adult")
    private Object adult;

    @JsonIgnore
    private String wmpType;

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 680 ~ 694
     * </pre>
     */
    public void assignValue(String divideKeyName, Object value) {
        switch (divideKeyName) {
            case "NormalPrice":     // divide_code 1
                this.normalPrice = value;
                break;
            case "SalePrice":       // divide_code 2
                this.salePrice = value;
                break;
            case "SaleRate":        // divide_code 3
                this.saleRate = value;
                break;
            case "CardPrice":       // divide_code 4
                this.cardPrice = value;
                break;
            case "DeliveryPrice":   // divide_code 5
                this.deliveryPrice = value;
                break;
            case "SoldOut":         // divide_code 6
                this.soldOut = value;
                break;
            case "Coupon":          // divide_code 7
                this.coupon = value;
                break;
            case "InstChargePrice": // divide_code 9
                this.instChargePrice = value;
                break;
            case "Adult":           // divide_code 26
                this.adult = value;
                break;
            default:
        }
    }

    @JsonIgnore
    public boolean isEmpty() {
        return this.normalPrice == null &&
                this.salePrice == null &&
                this.saleRate == null &&
                this.cardPrice == null &&
                this.deliveryPrice == null &&
                this.soldOut == null &&
                this.coupon == null &&
                this.instChargePrice == null &&
                this.adult == null;
    }

    public boolean needToCheckPrice() {
        return this.soldOut == null &&
                (this.normalPrice != null || this.salePrice != null || this.cardPrice != null);
    }

    public boolean isSoldOut() {
        return this.soldOut != null && "1".equals(String.valueOf(this.soldOut));
    }
}
