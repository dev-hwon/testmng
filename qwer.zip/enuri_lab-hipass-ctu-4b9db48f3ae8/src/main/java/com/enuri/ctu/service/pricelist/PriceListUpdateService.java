package com.enuri.ctu.service.pricelist;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.vo.TblPriceListDataVO;

public interface PriceListUpdateService {

    void sync(TblPriceListDataVO originalPriceList, MsSqlPriceList priceList, NuriBotLog nuriBotLog);
    void deliveryInfoUpdate(PriceListCollection priceListCollection, CrawlingParameter crawlingParameter,
                            NuriBotLog nuriBotLog, ResultDataSub resultDataSub);

    void couponUpdate(PriceListCollection priceListCollection, CrawlingParameter crawlingParameter,
                      NuriBotLog nuriBotLog, ResultDataSub resultDataSub);
}
