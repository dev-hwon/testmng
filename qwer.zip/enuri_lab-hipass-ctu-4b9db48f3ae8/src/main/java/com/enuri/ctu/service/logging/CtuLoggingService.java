package com.enuri.ctu.service.logging;

import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import org.springframework.http.HttpStatus;

public interface CtuLoggingService {

    // setFailLog
    void loggingFail(FailLog failLog);

    void loggingProxyAccess(ProxyConnectInfoVO proxyConnectInfoVO, CrawlingUnit unit, HttpStatus httpStatus);
}
