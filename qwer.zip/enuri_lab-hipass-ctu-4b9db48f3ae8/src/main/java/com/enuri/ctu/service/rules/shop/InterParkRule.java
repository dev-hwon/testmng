package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.parse.ParsingDataParameter;
import com.enuri.ctu.util.ParsingUtil;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Component
@RequiredArgsConstructor
public class InterParkRule implements ShopRule {

    @Override
    public ResultMessageCode checkOriginalPriceList(TblPriceListDataVO originalPriceList) {
        if (StringUtils.hasText(originalPriceList.getUrl()) &&
                originalPriceList.getUrl().contains("www.interpark.com") &&
                !originalPriceList.getUrl().contains("biz_cd=P00335")) {
            log.error("URL Deny Data");
            return ResultMessageCode.FAIL_URL_DENY;
        }

        return null;
    }

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        if (RequestService.HOMEPAGE != param.getService()) {
            return ShopRule.super.replaceProxyUrlLink(param, gatheringInfo);
        }

        String urlLink;
        int interParkType = 0;
        String gtrUrl = gatheringInfo.getGtrUrl();
        String url = param.getUrl();

        if (url.contains("opt_no")) {
            String gtrGoodsSubCode = RegExpUtils.getRegExpData(url, "opt_no=([0-9]{1,20}.*?)&");
            String optNo;
            if (DeviceType.MOBILE == param.getDevice()) {
                optNo = "&opt_no=";
            } else {
                optNo = "&optNo=";
            }
            urlLink = gtrUrl
                    .replace("GTR_GOODS_CODE", gtrGoodsSubCode)
                    .concat(optNo + param.getGoodsCode());
            interParkType = 1;
        } else {
            urlLink = gtrUrl.replace("GTR_GOODS_CODE", param.getGoodsCode());
        }

        gatheringInfo.setGtrUrl(urlLink);

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(param.getGoodsCode())
                .interParkType(interParkType)
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 697 ~ 710
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service, CrawlingUnit unit) {
        if (resultDataSub.getInstChargePrice() != null) {
            ParsingDataParameter parsingDataParameter = ParsingDataParameter.builder()
                    .startStr(",\"productInfoPriceDto\":")
                    .endStr("\"productInfoDeliveryDto\":")
                    .allStr("\"mktPr\":(.*?),")
                    .sourceHtml(html)
                    .regExpRetType("1")
                    .service(service)
                    .build();
            String phonePrice = ParsingUtil.parseHtmlData(parsingDataParameter);
            if (StringUtils.hasText(phonePrice)) {
                resultDataSub.setSalePrice(phonePrice);
            }
        }
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 581 ~ 679
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (deliveryMessage.contains("distCost") && !deliveryMessage.contains("distCost\":0\"")) {
            return this.distCost(deliveryMessage, deliveryInfoParam.getPriceList().getPrice());
        }

        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    private DeliveryInfoClass distCost(String deliveryMessage, Long price) {
        String delvMsg = deliveryMessage.substring(deliveryMessage.indexOf("minbuyAmt"));
        Pattern pt = Pattern.compile("(.*?)\"distCost\"");
        Matcher mc = pt.matcher(delvMsg);

        String delvFreeMinPrice = "";
        String delvDefaultPrice = "";

        if (mc.find()) {
            delvFreeMinPrice = mc.group(0);
        }

        pt = Pattern.compile("(?:\\d*\\.)?\\d+");
        mc = pt.matcher(delvFreeMinPrice);

        if (mc.find()) {
            delvFreeMinPrice = mc.group(0);
        }

        if(delvFreeMinPrice.equals("0")) {
            delvFreeMinPrice = null;
        }

        pt = Pattern.compile("distCost\":(.*?)\"localCostYn");
        mc = pt.matcher(delvMsg);
        while (mc.find()) {
            delvDefaultPrice = mc.group(0);
        }

        pt = Pattern.compile("(?:\\d*\\.)?\\d+");
        mc = pt.matcher(delvDefaultPrice);
        while (mc.find()) {
            delvDefaultPrice = mc.group(0);
        }

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        if (!StringUtils.hasText(delvFreeMinPrice)) {
            return deliveryInfoClass;
        }
        if (price != null) {
            if (Long.parseLong(delvFreeMinPrice) <= price) {
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryInfo("무료배송");
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("1");
            } else if (delvFreeMinPrice.equals("100000000") || delvFreeMinPrice.equals("99999999")) {
                deliveryInfoClass.setDeliveryInfo2(delvDefaultPrice);
                deliveryInfoClass.setDeliveryInfo(delvDefaultPrice);
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("2");
            } else {
                this.defaultDeliveryInfo(deliveryInfoClass, delvFreeMinPrice, delvDefaultPrice);
            }
        } else {
            this.defaultDeliveryInfo(deliveryInfoClass, delvFreeMinPrice, delvDefaultPrice);
        }

        return deliveryInfoClass;
    }

    private void defaultDeliveryInfo(DeliveryInfoClass deliveryInfoClass, String delvFreeMinPrice, String delvDefaultPrice) {
        String delvPrice = delvFreeMinPrice + "원 미만 " + delvDefaultPrice + "원";
        if (!StringUtils.hasText(delvDefaultPrice)) {
            delvDefaultPrice = "0";
            deliveryInfoClass.setDeliveryInfo2(delvDefaultPrice);
            deliveryInfoClass.setDeliveryInfo(delvPrice);
            deliveryInfoClass.setDeliveryType2("1");
            deliveryInfoClass.setRightnLeft("2");
        }
    }
}
