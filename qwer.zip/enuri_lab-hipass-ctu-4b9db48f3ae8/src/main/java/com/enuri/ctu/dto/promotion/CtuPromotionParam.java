package com.enuri.ctu.dto.promotion;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CtuPromotionParam {
    private Long shopCode;
    private String ctuService;
    private String ctuDevice;
    private String testCk;
}
