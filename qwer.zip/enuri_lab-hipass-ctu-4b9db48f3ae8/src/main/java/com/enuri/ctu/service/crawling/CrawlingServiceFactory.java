package com.enuri.ctu.service.crawling;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.crawling.nonproxy.NonProxyCrawlingService;
import com.enuri.ctu.service.crawling.nonproxy.NonProxyPrepareService;
import com.enuri.ctu.service.crawling.proxy.ProxyCrawlingService;
import com.enuri.ctu.service.crawling.proxy.ProxyPrepareService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CrawlingServiceFactory {

    private final ProxyCrawlingService proxyCrawlingService;
    private final NonProxyCrawlingService nonProxyCrawlingService;

    private final ProxyPrepareService proxyPrepareService;
    private final NonProxyPrepareService nonProxyPrepareService;

    public CrawlingService getService(ShopCode shopCode) {
        if (ShopCode.SSG == shopCode) {
            return this.nonProxyCrawlingService;
        }

        return this.proxyCrawlingService;
    }

    public PreCrawlingService getPreService(ShopCode shopCode) {
        // 12.09 일자 코드기준으로 모두 proxy 사용
//        if (ShopCode.SSG == shopCode) {
//            return this.nonProxyPrepareService;
//        }

        return this.proxyPrepareService;
    }
}
