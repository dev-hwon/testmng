package com.enuri.ctu.service.savegoods.call;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.vo.GoodsCodeVO;

import java.util.concurrent.CompletableFuture;

public interface InnerCallService {
    CompletableFuture<String> call(GoodsCodeVO goodsCodeVO, CtuTest ctuTest, IpType ipType);
}
