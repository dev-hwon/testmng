package com.enuri.ctu.dao.ctulog;

import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.vo.GoodsCodeVO;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface CtuLogDao {

    int insertFailLog(FailLog failLog);

    int insertSaveGoodsResult(GoodsCodeVO goodsCodeVO, LocalDateTime requestAt, LocalDateTime responseAt,
                              String response, String ctuTest);

    int insertSaveGoodsLog(String id, String ctuTest);

    int updateSaveGoodsLogEndDate(String id);

    int countSaveGoodsProcessById(String id);

    void deleteSaveGoodsProcessId(String id);

    int truncateSaveGoodsModel();

    void insertModelNo(List<GoodsCodeVO> list);
}
