package com.enuri.ctu.service.crawling.header;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.dao.oracle.OracleHeaderDao;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.vo.CtuHeaderVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <pre>
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * line: 214 ~ 227
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class CtuHeaderService implements HeaderService {

    private final OracleHeaderDao oracleHeaderDao;
    private final CtuLogDao ctuLogDao;

    @Override
    @LoggingProcessTime
    @Cacheable(
            value = "HEADERS",
            key = "'getCrawlingHeaders' + #gatheringInfo.gtrCode + #crawlingParam.shopCode + #crawlingParam.ctuTest.code"
    )
    public List<CtuHeaderVO> getCrawlingHeaders(CrawlingParameter crawlingParam, GatheringInfo gatheringInfo) {

        // line: 217
        List<CtuHeaderVO> headers = this.oracleHeaderDao.fetchHeaders(gatheringInfo.getGtrCode(), crawlingParam.getShopCode(),
                crawlingParam.getCtuTest().getCode());

        if (headers.isEmpty()) {
            log.error("ctuHeader Not Found shopCode: {} /goodsCode: {} /service: {} /ctuDevice: {}",
                    gatheringInfo.getShopCode(), crawlingParam.getGoodsCode(), gatheringInfo.getCtuService(),
                    gatheringInfo.getCtuDevice());

            FailLog failLog = FailLog.ofCrawlingPrepare(crawlingParam);
            failLog.setCrawlingUrl("");
            failLog.setFailType(5);
            failLog.setGtrTimeOut(gatheringInfo.getGtrTimeOut());
            this.ctuLogDao.insertFailLog(failLog);
            throw new CtuDataNotFoundException(ResultMessageCode.FAIL_5);
        }

        return headers;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebConnect::httpsUrlConnectProc
     * line: 861 ~ 889
     * 
     * 헤더 세팅
     * </pre>
     */
    @Override
    public HttpHeaders getReplacedHttpHeaders(CrawlingUnit unit) {
        final String targetValueStr = "GTR_GOODS_CODE";
        final String goodsCode = unit.getParamGoodsCode();
        List<CtuHeaderVO> ctuHeaderList = unit.getHeaderList();

        if (ctuHeaderList.isEmpty()) {
            Long gtrCode = unit.getGatheringInfo().getGtrCode();
            Long shopCode = unit.getGatheringInfo().getShopCode();
            String ctuTestCode = unit.getParamCtuTest().getCode();

            ctuHeaderList = this.oracleHeaderDao.fetchHeaders(gtrCode, shopCode, ctuTestCode);
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        ctuHeaderList.forEach(ctuHeader -> {
            String key = ctuHeader.getHeaderKey();
            String value = ctuHeader.getHeaderValue();
            if (goodsCode != null && value.contains(targetValueStr)) {
                value = value.replace(targetValueStr, goodsCode);
            }
            httpHeaders.add(key, value);
        });

        httpHeaders.add("Connection", "keep-alive");

        return httpHeaders;
    }
}
