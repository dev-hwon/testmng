package com.enuri.ctu.service.autotest;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.AutoTestLogVO;
import com.enuri.ctu.vo.TblPriceListDataVO;

public interface AutoTestService {

    AutoTestLogVO fetchAutoTestTbl(Long testCode);

    void updateAutoTestNoProduct(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl, DeviceType deviceType);

    void updateAutoTestCrawlingFail(CrawlingParameter parameter, ResultMessageCode resultMessageCode);

    void updateCategoryDeny(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl);

    void updateSoldOut(AutoTestLogDto autoTestLog, String status);

    void updateDeliveryInfo(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl, TblPriceList oraclePriceList,
                            TblPriceListDataVO originalPriceList);

    void updateCoupon(AutoTestLogDto autoTestLogDto, AutoTestLogVO autoTestTbl, TblPriceList priceList);

    void updatePrice(CrawlingParameter param, TblPriceList priceList, ResultDataSub resultDataSub);

    void updateNotApplicable(CrawlingParameter param);
}
