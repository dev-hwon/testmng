package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.service.rules.shop.GalleriaRule;
import com.enuri.ctu.vo.GatheringInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * line: 179 ~ 196
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class GeneralGatheringInfoService implements GatheringInfoService {

    private final GatheringDataHandler gatheringDataHandler;
    private final GalleriaRule galleriaRule;

    @Override
    @LoggingProcessTime
    public GatheringInfo fetchAndConvert(CrawlingParameter crawlingParam) {
        GatheringInfo gatheringInfo;
        if (this.isSpecial(crawlingParam.getService())) {
            log.info("Service Code : {}", crawlingParam.getService().getCode());
            gatheringInfo = this.processSpecial(crawlingParam);
        } else {
            gatheringInfo = this.processGeneral(crawlingParam);
        }

        // 갤러리아 모바일 GTR_CODE 교체 : 갤러리아몰 mobile도 PC정보 이용 (게이트페이지 동일)
        if (ShopCode.GALLERIA_MALL == ShopCode.getShopCode(crawlingParam.getShopCode())) {
            long replaceGtrCode = this.galleriaRule.replaceGtrCode(gatheringInfo.getGtrCode(),
                    crawlingParam.getShopCode(), crawlingParam.getDevice().getCode());

            gatheringInfo.setGtrCode(replaceGtrCode);
        }

        return gatheringInfo;
    }

    /**
     * <pre>
     * line: 187 ~ 196
     * </pre>
     */
    public GatheringInfo processGeneral(CrawlingParameter crawlingParam) {
        GatheringInfo gatheringInfo = this.initGatheringInfo(crawlingParam);
        GatheringInfoVO gatheringInfoVO = this.gatheringDataHandler.fetchGatheringInfo(gatheringInfo, crawlingParam);

        gatheringInfo.convertWithGatheringInfo(gatheringInfoVO);
        return gatheringInfo;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 182 ~ 185
     * </pre>
     */
    public GatheringInfo processSpecial(CrawlingParameter crawlingParam) {
        GatheringInfo gatheringInfo = this.initGatheringInfo(crawlingParam);

        final String originalCtuServiceCode = gatheringInfo.getCtuService();
        gatheringInfo.setCtuService(RequestService.DEAL.getCode());
        gatheringInfo.setCtuDevice(DeviceType.PC.getCode());

        GatheringInfoVO gatheringInfoVO = this.gatheringDataHandler.fetchGatheringInfo(gatheringInfo, crawlingParam);
        gatheringInfo.convertWithGatheringInfo(gatheringInfoVO);

        // 원복
        gatheringInfo.setCtuService(originalCtuServiceCode);

        return gatheringInfo;
    }


    /**
     * <pre>
     * line: 181
     *
     * #SR 29994(추석기획전) //SR 34660(크레이지 프라이데이) 체크
     * </pre>
     */
    private boolean isSpecial(RequestService serviceCode) {
        return RequestService.AL_TOOLBAR == serviceCode ||
                RequestService.DEAL_EVENT == serviceCode;
    }

    /**
     * <pre>
     * line: 188, 194
     * ShopCode Homeplus(6361) && Device Mobile
     * </pre>
     */
    private boolean isMobileHomePlus(String deviceType, long shopCode) {
        return DeviceType.MOBILE == DeviceType.getDeviceType(deviceType) &&
                ShopCode.HOMEPLUS_DELIVERY_MALL.getCode() == shopCode;
    }

}
