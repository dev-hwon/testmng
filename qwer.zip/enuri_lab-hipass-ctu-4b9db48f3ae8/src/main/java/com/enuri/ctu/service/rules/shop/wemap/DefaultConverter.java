package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;

class DefaultConverter implements WeMapUrlConverter {
    @Override
    public ReplacedUrlLink refine(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String urlLink = gatheringInfo.getGtrUrl().replace("GTR_GOODS_CODE", param.getGoodsCode());
        return ReplacedUrlLink.builder()
                .gtrGoodsCode(param.getGoodsCode())
                .urlLink(urlLink)
                .build();
    }

}
