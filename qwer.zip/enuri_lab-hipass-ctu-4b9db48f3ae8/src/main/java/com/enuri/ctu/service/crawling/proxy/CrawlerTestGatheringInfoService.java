package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.vo.GatheringInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class CrawlerTestGatheringInfoService implements GatheringInfoService {

    private final GatheringDataHandler gatheringDataHandler;

    /**
     * <pre>
     * line: 177
     * ctu_test = "Y"
     * </pre>
     */
    @Override
    public GatheringInfo fetchAndConvert(CrawlingParameter crawlingParam) {
        GatheringInfo gatheringInfo = this.initGatheringInfo(crawlingParam);
        GatheringInfoVO gatheringInfoVO = this.gatheringDataHandler.fetchGatheringInfo(gatheringInfo, crawlingParam);
        gatheringInfo.convertWithGatheringInfo(gatheringInfoVO);
        return gatheringInfo;
    }
}
