package com.enuri.ctu.exception;

import lombok.Getter;

@Getter
public class CtuRawMessageException extends RuntimeException {
    private final String responseMessage;

    public CtuRawMessageException(String responseMessage) {
        this.responseMessage = responseMessage;
    }
}
