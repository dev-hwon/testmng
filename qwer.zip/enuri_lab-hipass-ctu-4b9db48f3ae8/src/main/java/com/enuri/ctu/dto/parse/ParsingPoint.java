package com.enuri.ctu.dto.parse;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ParsingPoint {
    private int startPoint;
    private int endPoint;
}
