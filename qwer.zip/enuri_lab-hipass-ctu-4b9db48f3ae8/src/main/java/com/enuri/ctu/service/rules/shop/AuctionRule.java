package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class AuctionRule implements ShopRule {

    private static final String PATTERN_PRICE = "(\\d{0,10})미만:(\\d{0,10})";    // ([0-9]{0,10})미만:([0-9]{0,10})

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 129 ~ 156
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        if (!deliveryInfoParam.getDeliveryMessage().contains("이상:무료") ||
                deliveryInfoParam.getResultDataSub().getNormalPrice() == null) {
            ShopRule.super.getDeliveryInfo(deliveryInfoParam);
        }

        long normalPrice = Long.parseLong(deliveryInfoParam.getResultDataSub().getNormalPrice().toString());

        //30000미만:3000/30000이상:무료
        //50000미만:2500/50000이상:무료
        //**이상 무료일 경우 상품가격비교처리
        Pattern pattern = Pattern.compile(PATTERN_PRICE);
        Matcher matcher = pattern.matcher(deliveryInfoParam.getDeliveryMessage());
        String delvMsg = null;
        while (matcher.find()) {
            if (Long.parseLong(matcher.group(1)) > normalPrice) {
                delvMsg = matcher.group(2);
                break;
            }
        }

        String info;
        String info2;
        String rightNLeft;
        if (StringUtils.hasText(delvMsg)) {
            info = "무료배송";
            info2 = "0";
            rightNLeft = "1";
        } else {
            info = deliveryInfoParam.getDeliveryMessage();
            info2 = deliveryInfoParam.getDeliveryMessage();
            rightNLeft = "2";
        }

        return DeliveryInfoClass.builder()
                .deliveryInfo(info)
                .deliveryInfo2(info2)
                .deliveryType2("1")
                .rightnLeft(rightNLeft)
                .build();
    }


}
