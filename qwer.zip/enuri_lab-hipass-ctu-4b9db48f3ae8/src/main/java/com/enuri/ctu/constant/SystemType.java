package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum SystemType {
    MINI_BOT("1"),
    MP("2"),
    WEB_CTU("3"),
    MOBILE_CTU("4"),
    SDUL("5"),
    ETC("6"),
    MINI_MP("8"),
    WEB_TEST_PAGE("101");

    private final String code;

    private static final ImmutableMap<String, SystemType> SYSTEM_TYPE_MAP;

    static {
        Map<String, SystemType> mutableMap = Arrays.stream(SystemType.values())
                .collect(Collectors.toMap(SystemType::getCode, e -> e));
        SYSTEM_TYPE_MAP = ImmutableMap.copyOf(mutableMap);
    }

    SystemType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static boolean isMiniBot(String code) {
        return MINI_BOT.getCode().equals(code);
    }

    @Nullable
    public static SystemType getSystemType(String code) {
        if (!StringUtils.hasText(code)) {
            return null;
        }
        return SYSTEM_TYPE_MAP.get(code);
    }

    public static String getServiceDivisBySystemType(String systemTypeCode) {
        if (isMiniBot(systemTypeCode)) {
            return "1";
        }

        return "3";
    }
}
