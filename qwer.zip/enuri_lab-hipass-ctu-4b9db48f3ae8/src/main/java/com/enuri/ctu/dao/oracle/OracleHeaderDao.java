package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.CtuHeaderVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OracleHeaderDao {

    List<CtuHeaderVO> fetchHeaders(Long gtrCode, Long shopCode, String testCk);

}
