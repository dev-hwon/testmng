package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.GalleriaRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import com.enuri.ctu.service.rules.shop.lotte.LotteRule;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class GtrCodeRuleFactory {
    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;
    private final LotteRule lotteRule;
    private final SsgRule ssgRule;
    private final GalleriaRule galleriaRule;


    @PostConstruct
    public void init() {
        // lotte
        RULE_MAP.put(ShopCode.EL_LOTTE, this.lotteRule);
        RULE_MAP.put(ShopCode.LOTTE_MART_MALL, this.lotteRule);
        RULE_MAP.put(ShopCode.LOTTE_ON, this.lotteRule);

        // ssg
        RULE_MAP.put(ShopCode.SSG_DEPT, this.ssgRule);

        // galleria
        RULE_MAP.put(ShopCode.GALLERIA_MALL, this.galleriaRule);

    }

    public ShopRule getGtrCodeRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            shopRule = this.defaultShopRule;
        }

        return shopRule;
    }
}
