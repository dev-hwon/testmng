package com.enuri.ctu.dto.delivery;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DeliveryInfoParam {
    private String deliveryMessage;
    private long crawlingPrice;
    private CrawlingParameter param;
    private ResultDataSub resultDataSub;
    private TblPriceListDataVO originalPriceList;
    private TblPriceList priceList;
}
