package com.enuri.ctu.aop;

import com.enuri.ctu.dao.ctulog.CtuLogDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class SaveGoodsAop {

    private final CtuLogDao ctuLogDao;

    @Value("${ctu.default-ctu-test}")
    private String defaultCtuTest;

    @Around("@annotation(com.enuri.ctu.aop.SaveGoodsTask)")
    public Object manageTask(ProceedingJoinPoint joinPoint) throws Throwable {
        final String id = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        if (stillProcess(id)) {
            log.info("구독 CTU 작업이 종료 되지 않았음 : ID[{}]", id);
            return null;
        }

        log.info("구독 CTU 작업 시작 ID: {} - {}", id, this.defaultCtuTest);
        this.ctuLogDao.insertSaveGoodsLog(id, this.defaultCtuTest);

        Object result = joinPoint.proceed();

        log.info("구독 CTU 작업 종료");
        this.ctuLogDao.updateSaveGoodsLogEndDate(id);

        return result;
    }

    public boolean stillProcess(String id) {
        // end_date == null 인 count > 0 면 동작중인 것으로
        return this.ctuLogDao.countSaveGoodsProcessById(id) > 0;
    }
}
