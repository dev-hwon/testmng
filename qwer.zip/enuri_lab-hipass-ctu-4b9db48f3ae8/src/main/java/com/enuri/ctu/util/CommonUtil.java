package com.enuri.ctu.util;

import com.enuri.ctu.constant.IpType;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

public class CommonUtil {

    private static final List<String> CARD_WORD_LIST = Stream.of("KB국민카드]", "KB카드]", "국민카드]", "신한카드]",
            "삼성카드]", "현대카드]", "NH카드]", "NH농협카드]", "농협카드]", "BC카드]", "우리카드]", "롯데카드]",
            "씨티카드]", "외환카드]", "하나카드]", "CJ카드]", "SC은행카드]", "IBK카드]")
            .collect(collectingAndThen(toList(), Collections::unmodifiableList));

    private CommonUtil() {
        throw new IllegalStateException();
    }

    public static String getLocalDateTime() {
        return LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    public static String trimStr(String str) {
        if (str == null) {
            return "";
        }
        return str.trim();
    }

    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }

        return Pattern.compile("-?\\d+(\\.\\d+)?")
                .matcher(str)
                .matches();
    }

    public static String removeCarriageReturn(String str) {
        if (!StringUtils.hasText(str)) {
            return str;
        }

        return str.replace(System.lineSeparator(), "")
                .replace("\n", "")
                .replace("\r", "");
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::chkContainCardWord
     * line: 1497 ~ 1512
     *
     * TRUE: goodsName 에 card 사 문자가 포함되어 있으면
     * FALSE: 포함되어 있지 않으면
     * </pre>
     */
    public static boolean checkDetailCardWord(String goodsName) {
        return CARD_WORD_LIST.stream()
                .anyMatch(goodsName::contains);
    }

    public static boolean checkSimpleCardWord(String str) {
        return str != null && str.contains("카드]");
    }

    public static long convertToLongType(@Nullable Object obj) {
        long converted = 0L;
        if (obj != null && String.class.isAssignableFrom(obj.getClass())) {
            converted = Long.parseLong(String.valueOf(obj));
        }

        return converted;
    }

    public static IpType getIpTypeFromRequest(HttpServletRequest request) {
        String ipWithPort = request.getRemoteAddr() + ":" + request.getRemotePort();
        return IpType.getIpType(ipWithPort);
    }
}
