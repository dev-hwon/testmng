package com.enuri.ctu.config;

import com.enuri.ctu.util.UniqueValueGenerateUtil;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

import java.util.Map;

public class CustomTaskDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        Map<String, String> copyOfContextMap = MDC.getCopyOfContextMap();
        return () -> {
            if (copyOfContextMap != null) {
                copyOfContextMap.put("EXTRA-ID", UniqueValueGenerateUtil.generateUniqueChar(4));
                MDC.setContextMap(copyOfContextMap);
            }
            runnable.run();
        };
    }
}
