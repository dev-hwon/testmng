package com.enuri.ctu.dao.eloc;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ElocTestDao {

    int connectElocTest();
}
