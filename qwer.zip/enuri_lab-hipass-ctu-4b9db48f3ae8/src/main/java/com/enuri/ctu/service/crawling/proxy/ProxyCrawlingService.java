package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.service.crawling.CrawlingService;
import com.enuri.ctu.service.crawling.connect.CtuWebClient;
import com.enuri.ctu.service.rules.WebClientFallBackRuleFactory;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * package: com.enuri.common.util
 * class file: WebSpider.java
 * </pre>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ProxyCrawlingService implements CrawlingService {

    private final CtuWebClient webClient;
    private final WebClientFallBackRuleFactory fallBackRuleFactory;
    private final ProxyDataHandler proxyDataHandler;


    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 145 ~ 807
     *
     * proxy 를 사용하는 crawler
     * </pre>
     */
    @Override
    @LoggingProcessTime
    public CrawlingResponse crawling(CrawlingUnit unit) {
        // source: com.enuri.common.util.WebConnect::targetWebDivideConnectCTU
        // line: 97
        // proxyConnectInfo
        ProxyConnectInfoVO proxyInfo;
        if (IpType.LOCAL == unit.getParamIpType() || CtuTest.RELEASE != unit.getParamCtuTest()) {
            log.info("Test Proxy Setting : ELITE Only");
            proxyInfo = this.proxyDataHandler.getRandomEliteProxyInfo();
        } else {
            String cpnStatus = this.proxyDataHandler.getCpnStatus();
            proxyInfo = this.proxyDataHandler.getRandomProxyConnectInfo(cpnStatus);
        }

        log.info("ProxyInfo : [{}] {}:{}", proxyInfo.getProxyCompanyCd(), proxyInfo.getProxyIp(), proxyInfo.getProxyPort());

        // call
        // todo lotte_on(49) SELENIUM
        CrawlingResponse response = this.webClient.connectWithProxy(proxyInfo, unit);

        // result handling timon, lotte
        ShopCode shopCode = ShopCode.getShopCode(unit.getGatheringInfo().getShopCode());
        // fallback 처리
        return this.fallBackRuleFactory
                .getFallBackRule(shopCode)
                .fallbackProcess(proxyInfo, unit, response);
    }

}
