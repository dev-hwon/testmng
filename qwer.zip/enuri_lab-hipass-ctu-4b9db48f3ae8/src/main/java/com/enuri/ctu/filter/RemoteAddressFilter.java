package com.enuri.ctu.filter;

import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
public class RemoteAddressFilter extends OncePerRequestFilter {
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        final String requestURI = request.getRequestURI();
        return requestURI.contains("/docs");
    }

    /**
     * <pre>
     *      original source: com.enuri.controller.CtuController::ctuGetDataCtlReal
     *      line: 243 ~ 247
     *
     *      if(!(strIp.startsWith("10.10.10.") || strIp.startsWith("100.100.") || strIp.startsWith("0:0:0:0:0:0:0:1") || strIp.startsWith("192.168.213.") || strIp.startsWith("127.0.0.1"))){
     * 			//System.out.println("==============not allow ip:"+strIp);
     * 			 logModule.LogPrint("#####################not allow ip: "+ipType);
     * 			return "not allow ip:"+strIp;
     *      }
     * </pre>
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        final String ipWithPort = request.getRemoteAddr() + ":" + request.getRemotePort();
        final IpType ipType = CommonUtil.getIpTypeFromRequest(request);
        log.info("IP TYPE : {}", ipType.name());

        if (IpType.NOT_ALLOWED_IP_TYPE == ipType) {
            log.warn("Not Allowed IP: " + ipWithPort);
            return;
        }

        filterChain.doFilter(new CustomRequestWrapper(request, ipType), response);
    }


}
