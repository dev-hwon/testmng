package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;

interface WeMapUrlConverter {
    ReplacedUrlLink refine(CrawlingParameter param, GatheringInfo gatheringInfo);

    default void replaceGtrGoodsCode(ReplacedUrlLink refinedCrawlingUrl) {
        String replacedUrlLink = refinedCrawlingUrl.getUrlLink()
                .replace("GTR_GOODS_CODE", refinedCrawlingUrl.getGtrGoodsCode());
        refinedCrawlingUrl.setUrlLink(replacedUrlLink);
    }
}
