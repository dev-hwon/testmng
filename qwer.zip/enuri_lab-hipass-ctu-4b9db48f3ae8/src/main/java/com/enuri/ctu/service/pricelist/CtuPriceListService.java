package com.enuri.ctu.service.pricelist;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.CrawlProcessResult;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.dto.promotion.PromotionResult;
import com.enuri.ctu.service.promotion.PromotionService;
import com.enuri.ctu.service.rules.DeliveryInfoRuleFactory;
import com.enuri.ctu.util.PriceListGenerator;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class CtuPriceListService implements PriceListService {

    private final DeliveryInfoRuleFactory deliveryInfoRuleFactory;
    private final PromotionService promotionService;

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 459 ~ 616
     * </pre>
     */
    @Override
    @LoggingProcessTime
    public PriceListCollection setUpPriceLists(CrawlProcessResult crawlProcessResult, TblPriceListDataVO originalPriceList) {
        ResultDataSub resultDataSub = (ResultDataSub) crawlProcessResult.getCommonResponse().getResultData();
        PriceListCollection priceListCollection = this.generatePriceCollection(crawlProcessResult.getCrawlingParameter(), originalPriceList, resultDataSub);
        // delivery price
        this.setPriceListDelivery(resultDataSub, crawlProcessResult.getCrawlingParameter(), priceListCollection, originalPriceList);

        // promotion
        PromotionResult promotionResult = null;
        if (priceListCollection.getPriceList().getPlNo() != null) {
             promotionResult = this.promotionService.getCtuPromotion(priceListCollection.getPriceList(), originalPriceList, crawlProcessResult.getCrawlingParameter());
        }

        if (promotionResult != null && !promotionResult.isEmpty()) {
            if (StringUtils.hasText(promotionResult.getCoupon())) {
                resultDataSub.setCoupon("1");
                priceListCollection.getOraclePriceList().setCoupon(1L);
                priceListCollection.getSqlPriceList().setPlCoupon(1L);
            }

            if (StringUtils.hasText(promotionResult.getPromotionPrice()) &&
                    Long.parseLong(promotionResult.getPromotionPrice()) > 0) {
                priceListCollection.getPriceList().setPrice(Long.parseLong(promotionResult.getPromotionPrice()));
            }

            if (StringUtils.hasText(promotionResult.getPromotionCardPrice()) &&
                    Long.parseLong(promotionResult.getPromotionCardPrice()) > 0) {
                priceListCollection.getPriceList().setPriceCard(Long.parseLong(promotionResult.getPromotionCardPrice()));
            }

            ShopCode shopCode = ShopCode.getShopCode(crawlProcessResult.getCrawlingParameter().getShopCode());
            if (ShopCode.AK_MALL != shopCode && promotionResult.getResultMessage() != null &&
                    ResultMessageCode.SUCCESS_PROMOTION == promotionResult.getResultMessage()) {
                crawlProcessResult.getCommonResponse().setResultMsg(ResultMessageCode.SUCCESS_PROMOTION);
            }

            crawlProcessResult.getCommonResponse().setResultDataPromotion(promotionResult);
        }

        return priceListCollection;
    }

    private PriceListCollection generatePriceCollection(CrawlingParameter param, TblPriceListDataVO originalPriceList,
                                                        ResultDataSub resultDataSub) {
        // TblPriceLIst setting
        TblPriceList priceList = PriceListGenerator.ofParam(param, originalPriceList, resultDataSub);

        TblPriceList oraclePriceList = PriceListGenerator.copyForOracle(originalPriceList);
        MsSqlPriceList sqlPriceList = PriceListGenerator.copyForMsSql(originalPriceList);

        long plNo = StringUtils.hasText(param.getPlNo())? Long.parseLong(param.getPlNo()) : originalPriceList.getPlNo();
        MsSqlPriceList priceListLog = MsSqlPriceList.builder()
                .plNo(plNo)
                .plModelno(originalPriceList.getModelNo())
                .build();
        return new PriceListCollection(priceList, oraclePriceList, sqlPriceList, priceListLog);
    }

    private boolean verifyPrice(TblPriceList priceList) {
        return priceList.getPrice() != null && priceList.getPrice() != 0L;
    }

    private void setPriceListDelivery(ResultDataSub resultDataSub, CrawlingParameter param,
                                      PriceListCollection collection, TblPriceListDataVO originalPriceList) {

        if (resultDataSub.getDeliveryPrice() != null) {
            TblPriceList priceList = collection.getPriceList();
            ShopCode shopCode = ShopCode.getShopCode(param.getShopCode());
            final String deliveryMessage= resultDataSub.getDeliveryPrice().toString();
            long crawlingPrice = verifyPrice(priceList)? priceList.getPrice() : originalPriceList.getPrice();

            DeliveryInfoParam deliveryInfoParam = DeliveryInfoParam.builder()
                    .deliveryMessage(deliveryMessage)
                    .crawlingPrice(crawlingPrice)
                    .param(param)
                    .originalPriceList(originalPriceList)
                    .priceList(priceList)
                    .build();

            DeliveryInfoClass deliveryInfoClass = this.deliveryInfoRuleFactory
                    .getDeliveryInfoRule(shopCode)
                    .getDeliveryInfo(deliveryInfoParam);

            if (StringUtils.hasText(deliveryInfoClass.getDeliveryInfo())) {
                resultDataSub.setDeliveryPrice(deliveryInfoClass.getDeliveryInfo());
            }

            collection.getOraclePriceList().setDelivery(deliveryInfoClass);
            priceList.setDelivery(deliveryInfoClass);
            collection.getSqlPriceList().setDelivery(deliveryInfoClass);
        }
    }

}
