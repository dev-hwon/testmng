package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.CtuRegExpVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OracleRegExpDao {

    List<CtuRegExpVO> fetchRegExpList(long gtrCode, String regexpDivis, String testCk);

    // getDbRegexpListInfoCorePc
    List<CtuRegExpVO> fetchRegExpListForPc(long shopCode, long gtrCode, String regexpDivis, String testCk);

    // getDbRegexpListInfoCoreMobileY
    List<CtuRegExpVO> fetchRegExpListForMobileY(long shopCode, long gtrCode, String regexpDivis, String testCk);

    // getDbRegexpListInfoCoreMobileN
    List<CtuRegExpVO> fetchRegExpListForMobileN(long shopCode, long gtrCode, String regexpDivis, String testCk);

    List<CtuRegExpVO> fetchRegExpListForLocal(long shopCode, long gtrCode, String regexpDivis, String testCk);
}
