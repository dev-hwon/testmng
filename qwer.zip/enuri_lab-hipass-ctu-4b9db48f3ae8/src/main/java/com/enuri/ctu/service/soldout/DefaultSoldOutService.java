package com.enuri.ctu.service.soldout;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dao.eloc.MsSqlElocPriceListDao;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.autotest.AutoTestService;
import com.enuri.ctu.service.nuribot.NuriBotService;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class DefaultSoldOutService implements SoldOutService {

    private final MsSqlElocPriceListDao msSqlElocPriceListDao;
    private final AutoTestService autoTestService;
    private final NuriBotService nuriBotService;


    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 693 ~
     * </pre>
     */
    @Override
    @LoggingProcessTime
    public void soldOutProcess(NuriBotLog nuriBotLog, CrawlingParameter param, Long modelMinPrice) {
        AutoTestLogDto autoTestLog = param.getAutoTestLog();
        TblPriceListDataVO originalPriceList = param.getTblPriceListData();

        log.info("CTU PC MSSQL SOLDOUT UPDATE START");
        this.updateToMsSql(originalPriceList);
        log.info("CTU PC MSSQL SOLDOUT UPDATE END");

        nuriBotLog.setLogoType("1");
        nuriBotLog.setServiceType(param.getDevice().getCode());

        String serviceDivis = SystemType.getServiceDivisBySystemType(param.getSystemType());
        nuriBotLog.setServiceDivis(serviceDivis);
        nuriBotLog.setOrgPrice(originalPriceList.getPrice());
        nuriBotLog.setMinPrice(modelMinPrice);

        if (param.isRealTest() && autoTestLog.getTestCode() != 0 && "6".equals(param.getDivis())) {
            this.autoTestService.updateSoldOut(autoTestLog, originalPriceList.getStatus());
            throw new CtuException(ResultMessageCode.SOLD_OUT);
        }

        if (!"5".equals(originalPriceList.getStatus()) && DeviceType.PC == param.getDevice()) {
            boolean isEqualPrice = originalPriceList.getPrice().equals(modelMinPrice);
            this.nuriBotService.setSoldOutLog(nuriBotLog, isEqualPrice);
        }

    }

    private void updateToMsSql(TblPriceListDataVO originalPriceList) {
        MsSqlPriceList msSqlSoldOutPriceList = MsSqlPriceList.builder()
                .plVcode(originalPriceList.getShopCode())
                .plNo(originalPriceList.getPlNo())
                .plGoodscode(originalPriceList.getGoodsCode())
                .plStatus("5")
                .build();

        this.msSqlElocPriceListDao.updateStatus(msSqlSoldOutPriceList);
        this.msSqlElocPriceListDao.setDbPlDateUpdate(msSqlSoldOutPriceList);
    }
}
