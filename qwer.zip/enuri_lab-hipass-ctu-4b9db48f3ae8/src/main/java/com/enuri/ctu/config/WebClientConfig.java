package com.enuri.ctu.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;

@Configuration
public class WebClientConfig {

    @Bean("connectionProvider")
    public ConnectionProvider nettyConnectionProvider() {
        return ConnectionProvider.builder("ctu-custom-provider")
                .maxConnections(ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS)
                .evictInBackground(Duration.ofSeconds(60))
                .lifo()
                .build();
    }

    @Bean("exchangeStrategies")
    public ExchangeStrategies exchangeStrategies() {
        return ExchangeStrategies.builder()
                .codecs(conf -> conf.defaultCodecs().maxInMemorySize(-1))
                .build();
    }
}
