package com.enuri.ctu.scheduler;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.service.savegoods.SaveGoodsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class MemberSaveGoodsScheduler {

    private final SaveGoodsService saveGoodsService;

    @Value("${ctu.default-ctu-test}")
    private String envCtuTest;

    /**
     * <pre>
     * SchedulerLock :
     * 같은 소스의 여러 application 이 동작중일때 같은 schedule time 을 가지는 배치가 동작하지 않도록
     * (단 하나의 배치 프로세스만 동작하도록) CTU_LOG DB의 shedlock table에 Lock 을 걸어둠
     * @see com.enuri.ctu.config.SchedulerConfig
     *
     * </pre>
     */
    @Scheduled(cron = "0 0 6-23/6 * * *")
    @SchedulerLock(
            name = "MemberSaveGoodsTask",
            lockAtLeastFor = "PT10M",   // 잠금을 유지해야 하는 시간
            lockAtMostFor = "PT11M"     // 잠금을 유지해야 하는 최소 시간
    )
    public void saveGoodsTask() {
        CtuTest ctuTest = CtuTest.getCtuTest(this.envCtuTest);
        IpType ipType = IpType.DEVELOPMENT;
        if (CtuTest.RELEASE == ctuTest) {
            ipType = IpType.PRODUCTION;
        }

        log.info("구독 CTU Scheduler Start : CTU_TEST[{}], IP_TYPE[{}]", ctuTest.getCode(), ipType.name());
        this.saveGoodsService.saveGoodsProcess(ctuTest, ipType);
        log.info("구독 CTU Scheduler Complete");
    }
}
