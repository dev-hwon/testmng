package com.enuri.ctu.constant;

import com.fasterxml.jackson.annotation.JsonValue;

// todo 중복/불필요 코드 정리
public enum ResultMessageCode {
    SUCCESS("SUCCESS", null),
    SUCCESS_PROMOTION("SUCCESS(Promotion Price Deny)", null),

    DUPLICATE_CALL("Duplicate call", null),
    NO_PRODUCT("No product information", "Not found Data In Oracle TblPriceLIst"),
    SOLD_OUT("Sold out", null),
    NOT_APPLICABLE("Not Applicable", "Parsing Data Not Found1"),
    INTENDED_FAIL("INTENDED_FAIL", "shopJobData Not Found Data"),
    INTERPARK_EXCEPTION("Interpark exception", null),
    CATEGORY_DENY("Category Deny", null),
    REAL_TEST_DELIVERY_PRICE("RealTest: Delivery Price", null),
    REAL_TEST_COUPON("RealTest: Coupon", null),
    REAL_TEST_CARD_PRICE("RealTest: CardPrice", null),
    REAL_TEST_NORMAL_PRICE("RealTest: NormalPrice", null),
    REAL_TEST_SALE_PRICE("RealTest: SalePrice", null),

    FAIL("FAIL", null),
    FAIL_URL_DENY("FAIL_URL Deny", null),
    FAIL_CATEGORY_DENY("FAIL_Category Deny", null),
    FAIL_EMART_PROMOTION("FAIL_EMART_PROMOTION", "Contains Keyword"),

    FAIL_0("FAIL0", "timeout2"),
    FAIL_1("FAIL1", "no crawling data"),
    FAIL_2("FAIL2", null),
    FAIL_3("FAIL3", "ctuRegExp Not Found Data"),
    FAIL_4("FAIL4", "ctuGathering Info Not Found Data"),
    FAIL_5("FAIL5", "ctuHeader Not Found Data"),
    FAIL_6("FAIL6", "ctuRegExp Not Found Data"),
    FAIL_8("FAIL8", "timeout"),
    FAIL_9("FAIL9", "Connect Time Out"),

    FAIL_10("FAIL10", "Connect Time Out2"),
    FAIL_11("FAIL11", "It has failed to crawl to the ShoppingMall(tmon)"),
    FAIL_12("FAIL12", "Parsing Data Not Found3"),
    FAIL_13("FAIL13", "Connect Time Out3"),
    FAIL_14("FAIL14", "Connect Time Out4"),
    FAIL_15("FAIL15", "It has failed to crawl to the ShoppingMall2(tmon)"),
    FAIL_16("FAIL16", "Parsing Data Not Found2"),
    FAIL_17("FAIL17", "NO DATA"),
    FAIL_18("FAIL18", null),

    FAIL_20("#FAIL20", "필수값이 null 일 경우"),
    FAIL_21("FAIL21", "Not found Data In Oracle TblPriceList"),
    FAIL_22("FAIL22", null),
    FAIL_23("FAIL23", "Not found Data In TblMobileDealVer2"),
    FAIL_24("FAIL24", "Crawling Gathering Info Not Found"),
    FAIL_25("FAIL25", "Goods Url Not Found"),
    FAIL_26("FAIL26", "goodsUrl incorrect"),
    FAIL_27("FAIL27", null),
    FAIL_28("FAIL28", "Crawling Gathering Info Not Found"),
    FAIL_29("FAIL29", null),

    FAIL_30("FAIL30", null),
    FAIL_31("FAIL31", "Not found Data In TBL_CRAZY_DEAL_REAL"),
    FAIL_32("FAIL32", "Crawling Gathering Info Not Found"),
    FAIL_33("FAIL33", "TBL_CRAZY_DEAL_REAL Goods Url Not Found"),
    FAIL_34("FAIL34", "TBL_CRAZY_DEAL_REAL goodsUrl incorrect"),

    FAIL_6620("FAIL_6620", "MINIBOT_X")
    ;

    private final String message;
    private final String data;

    ResultMessageCode(String message, String data) {
        this.message = message;
        this.data = data;
    }

    @JsonValue
    public String getMessage() {
        return message;
    }

    public String getData() {
        return data;
    }

    public static boolean isSuccess(ResultMessageCode resultMessageCode) {
        return resultMessageCode == ResultMessageCode.SUCCESS ||
                resultMessageCode == ResultMessageCode.SUCCESS_PROMOTION;
    }
}
