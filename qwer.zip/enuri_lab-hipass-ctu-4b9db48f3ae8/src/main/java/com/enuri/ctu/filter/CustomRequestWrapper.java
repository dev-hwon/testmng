package com.enuri.ctu.filter;

import com.enuri.ctu.constant.IpType;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class CustomRequestWrapper extends HttpServletRequestWrapper {
    /*
     https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/web/bind/WebDataBinder.html#DEFAULT_FIELD_DEFAULT_PREFIX
     provide a default value instead of an empty value.
     */
    private static final String KEY_IP_TYPE = "!ip_type";

    private final IpType ipType;

    public CustomRequestWrapper(HttpServletRequest request, IpType ipType) {
        super(request);
        this.ipType = ipType;
    }

    @Override
    public String getParameter(String name) {
        if (KEY_IP_TYPE.equals(name)) {
            // return LOCAl, DEVELOPMENT, PRODUCTION
            return this.ipType.name();
        }

        return super.getParameter(name);
    }

}
