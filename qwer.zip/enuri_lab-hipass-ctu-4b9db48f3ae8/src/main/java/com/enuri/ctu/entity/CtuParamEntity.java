package com.enuri.ctu.entity;

import com.enuri.ctu.util.CommonUtil;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;

/**
 * KEY : shop_code/goods_code/device
 * VALUE : local date time(yyyy-MM-dd HH:mm:ss)
 * EXPIRE : 600 seconds (10 min)
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
@RedisHash(timeToLive = 600)
public class CtuParamEntity implements Serializable {

    @Id
    private String id;
    private String value;

    public CtuParamEntity(CtuParamVOWrapper ctuParamVO) {
        this.id = ctuParamVO.getShopCode() + "/" + ctuParamVO.getGoodsCode() + "/" + ctuParamVO.getDevice().getCode();
        this.value = CommonUtil.getLocalDateTime();
    }
}
