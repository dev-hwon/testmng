package com.enuri.ctu.service.crawling;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;

public interface PreCrawlingService {

    CrawlingUnit getCrawlingUnit(CrawlingParameter parameter);
}
