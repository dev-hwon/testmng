package com.enuri.ctu.service.parse;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.ShopJob;
import com.enuri.ctu.dto.parse.AsyncParsingParameter;
import com.enuri.ctu.dto.parse.AsyncParsingResult;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.service.rules.ResultDataRuleFactory;
import com.enuri.ctu.vo.CtuRegExpVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CtuParsingService implements ParsingService {

    private final PreParsingService preParsingService;
    private final ResultDataRuleFactory resultDataRuleFactory;
    private final AsyncParser asyncParser;

    @Override
    @LoggingProcessTime
    public ResultDataSub parse(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        if (!StringUtils.hasText(crawlingResult)) {
            return new ResultDataSub();
        }

        ParsingResult parsingResult = this.preParsingService.preParse(param, unit, crawlingResult);

        RequestService service = param.getService();
        int interParkType = unit.getReplacedUrlLink().getInterParkType();
        DeviceType deviceType = param.getDevice();

        ShopCode shopCode = ShopCode.getShopCode(param.getShopCode());
        String htmlData = parsingResult.getCtuHtmlData();

        // line: 609 ~ 611
        if (ShopCode.isLotte(shopCode)) {
            htmlData = parsingResult.getLotteTotalCtuHtmlData();
        }

        ResultDataSub resultDataSub = new ResultDataSub();
        List<CompletableFuture<AsyncParsingResult>> asyncFutureList = new ArrayList<>();

        log.info("HTML SIZE : {} bytes", crawlingResult.getBytes(StandardCharsets.UTF_8).length);
        log.info("RegExp SIZE : {}", unit.getRegExpList().size());

        for (CtuRegExpVO regExpVO : unit.getRegExpList()) {
            AsyncParsingParameter asyncParsingParameter = AsyncParsingParameter.builder()
                    .shopCode(shopCode)
                    .service(service)
                    .interParkType(interParkType)
                    .deviceType(deviceType)
                    .htmlData(htmlData)
                    .regExpVO(regExpVO)
                    .build();

            asyncFutureList.add(this.asyncParser.extractParsingValue(asyncParsingParameter));
        }

        List<AsyncParsingResult> join = CompletableFuture
                .allOf(asyncFutureList.toArray(new CompletableFuture[0]))
                .thenApply(result -> asyncFutureList.stream()
                        .map(CompletableFuture::join)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList()
                    )
                )
                .join();

        for (AsyncParsingResult result : join) {
            final String extractedData = result.getExtractedData();
            final String regexpDivis = result.getRegexpDivis();
            final String regexpRetType = result.getRegExpReturnType();

            // line: 677 ~ 696 : retType 에 따라 데이터 타입이 결정
            if (StringUtils.hasText(extractedData) && StringUtils.hasText(regexpDivis)) {
                Object data;
                if ("1".equals(regexpRetType)) {
                    data = Integer.parseInt(extractedData);
                } else if ("2".equals(regexpRetType)) {
                    data = Long.parseLong(extractedData);
                } else {
                    data = extractedData;
                }
                resultDataSub.assignValue(result.getKey(), data);
            }

            if (result.isHasDeliveryPrice()) {
                resultDataSub.setDeliveryPrice(result.getDeliveryPrice());
            }
        }


        log.info("ResultDataSub : {}", resultDataSub);

        // shopCode 별 resultDataSub 설정 -> resultDataSub 의 value 를 변경(void)
        this.resultDataRuleFactory.getResultDataRule(shopCode)
                .adjustResultDataSub(resultDataSub, htmlData, service, unit);

        // coupon
        if (this.isNeedCouponToZero(resultDataSub, service, deviceType, unit.getShopJobData())) {
            resultDataSub.setCoupon(0L);
        }

        // wmpType
        if (StringUtils.hasText(parsingResult.getWmpType())) {
            resultDataSub.setWmpType(parsingResult.getWmpType());
        }

        log.info("ResultDataSub Adjust by ShopCode[{}] : {}", shopCode, resultDataSub);

        return resultDataSub;
    }





    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 719 ~ 723
     * </pre>
     */
    public boolean isNeedCouponToZero(ResultDataSub resultDataSub, RequestService service, DeviceType deviceType,
                                      ShopJob shopJob) {
        return !resultDataSub.isEmpty() &&
                resultDataSub.getCoupon() == null &&
                resultDataSub.getAdult() == null &&
                RequestService.isHomePage(service) &&
                DeviceType.PC == deviceType &&
                Boolean.TRUE.equals(shopJob.getCouponYn());
    }
}
