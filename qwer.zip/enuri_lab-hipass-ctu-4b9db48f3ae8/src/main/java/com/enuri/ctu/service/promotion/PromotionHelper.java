package com.enuri.ctu.service.promotion;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.PromotionOperator;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.dto.promotion.PromotionResult;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.CtuPromotionVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

@Component
public class PromotionHelper {

    private static final List<ShopCode> COUPON_YES_SHOP =
            Stream.of(ShopCode.H_MALL, ShopCode.CJ_MALL, ShopCode.EL_LOTTE, ShopCode.HI_MART)
            .collect(collectingAndThen(toList(), Collections::unmodifiableList));

    /**
     * <pre>
     * source: com.enuri.service.CtuPromotionService::svrCtuPromotion
     * line: 96 ~ 169
     * </pre>
     */
    public PromotionResult getPromotionResult(String promotionValue, CtuPromotionVO saleInfo, CtuPromotionVO rateInfo,
                                              TblPriceListDataVO originalPriceList, TblPriceList priceList,
                                              CrawlingParameter param) {

        double promotionLongValue = Double.parseDouble(promotionValue);
        boolean lessThanValue = Double.parseDouble(saleInfo.getPriceMinPercent()) < promotionLongValue;
        boolean greaterOrEqualValue = Double.parseDouble(saleInfo.getPriceMaxPercent()) >= promotionLongValue;

        if (!lessThanValue || !greaterOrEqualValue) {
            return PromotionResult.builder().build();
        }

        PromotionResult result = PromotionResult.builder().build();
        ShopCode shopCode = ShopCode.getShopCode(originalPriceList.getShopCode());
        if (COUPON_YES_SHOP.contains(shopCode) && DeviceType.PC == param.getDevice()) {
            result.setCoupon("1");
            priceList.setCoupon(1L);
        }

        if (StringUtils.hasText(saleInfo.getPromotionDivide()) && "1".equals(saleInfo.getPromotionDivide())) {
            result.setResultMessage(ResultMessageCode.SUCCESS_PROMOTION);
            result.setPromotionRate(promotionValue);

            if (priceList.getPrice() == null) {
                return result;
            }

            double price = Double.parseDouble(priceList.getPrice().toString());
            double cardPrice = priceList.getPriceCard() == null? 0 : Double.parseDouble(priceList.getPriceCard().toString());
            double promotionRoundLength = rateInfo == null? 1 : Double.parseDouble(rateInfo.getRoundLength());

            String promotionAppliedPrice =
                    String.valueOf(this.calculatePrice(promotionLongValue, price, promotionRoundLength, rateInfo));
            String promotionAppliedCardPrice =
                    String.valueOf(this.calculatePrice(promotionLongValue, cardPrice, promotionRoundLength, rateInfo));

            result.setPromotionPrice(promotionAppliedPrice);
            result.setCoupon(promotionAppliedCardPrice);
        }

        return result;
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuPromotionService::svrCtuPromotion
     * line: 80 ~ 91
     * </pre>
     */
    public String getPromotionValue(TblPriceListDataVO originalPriceList, ShopCode shopCode, RequestService service,
                                    CtuPromotionVO saleInfo) {
        String goodsNm = originalPriceList.getGoodsNm();
        if (saleInfo == null || !StringUtils.hasText(goodsNm)) {
            return "";
        }

        String promotionValue;
        if (ShopCode.H_MALL == shopCode && RequestService.HOMEPAGE == service) {
            String trimGoodsName = goodsNm.replace(" ", "");
            promotionValue = RegExpUtils.getRegExpData(trimGoodsName, saleInfo.getPriceRegexpStr());
        } else {
            promotionValue = RegExpUtils.getRegExpData(goodsNm, saleInfo.getPriceRegexpStr());
        }

        return promotionValue;
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuPromotionService::svrCtuPromotion
     * line: 131 ~ 164
     * </pre>
     */
    public int calculatePrice(double promotionValue, double price, double promotionRoundLength, CtuPromotionVO rateInfo) {
        double promotionApplied = price * (100 - promotionValue) / 100;

        if (rateInfo != null && "Y".equals(rateInfo.getPriceCalculation()) && StringUtils.hasText(rateInfo.getRoundDivide())) {
            PromotionOperator operator = PromotionOperator.getOperator(rateInfo.getRoundDivide());
            if (operator != null) {
                promotionApplied = operator.calc(promotionApplied, promotionRoundLength);
            }
        }

        return (int) promotionApplied;
    }
}
