package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.TblPriceListDataVO;
import org.apache.ibatis.annotations.Mapper;

import javax.annotation.Nonnull;
import java.util.List;

@Mapper
public interface OraclePriceListDao {

    TblPriceListDataVO fetchTblPriceListData(@Nonnull Long shopCode, String goodsCode, String plNo);

    List<TblPriceListDataVO> fetchTblPriceDivideGoods(@Nonnull Long shopCode, String goodsCode, Long plNo);

    void setDbTblPriceListUpdate(TblPriceList priceList);

    Long fetchSmartStoreShopCodeByGoodsCode(@Nonnull String goodsCode);

}
