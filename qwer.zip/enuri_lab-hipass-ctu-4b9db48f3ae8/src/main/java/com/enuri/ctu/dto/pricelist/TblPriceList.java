package com.enuri.ctu.dto.pricelist;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * <pre>
 * source: com.enuri.vo.main.pricelist.TblPriceList
 * DB 에 저장될 PriceListDto
 * </pre>
 */
@Data
@Builder
public class TblPriceList {
    private Long modelno;
    private Long shopCode;
    private Long shopCodeSub; //SR48189
    private String goodsnm;
    private String caCode;
    private Long price;
    private String url;
    private String note;
    private String srvflag;
    private String status;
    private String etc;
    private String authflag;
    private String authdate;
    private String soldflag;
    private String solddate;
    private String uDate;
    private String rightnleft;
    private String multiflag;
    private String multicomment;
    private String flag;
    private String esstockflag;
    private String esoptflag;
    private Long plNo;
    private String imgurl;
    private Long coupon;
    private Long authvcode;
    private String jobtype;
    private Long stockcount;
    private Long regterm;
    private String origin;
    private String delfeetype;
    private String delfeedesc;
    private String delareadesc;
    private Long basisto;
    private String deliveryflag;
    private String airconfeetype;
    private Long basisfrom;
    private Long delprice;
    private String delareatype;
    private String aircondesc;
    private String specflag;
    private String accountYn;
    private String imgurlflag;
    private Long instancePrice;
    private String pjobcode;
    private Long finalusedflag;
    private String goodsfactory;
    private String goodscode;
    private String searchflag;
    private String deliveryinfo;
    private String subsideLevel;
    private String nointMonth;
    private String nointSdate;
    private String nointEdate;
    private Long cashback;
    private Long subside;
    private String freeinterest;
    private Long agreeMonth;
    private Long popular;
    private String homeflag;
    private String openSeller;
    private String deliveryinfo2;
    private String deliverytype2;
    private Long priceCard;
    private String optionFlag;
    private String optionFlag2;
    private String catalogFlag;
    private String powerFlag;
    private String bidFlag;
    private String enuriUserId;
    private String priceFlag;
    private String deliveryLev;
    private String setYn;
    private String storeFlag;
    private String caCodeDept;
    private String goodsbrand;
    private String mobileFlag;
    private String mobileBidFlag;
    private String delvValue;
    private List<String> exceptionPlNo;

    public void setDelivery(DeliveryInfoClass deliveryInfoClass) {
        this.deliveryinfo = deliveryInfoClass.getDeliveryInfo();
        this.deliveryinfo2 = deliveryInfoClass.getDeliveryInfo2();
        this.deliverytype2 = deliveryInfoClass.getDeliveryType2();
        this.rightnleft = deliveryInfoClass.getRightnLeft();
    }
}
