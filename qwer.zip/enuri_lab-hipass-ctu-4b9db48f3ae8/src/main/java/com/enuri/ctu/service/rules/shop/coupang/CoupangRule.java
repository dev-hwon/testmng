package com.enuri.ctu.service.rules.shop.coupang;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.util.RegExpUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class CoupangRule implements ShopRule {

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        if (RequestService.HOMEPAGE != param.getService()) {
            return ShopRule.super.replaceProxyUrlLink(param, gatheringInfo);
        }

        String gtrUrl = gatheringInfo.getGtrUrl();
        String url = param.getUrl();
        String urlLink = CoupangUrlConverter.convertUrl(gtrUrl, url, param.getGoodsCode());

        gatheringInfo.setGtrUrl(urlLink);

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }

    @Override
    public ReplacedUrlLink replaceNonProxyUrlLink(CrawlingParameter parameter, GatheringInfo gatheringInfo) {
        final Long shopCode = parameter.getShopCode();
        final String goodsCode = parameter.getGoodsCode();
        StringBuilder urlBuilder = new StringBuilder("http://cws.enuri.com/cws/getCwsData.cws?shopCode=");
        urlBuilder.append(shopCode);
        urlBuilder.append("&goodsCode=");
        urlBuilder.append(goodsCode);
        urlBuilder.append("&device=");
        urlBuilder.append(parameter.getDevice().getCode());

        String urlLink = CoupangUrlConverter.convertUrl(gatheringInfo.getGtrUrl(), parameter.getUrl(), goodsCode);
        String encodedUrlLink;
        try {
            encodedUrlLink = URLEncoder.encode(urlLink, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new CtuException(ResultMessageCode.FAIL);
        }

        urlBuilder.append("&service=1&cwsType=2&gtrOrder=1&ctuTest=N&batchNumber=1&isbn=&modelCode=&cateNo=&siteNo=&salestrNo=&goodsUrl=");
        urlBuilder.append(encodedUrlLink);

        return ReplacedUrlLink.builder()
                .urlLink(urlBuilder.toString())
                .gtrGoodsCode(goodsCode)
                .build();
    }

    /**
     * <pre>
     * part 1.
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 712 ~ 717
     *
     * part 2.
     * source: com.enuri.common.service.CtuService::svrMainCtuProcReal
     * line: 377 ~ 408
     *
     * part 3.
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 542 ~ 548
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service,
                                    CrawlingUnit unit) {
        // part 1
        if (resultDataSub.getInstChargePrice() != null) {
            resultDataSub.setSalePrice(null);
            resultDataSub.setNormalPrice(null);
        }

        // part 2
//        if (DeviceType.isMobile(unit.getParamDevice().getCode())) {
//            this.adjustForMobile(resultDataSub);
//        }

        // part 3
        if (resultDataSub.getDeliveryPrice() != null &&
                resultDataSub.getDeliveryPrice().toString().contains("로켓")) {
            resultDataSub.setDeliveryPrice(null);
        }
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 462 ~ 484
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (StringUtils.hasText(deliveryMessage) && deliveryMessage.contains("이상")) {
            Pattern pt = Pattern.compile("(\\d*)이상구매시\\)그외배송비(\\d*)");
            Matcher mc = pt.matcher(deliveryMessage);

            DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
            if (mc.find()) {
                String s = mc.group(1);
                if ((StringUtils.hasText(s) && Long.parseLong(s) > deliveryInfoParam.getOriginalPriceList().getPrice())) {
                    String delvPriceCondition = mc.group(2);
                    deliveryInfoClass.setDeliveryInfo(delvPriceCondition);
                    deliveryInfoClass.setDeliveryInfo2(delvPriceCondition);
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("2");
                } else {
                    deliveryInfoClass.setDeliveryInfo("무료배송");
                    deliveryInfoClass.setDeliveryInfo2("0");
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("1");
                }
            }

            return deliveryInfoClass;
        }

        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    private void adjustForMobile(ResultDataSub resultDataSub) {
        if (resultDataSub.getNormalPrice() != null){
            Object normalPrice = resultDataSub.getNormalPrice();
            resultDataSub.setNormalPrice(RegExpUtils.numberOnly(normalPrice));
        }

        if (resultDataSub.getSalePrice() != null) {
            Object salePrice = resultDataSub.getSalePrice();
            resultDataSub.setSalePrice(RegExpUtils.numberOnly(salePrice));
        }

        if (resultDataSub.getCardPrice() != null) {
            Object cardPrice = resultDataSub.getCardPrice();
            resultDataSub.setCardPrice(cardPrice);
        }

        if (resultDataSub.getSoldOut() != null) {
            Object soldOut = resultDataSub.getSoldOut();
            if (String.class.isAssignableFrom(soldOut.getClass())) {
                String strSoldOut = String.valueOf(soldOut);
                if ("1".equals(strSoldOut) || strSoldOut.contains("품절")) {
                    resultDataSub.setSoldOut(1);
                } else {
                    resultDataSub.setSoldOut(null);
                }
            }
        }
    }

}
