package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AutoTestLogVO {
    private Long testCode;
    private Long shopCode;
    private String shopName;
    private String divideCode;
    private String divideCodeName;
    private String divideName;
    private String goodsCode;
    private String resultPcOrg;
    private String resultPcUp;
    private String resultMobileOrg;
    private String resultMobileUp;
    private String lastProcTime;
    private String memo;
    private String status;
    private String addDate;
    private String modDate;
}
