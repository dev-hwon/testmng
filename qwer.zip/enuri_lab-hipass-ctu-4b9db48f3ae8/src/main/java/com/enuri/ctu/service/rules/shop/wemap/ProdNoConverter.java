package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;

class ProdNoConverter implements WeMapUrlConverter {

    @Override
    public ReplacedUrlLink refine(CrawlingParameter param, GatheringInfo gatheringInfo) {

        final String goodsCode = param.getGoodsCode();
        final String separator = "_";
        if (goodsCode.contains(separator)) {
            String[] split = goodsCode.split(separator);
            return this.refineWithSeparated(split, param.getDevice());
        }

        return null;
    }

    private ReplacedUrlLink refineWithSeparated(String[] split, DeviceType deviceType) {
        if (split[0].equals(split[1])) {
            ReplacedUrlLink replacedUrlLink = ReplacedUrlLink.builder()
                    .urlLink(this.getUrlLinkByDeviceType(deviceType))
                    .gtrGoodsCode(split[0])
                    .wmpType(1)
                    .build();
            this.replaceGtrGoodsCode(replacedUrlLink);
            return replacedUrlLink;
        }
        return null;
    }

    private String getUrlLinkByDeviceType(DeviceType deviceType) {
        if (DeviceType.MOBILE == deviceType) {
            return "https://mw.wemakeprice.com/product/GTR_GOODS_CODE?utm_source=enuri&utm_medium=PRICE_af&utm_campaign=null";
        }

        return "https://front.wemakeprice.com/product/GTR_GOODS_CODE?utm_source=enuri&utm_medium=PRICE_af&utm_campaign=null";
    }


}
