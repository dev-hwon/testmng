package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Slf4j
@Component
public class EMartMallRule implements ShopRule {

    @Override
    public ResultMessageCode checkOriginalPriceList(TblPriceListDataVO originalPriceList) {
        if (StringUtils.hasText(originalPriceList.getGoodsNm()) &&
                originalPriceList.getGoodsNm().contains("더블할인쿠폰")) {
            log.error("FAIL_EMART_PROMOTION");
            return ResultMessageCode.FAIL_EMART_PROMOTION;
        }
        return null;
    }

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String url = param.getUrl();
        String gtrShopType = RegExpUtils.getRegExpData(url, "http://(.*?).ssg.com/");
        String gtrSiteNo = RegExpUtils.getRegExpData(url, "siteNo=(.*?)&");
        String urlLink = gatheringInfo.getGtrUrl()
                .replace("GTR_SHOP_TYPE", gtrShopType)
                .replace("GTR_SITE_NO", gtrSiteNo);

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }
}
