package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.dao.oracle.OracleRegExpDao;
import com.enuri.ctu.dao.oracle.OracleShopJobDao;
import com.enuri.ctu.dto.crawling.RegExpParameter;
import com.enuri.ctu.dto.crawling.ShopJob;
import com.enuri.ctu.vo.CtuRegExpVO;
import com.enuri.ctu.vo.CtuShopJobVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class RegExpDataHandler {

    private final OracleShopJobDao oracleShopJobDao;
    private final OracleRegExpDao oracleRegExpDao;


    /**
     * line: 294 ~ 304
     */
    @Cacheable(
            value = "REG_EXP_LIST",
            key = "'getCtuRegExpList:' + #param.shopCode + #param.gtrCode + #param.regexpDivis + #param.testCk + #param.deviceType.code + #isMobileYn"
    )
    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 2,
            backoff = @Backoff(delay = 100)
    )
    public List<CtuRegExpVO> getCtuRegExpList(RegExpParameter param, boolean isMobileYn) {
        List<CtuRegExpVO> ctuRegExpVOList;
        final long shopCode = param.getShopCode();
        final long gtrCode = param.getGtrCode();
        final String regExpDivis = param.getRegexpDivis();
        final String testCk = param.getTestCk();

        log.info("Fetch RegExpList : SHOP_CODE[{}], GTR_CODE[{}], REG_EXP_DIVIS[{}], TEST_CK[{}], DEVICE[{}]",
                shopCode, gtrCode, regExpDivis, testCk, param.getDeviceType().getCode());

        if (IpType.LOCAL == param.getIpType()) {
            return this.oracleRegExpDao.fetchRegExpListForLocal(shopCode, gtrCode, regExpDivis, testCk);
        }

        if (DeviceType.PC == param.getDeviceType()) {
            ctuRegExpVOList = this.oracleRegExpDao.fetchRegExpListForPc(shopCode, gtrCode, regExpDivis, testCk);
        } else {
            if (isMobileYn) {
                ctuRegExpVOList = this.oracleRegExpDao.fetchRegExpListForMobileY(shopCode, gtrCode, regExpDivis, testCk);
            } else {
                ctuRegExpVOList = this.oracleRegExpDao.fetchRegExpListForMobileN(shopCode, gtrCode, regExpDivis, testCk);
            }
        }

        return ctuRegExpVOList;
    }

    /**
     * line: 274 ~ 278
     */
    @Cacheable(
            value = "SHOP_JOB",
            key = "'getShopJobData:' + #shopCode + #isSmartStore"
    )
    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public ShopJob getShopJobData(long shopCode, boolean isSmartStore) {
        CtuShopJobVO ctuShopJobVO;
        if (isSmartStore) {
            ctuShopJobVO = this.oracleShopJobDao.fetchSmartStoreShopJob(shopCode);
        } else {
            ctuShopJobVO = this.oracleShopJobDao.fetchShopJob(shopCode);
        }

        return ShopJob.of(ctuShopJobVO);
    }
}
