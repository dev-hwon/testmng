package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum CtuTest {
    ONLY_FOR_CRAWLER_TEST("Y"), // Only CrawlerTEST
    RELEASE("N"),               // N:RealProc - 운영
    REAL_TEST("RT");            // RealTest(TestTag Use and DB Update)

    private final String code;

    private static final ImmutableMap<String, CtuTest> CTU_TEST_MAP;

    static {
        Map<String, CtuTest> mutableMap = Arrays.stream(CtuTest.values())
                .collect(Collectors.toMap(CtuTest::getCode, e -> e));
        CTU_TEST_MAP = ImmutableMap.copyOf(mutableMap);
    }

    CtuTest(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static CtuTest getCtuTest(String code) {
        return CTU_TEST_MAP.get(code);
    }
}
