package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.EMartMallRule;
import com.enuri.ctu.service.rules.shop.coupang.CoupangRule;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.GalleriaRule;
import com.enuri.ctu.service.rules.shop.HomePlusRule;
import com.enuri.ctu.service.rules.shop.InterParkRule;
import com.enuri.ctu.service.rules.shop.lotte.LotteRule;
import com.enuri.ctu.service.rules.shop.shockingdeal.ShockingDealRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SmartStoreRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import com.enuri.ctu.service.rules.shop.timon.TimonRule;
import com.enuri.ctu.service.rules.shop.wemap.WeMapRule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ProxyReplaceUrlRuleFactory {
    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;

    private final ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        // get bean instance
        SsgRule ssgRuleBean = this.applicationContext.getBean(SsgRule.class);
        LotteRule lotteRuleBean = this.applicationContext.getBean(LotteRule.class);
        SmartStoreRule smartStoreRuleBean = this.applicationContext.getBean(SmartStoreRule.class);
        WeMapRule weMapRuleBean = this.applicationContext.getBean(WeMapRule.class);
        HomePlusRule homePlusRuleBean = this.applicationContext.getBean(HomePlusRule.class);
        ShockingDealRule shockingDealRuleBean = this.applicationContext.getBean(ShockingDealRule.class);
        TimonRule timonRuleBean = this.applicationContext.getBean(TimonRule.class);
        InterParkRule interParkRuleBean = this.applicationContext.getBean(InterParkRule.class);
        CoupangRule coupangRuleBean = this.applicationContext.getBean(CoupangRule.class);
        GalleriaRule galleriaRuleBean = this.applicationContext.getBean(GalleriaRule.class);
        EMartMallRule eMartMallRule = this.applicationContext.getBean(EMartMallRule.class);

        // ssg
        RULE_MAP.put(ShopCode.SSG_MALL, ssgRuleBean);
        RULE_MAP.put(ShopCode.SSG_DEPT, ssgRuleBean);

        // lotte
        RULE_MAP.put(ShopCode.LOTTE_ON, lotteRuleBean);
        RULE_MAP.put(ShopCode.EL_LOTTE, lotteRuleBean);
        RULE_MAP.put(ShopCode.LOTTE_MART_MALL, lotteRuleBean);

        // smart store
        RULE_MAP.put(ShopCode.SMART_STORE, smartStoreRuleBean);

        // wemap: we_make_price
        RULE_MAP.put(ShopCode.WEMAP, weMapRuleBean);

        // homeplus
        RULE_MAP.put(ShopCode.HOMEPLUS_DELIVERY_MALL, homePlusRuleBean);

        // shocking deal
        RULE_MAP.put(ShopCode.SHOCKING_DEAL, shockingDealRuleBean);

        // timon
        RULE_MAP.put(ShopCode.TIMON, timonRuleBean);

        // interpark
        RULE_MAP.put(ShopCode.INTERPARK, interParkRuleBean);

        // coupang
        RULE_MAP.put(ShopCode.COUPANG, coupangRuleBean);

        // galleria
        RULE_MAP.put(ShopCode.GALLERIA_MALL, galleriaRuleBean);

        // emart_mall
        RULE_MAP.put(ShopCode.EMART_MALL, eMartMallRule);

    }

    public ShopRule getUrlRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            shopRule = this.defaultShopRule;
        }

        return shopRule;
    }
}
