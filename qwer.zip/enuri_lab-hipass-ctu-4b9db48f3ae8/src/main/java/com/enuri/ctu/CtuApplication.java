package com.enuri.ctu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

@EnableRetry
@SpringBootApplication
public class CtuApplication {
    public static void main(String[] args) {
        SpringApplication.run(CtuApplication.class, args);
    }
}
