package com.enuri.ctu.service.soldout;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;

public interface SoldOutService {

    void soldOutProcess(NuriBotLog nuriBotLog, CrawlingParameter param, Long modelMinPrice);

}
