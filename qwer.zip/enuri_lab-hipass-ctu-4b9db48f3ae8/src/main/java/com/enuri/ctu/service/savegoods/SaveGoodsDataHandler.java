package com.enuri.ctu.service.savegoods;

import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.dao.oracle.OracleMemberSaveGoodsDao;
import com.enuri.ctu.dao.oracle.OraclePriceListDataHandler;
import com.enuri.ctu.vo.GoodsCodeVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class SaveGoodsDataHandler {

    private final OraclePriceListDataHandler oraclePriceListDataHandler;
    private final OracleMemberSaveGoodsDao memberSaveGoodsDao;
    private final CtuLogDao ctuLogDao;


    /**
     * TBL_MEMBER_SAVE_GOODS 구독 상품 테이블에서 modelno 조회
     * Size 가 크기 때문에 분할 조회
     */
    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public List<Long> getAllModelNo() {
//        final int defaultRegDateDays = 7;

        List<Long> alramModelList = this.memberSaveGoodsDao.fetchAllMemberModelNo();
        // n 일전 등록기준 모델 번호 리스트는 잠시 제거
//        List<Long> modelByRegDateList = this.memberSaveGoodsDao.fetchModelNoByRegDate(defaultRegDateDays);
//
//        List<Long> allModelNo = Stream
//                .concat(alramModelList.stream(), modelByRegDateList.stream())
//                .distinct()
//                .collect(Collectors.toList());

        if (alramModelList.isEmpty()) {
            log.error("MemberSavedGoods ModelNo is EMPTY");
            return new ArrayList<>();
        }

        log.info("초기 Model size : {}", alramModelList.size());

        return alramModelList;
    }


    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public List<GoodsCodeVO> getGoodsCode(long modelNo) {
        List<GoodsCodeVO> list = this.oraclePriceListDataHandler.getGoodsCodeByModelNo(modelNo)
                .stream()
                .filter(vo -> StringUtils.hasText(vo.getGoodsCode()))
                .collect(Collectors.toList());

        if (list.isEmpty()) {
            return new ArrayList<>();
        }

        this.ctuLogDao.insertModelNo(list);
        return list;
    }


}
