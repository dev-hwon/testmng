package com.enuri.ctu.dao.eloc;

import com.enuri.ctu.dto.nuribot.NuriBotLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MsElocNuribotLogDao {

    void setDbNuribotSoldOutLogInsert(NuriBotLog nuriBotLog);
    
}
