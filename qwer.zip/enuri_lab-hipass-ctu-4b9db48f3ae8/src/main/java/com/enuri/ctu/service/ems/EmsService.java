package com.enuri.ctu.service.ems;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.ems.EmsCall;

public interface EmsService {

    EmsCall checkPrice(ResultDataSub resultDataSub);

    void emsCall(Long modelNo, Long plNo, long emsCallPrice);
}
