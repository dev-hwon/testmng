package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.dao.newcws.NewCwsProxyInfoDao;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProxyDataHandler {
    private static final String DEFAULT_SERVICE_TYPE = "1";

    private final NewCwsProxyInfoDao newCwsProxyInfoDao;

    @Cacheable(value = "CPN_STATUS", key = "'getCpnStatus'")
    public String getCpnStatus() {
        return this.newCwsProxyInfoDao.getProxyCpnStatus(DEFAULT_SERVICE_TYPE);
    }

    @LoggingProcessTime
    public ProxyConnectInfoVO getRandomProxyConnectInfo(String cpnStatus) {
        if ("AA".equals(cpnStatus)) {
            return this.newCwsProxyInfoDao.fetchRandomProxyInfoOrderByFailCnt();
        }
        // yyyyMMdd
        LocalDate localDate = LocalDate.now().minusDays(1);
        String dateNo = localDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        return this.newCwsProxyInfoDao.fetchDefaultRandomProxyProxyInfo(cpnStatus, dateNo);
    }

    public ProxyConnectInfoVO getRandomEliteProxyInfo() {
        return this.newCwsProxyInfoDao.fetchRandomProxyInfo();
    }
}
