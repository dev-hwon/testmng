package com.enuri.ctu.dto.parse;

import com.enuri.ctu.dto.ResultDataSub;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ParsingResult {

    private ResultDataSub resultDataSub;
    private String wmpType;                 // todo CommonResponse 로 전달
    private String ctuHtmlData;
    private String lotteTotalCtuHtmlData;
}
