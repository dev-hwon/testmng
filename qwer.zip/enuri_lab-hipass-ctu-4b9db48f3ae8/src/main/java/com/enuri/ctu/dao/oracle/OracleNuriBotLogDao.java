package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.dto.nuribot.NuriBotLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleNuriBotLogDao {

    void setDbNuribotSoldOutLogInsert(NuriBotLog nuriBotLog);
    void setDbNuribotDeliveryLogInsert(NuriBotLog nuriBotLog);

    void setDbNuribotCouponLogInsert(NuriBotLog nuriBotLog);
    void setDbNuribotLogInsert(NuriBotLog nuriBotLog);
    void setDbNuribotCardLogInsert(NuriBotLog nuriBotLog);
}
