package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;

import javax.annotation.Nullable;

public enum DeliveryPriceCode {

    DIRECT_DELIVERY("직접배달") {
        @Override
        public String getDeliveryPriceValue(String str) {
            return "무료배송";
        }
    },
    DIRECT_CARRY("직접전달") {
        @Override
        public String getDeliveryPriceValue(String str) {
            if (str.contains(KEYWORD_FREE)) {
                return "무료배송";
            }
            return "무료";
        }
    },
    PRE_CHARGED("선결제") {
        @Override
        public String getDeliveryPriceValue(String str) {
            if (str.contains(KEYWORD_FREE)) {
                return "유무료";
            }
            return "착불";
        }
    };

    private static final String KEYWORD_FREE = "무료";
    private static final ImmutableMap<String, DeliveryPriceCode> CODE_MAP;

    static {
        CODE_MAP = ImmutableMap.<String, DeliveryPriceCode>builder()
                .put(DIRECT_DELIVERY.condition, DIRECT_DELIVERY)
                .put(DIRECT_CARRY.condition, DIRECT_CARRY)
                .put(PRE_CHARGED.condition, PRE_CHARGED)
                .build();
    }

    public abstract String getDeliveryPriceValue(String str);

    private final String condition;

    DeliveryPriceCode(String condition) {
        this.condition = condition;
    }

    @Nullable
    public static DeliveryPriceCode getDeliveryPriceCode(String str) {
        return CODE_MAP.get(str);
    }
}
