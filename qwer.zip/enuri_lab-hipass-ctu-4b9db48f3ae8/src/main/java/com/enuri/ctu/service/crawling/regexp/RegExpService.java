package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.RegExpObj;

public interface RegExpService {

    RegExpObj getCtuRegExpList(CrawlingParameter crawlingParam, GatheringInfo gatheringInfo);
}
