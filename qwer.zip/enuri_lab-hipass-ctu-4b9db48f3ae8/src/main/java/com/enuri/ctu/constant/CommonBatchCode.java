package com.enuri.ctu.constant;

public enum CommonBatchCode {
    ALL_MODEL_NO
}
