package com.enuri.ctu.dao.redis;

import com.enuri.ctu.entity.CtuParamEntity;
import org.springframework.data.repository.CrudRepository;

public interface CtuParamRedisRepository extends CrudRepository<CtuParamEntity, String> {
}
