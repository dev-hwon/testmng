package com.enuri.ctu.vo.search;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ModelSearchResultVO {
    private List<String> categories;
    private long total;

    private List<ItemVO> items;
}
