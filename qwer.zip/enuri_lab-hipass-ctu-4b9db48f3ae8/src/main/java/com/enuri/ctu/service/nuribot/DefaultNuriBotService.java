package com.enuri.ctu.service.nuribot;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.dao.eloc.MsElocNuribotLogDao;
import com.enuri.ctu.dao.oracle.OracleNuriBotLogDao;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DefaultNuriBotService implements NuriBotService {

    private final OracleNuriBotLogDao oracleNuribotLogDao;
    private final MsElocNuribotLogDao msSqlNuribotLogDao;

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 728 ~ 739
     * </pre>
     */
    @Override
    @LoggingProcessTime
    public void setSoldOutLog(NuriBotLog nuriBotLog, boolean isEqualPrice) {
        //원래 상태가 품절이 아니었던 상품만 실제 품절로그를 남긴다
        this.oracleNuribotLogDao.setDbNuribotSoldOutLogInsert(nuriBotLog);
        if (isEqualPrice) {
            //최저가 품절상품일 경우 ELOC에 로그데이터를 넣어준다 SR#23759
            this.msSqlNuribotLogDao.setDbNuribotSoldOutLogInsert(nuriBotLog);
        }
    }

    @Override
    @LoggingProcessTime
    public void setPriceLog(NuriBotLog nuriBotLog, MsSqlPriceList priceListLog, TblPriceListDataVO originalPriceList,
                            Long cardPrice) {
        if (priceListLog.validNotExceptionPlNo()) {
            priceListLog.getNotExceptionPlNo().forEach(ePlNo -> {
                nuriBotLog.setPlNo(Long.parseLong(ePlNo));
                this.oracleNuribotLogDao.setDbNuribotLogInsert(nuriBotLog);
            });
        } else {
            this.oracleNuribotLogDao.setDbNuribotLogInsert(nuriBotLog);
        }

        if (cardPrice > 0 && !cardPrice.equals(originalPriceList.getPriceCard())) {
            this.oracleNuribotLogDao.setDbNuribotCardLogInsert(nuriBotLog);
        }
    }
}
