package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.vo.CtuHeaderVO;
import com.enuri.ctu.vo.CtuRegExpVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class CrawlingUnit {
    private GatheringInfo gatheringInfo;
    private List<CtuHeaderVO> headerList;
    private List<CtuRegExpVO> regExpList;
    private ReplacedUrlLink replacedUrlLink;
    private ShopJob shopJobData;

    // header setting 시 필요
    // CtuHeaderService::getReplacedHttpHeaders
    private String paramGoodsCode;
    private CtuTest paramCtuTest;
    private String paramUrl;
    private DeviceType paramDevice;
    private String paramGoodsName;
    private IpType paramIpType;
    private TblPriceListDataVO tblPriceListData;
}
