package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MiniBotRegVO implements Serializable {

    private long shopCode;              // SPM_CD 쇼핑몰코드
    private long rankMaxSize;           // MODEL_PP_RNK_CND 모델인기순위조건
    private String serviceType;         // SRV_TP_CD 서비스 유형 코드(일반:G, 스피드:S)
}
