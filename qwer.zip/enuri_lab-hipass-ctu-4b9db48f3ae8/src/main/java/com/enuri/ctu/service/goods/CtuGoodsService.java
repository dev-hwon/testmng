package com.enuri.ctu.service.goods;

import com.enuri.ctu.dao.oracle.OracleGoodsDao;
import com.enuri.ctu.dao.oracle.OraclePriceListDao;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.vo.GoodsInfoVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CtuGoodsService implements GoodsService {

    private final OracleGoodsDao oracleGoodsDao;
    private final OraclePriceListDao oraclePriceListDao;

    @Override
    public GoodsInfoVO getMinPriceGoodsInfo(Long modelNo) {
        if (modelNo > 0) {
            return this.oracleGoodsDao.fetchMinPriceGoodsInfo(modelNo);
        }

        return null;
    }

    @Override
    public Long getModelPopularRank(TblPriceListDataVO original) {
        return this.oracleGoodsDao.fetchModelRank(original.getCaCode(), original.getModelNo());
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDivideGoodsExceptionService::srvGetexceptionPlDate
     * line: 103 ~ 116
     * </pre>
     */
    @Override
    public List<String> getExceptionPlDate(TblPriceList priceList) {
        return this.oraclePriceListDao
                .fetchTblPriceDivideGoods(priceList.getShopCode(), priceList.getGoodscode(), priceList.getPlNo())
                .stream()
                .filter(priceListDataVO -> divideGoodsPredicate().test(priceListDataVO))
                .map(priceListDataVO -> priceListDataVO.getPlNo().toString())
                .collect(Collectors.toList());
    }

    private Predicate<TblPriceListDataVO> divideGoodsPredicate() {
        return x -> x.getGoodsCode() == null && x.getNote() != null && x.getNote().contains("종료일");
    }
}
