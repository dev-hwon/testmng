package com.enuri.ctu.service.cache;

import com.enuri.ctu.vo.CtuParamVOWrapper;

public interface CacheService {

    boolean isDuplicated(CtuParamVOWrapper paramVO);

    void caching(CtuParamVOWrapper paramVO);
}
