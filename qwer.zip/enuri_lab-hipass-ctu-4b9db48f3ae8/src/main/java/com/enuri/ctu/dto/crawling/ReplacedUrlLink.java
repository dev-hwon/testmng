package com.enuri.ctu.dto.crawling;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReplacedUrlLink {
    private int wmpType;
    private int tmonType;
    private int interParkType;
    private String tmonCardYn;

    private String gtrGoodsCode;
    private String urlLink;
}
