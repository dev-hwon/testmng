package com.enuri.ctu.service.pricelist.pricelimit;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dao.eloc.MsSqlElocPriceListDao;
import com.enuri.ctu.dao.oracle.OraclePriceListDao;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.service.autotest.AutoTestService;
import com.enuri.ctu.service.nuribot.NuriBotService;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@RequiredArgsConstructor
public class CtuPriceLimitService implements PriceLimitProcessService {

    private final MsSqlElocPriceListDao sqlPriceListDao;
    private final OraclePriceListDao oraclePriceListDao;
    private final NuriBotService nuriBotService;
    private final AutoTestService autoTestService;

    @Override
    @LoggingProcessTime
    public void process(CrawlingParameter param, PriceListCollection priceListCollection, ResultDataSub resultDataSub,
                        NuriBotLog nuriBotLog, Long modelMinPrice) {
        TblPriceListDataVO originalPriceList = param.getTblPriceListData();
        TblPriceList priceList = priceListCollection.getPriceList();

        priceList.setCaCode(originalPriceList.getCaCode());
        priceList.setModelno(originalPriceList.getModelNo());

        DeviceType device = param.getDevice();
        if (DeviceType.PC == device) {
            this.pcProcess(priceListCollection, param, resultDataSub, nuriBotLog, modelMinPrice);
        } else {
            this.mobileProcess(priceListCollection, param, resultDataSub, nuriBotLog, modelMinPrice);
        }
        // autotest
        this.autoTestService.updatePrice(param, priceListCollection.getPriceList(), resultDataSub);

        priceList.setCaCode(originalPriceList.getCaCode());
        priceList.setAirconfeetype(originalPriceList.getAirconFeeType());
    }

    public void pcProcess(PriceListCollection priceListCollection, CrawlingParameter parameter,
                          ResultDataSub resultDataSub, NuriBotLog nuriBotLog, Long modelMinPrice) {

        TblPriceListDataVO originalPriceList = parameter.getTblPriceListData();
        TblPriceList priceList = priceListCollection.getPriceList();

        boolean validPrice = priceList.getPrice() != null &&
                !Objects.equals(priceList.getPrice(), originalPriceList.getPrice());
        boolean validCardPrice = originalPriceList.getPriceCard() != null &&
                resultDataSub.getCardPrice() != null &&
                !Objects.equals(Long.parseLong(resultDataSub.getCardPrice().toString()), originalPriceList.getPriceCard());

        if (priceList.getPriceCard() == null || priceList.getPriceCard() <= 0 || !(validPrice || validCardPrice)) {
            return;
        }

        Long cardPrice= resultDataSub.getCardPrice() == null? 0L : Long.parseLong(resultDataSub.getCardPrice().toString());
        TblPriceList oraclePriceList = priceListCollection.getOraclePriceList();
        MsSqlPriceList sqlPriceList = priceListCollection.getSqlPriceList();

        oraclePriceList.setPrice(priceList.getPrice());
        oraclePriceList.setPriceCard(cardPrice);
        oraclePriceList.setPlNo(originalPriceList.getPlNo());

        sqlPriceList.setPlPrice(priceList.getPrice());
        sqlPriceList.setPlPriceCard(cardPrice);
        sqlPriceList.setPlNo(originalPriceList.getPlNo());

        this.sqlPriceListDao.setDbPriceListUpdate(sqlPriceList);
        this.sqlPriceListDao.setDbPlDateUpdate(sqlPriceList);
        this.oraclePriceListDao.setDbTblPriceListUpdate(oraclePriceList);

        MsSqlPriceList priceListLog = priceListCollection.getPriceListLog();
        if (priceListLog.validNotExceptionPlNo()) {
            this.sqlPriceListDao.setDbLogListProc(priceListLog);
        } else {
            Long logPlNo = priceListLog.getPlNo();
            Integer modelNoKey = this.sqlPriceListDao.fetchModelNoKey(logPlNo);
            if (modelNoKey != null && modelNoKey != 0) {
                this.sqlPriceListDao.setDbLogProc(logPlNo, modelNoKey);
            }
        }

        setNuribotLog(parameter, nuriBotLog, modelMinPrice, priceList, originalPriceList, cardPrice);
        nuriBotLog.setServiceType("1");

        this.nuriBotService.setPriceLog(nuriBotLog, priceListLog, originalPriceList, cardPrice);
    }

    public void mobileProcess(PriceListCollection priceListCollection, CrawlingParameter parameter,
                              ResultDataSub resultDataSub, NuriBotLog nuriBotLog, Long modelMinPrice) {
        TblPriceList priceList = priceListCollection.getPriceList();
        TblPriceListDataVO originalPriceList = parameter.getTblPriceListData();

        boolean isExistPrice = priceList.getPrice() != null && priceList.getPrice() > 0;
        boolean isInstancePriceEquals = Objects.equals(priceList.getPrice(), originalPriceList.getInstancePrice());
        boolean validCondition = isExistPrice && (originalPriceList.getInstancePrice() == null || !isInstancePriceEquals);

        if (!validCondition) {
            return;
        }

        TblPriceList oraclePriceList = priceListCollection.getOraclePriceList();
        MsSqlPriceList sqlPriceList = priceListCollection.getSqlPriceList();
        oraclePriceList.setInstancePrice(priceList.getPrice());
        sqlPriceList.setPlInstancePrice(priceList.getPrice());

        MsSqlPriceList priceListLog = priceListCollection.getPriceListLog();
        if (priceListLog.validNotExceptionPlNo()) {
            this.sqlPriceListDao.setDbLogListProc(priceListLog);
        } else {
            Long logPlNo = priceListLog.getPlNo();
            Integer modelNoKey = this.sqlPriceListDao.fetchModelNoKey(logPlNo);
            if (modelNoKey != null && modelNoKey != 0) {
                this.sqlPriceListDao.setDbLogProc(logPlNo, modelNoKey);
            }
        }

        Long cardPrice= resultDataSub.getCardPrice() == null? 0L : Long.parseLong(resultDataSub.getCardPrice().toString());

        setNuribotLog(parameter, nuriBotLog, modelMinPrice, priceList, originalPriceList, cardPrice);
        nuriBotLog.setGoodscode(originalPriceList.getGoodsCode());
        nuriBotLog.setServiceType("2");

        this.nuriBotService.setPriceLog(nuriBotLog, priceListLog, originalPriceList, cardPrice);

    }

    private void setNuribotLog(CrawlingParameter parameter, NuriBotLog nuriBotLog, Long modelMinPrice,
                               TblPriceList priceList, TblPriceListDataVO originalPriceList, Long cardPrice) {
        nuriBotLog.setDelFlag("N");
        nuriBotLog.setErrorCode("0");
        nuriBotLog.setJobType("");
        nuriBotLog.setLogoType("1");

        String divis = SystemType.getServiceDivisBySystemType(parameter.getSystemType());
        nuriBotLog.setServiceDivis(divis);
        nuriBotLog.setMinPrice(modelMinPrice);
        nuriBotLog.setOrgCardPrice(originalPriceList.getPriceCard());
        nuriBotLog.setUpCardPrice(cardPrice);

        long orgPrice = originalPriceList.getPrice() == null? 0L : originalPriceList.getPrice();
        nuriBotLog.setOrgPrice(orgPrice);
        nuriBotLog.setUpPrice(priceList.getPrice());
        nuriBotLog.setPriceCheck("1");
    }


}
