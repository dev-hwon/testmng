package com.enuri.ctu.service.crawling.header;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.vo.CtuHeaderVO;
import org.springframework.http.HttpHeaders;

import java.util.List;

public interface HeaderService {

    List<CtuHeaderVO> getCrawlingHeaders(CrawlingParameter paramDto, GatheringInfo gatheringInfo);

    HttpHeaders getReplacedHttpHeaders(CrawlingUnit unit);
}
