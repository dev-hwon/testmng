package com.enuri.ctu.service.pricelist;

import com.enuri.ctu.dto.CrawlProcessResult;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.vo.TblPriceListDataVO;

public interface PriceListService {

    PriceListCollection setUpPriceLists(CrawlProcessResult crawlProcessResult, TblPriceListDataVO originalPriceList);
}
