package com.enuri.ctu.exception;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.CommonResponse;
import lombok.Getter;

@Getter
public class CtuException extends RuntimeException {

    private final CommonResponse commonResponse;

    public CtuException(ResultMessageCode resultMessageCode, Object data) {
        super(resultMessageCode.getMessage());
        this.commonResponse = CommonResponse.builder()
                .resultMsg(resultMessageCode)
                .resultData(data)
                .build();
    }

    public CtuException(ResultMessageCode resultMessageCode) {
        super(resultMessageCode.getMessage());
        this.commonResponse = CommonResponse.builder()
                .resultMsg(resultMessageCode)
                .resultData(resultMessageCode.getData())
                .build();
    }


}
