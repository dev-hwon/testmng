package com.enuri.ctu.dto.logging;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FailLog {
    private String device;
    private String service;
    private Long shopCode;
    private String goodsCode;
    private String plNo;
    private String url;
    private String crawlingUrl;
    private int gtrTimeOut;
    private int sendType;
    private int count;
    private int totalCount;
    private long logSeq;
    private String addDate;
    private String sendDate;
    private int failType;       // todo define fail type constant

    public static FailLog ofCrawlingPrepare(CrawlingParameter crawlingParameter) {
        return FailLog.builder()
                .device(crawlingParameter.getDevice().getCode())
                .goodsCode(crawlingParameter.getGoodsCode())
                .plNo(crawlingParameter.getPlNo())
                .service(crawlingParameter.getService().getCode())
                .shopCode(crawlingParameter.getShopCode())
                .url(crawlingParameter.getUrl())
                .build();
    }
}
