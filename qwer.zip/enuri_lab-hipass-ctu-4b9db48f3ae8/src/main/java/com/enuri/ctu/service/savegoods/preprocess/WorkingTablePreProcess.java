package com.enuri.ctu.service.savegoods.preprocess;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.dao.oracle.OracleMemberSaveGoodsDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
@RequiredArgsConstructor
public class WorkingTablePreProcess implements SaveGoodsPreProcess {
    private final OracleMemberSaveGoodsDao memberSaveGoodsDao;
    private final CtuLogDao ctuLogDao;

    @LoggingProcessTime
    @Transactional
    @Override
    public void initWorkingTable() {
        log.info("구독 CTU 작업 테이블 초기화 시작: TB_SBSCR_CTU_BTC");

        int truncateResult = this.memberSaveGoodsDao.truncateWorkingTable();
        log.info("Truncate TB_SBSCR_CTU_BTC : {}", truncateResult);

        int truncateCtuLogResult = this.ctuLogDao.truncateSaveGoodsModel();
        log.info("Truncate CTU_SAVE_GOODS_MODEL : {}", truncateCtuLogResult);

        int modelNoInsertResult = this.memberSaveGoodsDao.insertModelNoToWorkingTable();
        log.info("Insert ModelNo To TB_SBSCR_CTU_BTC : {}[{}]",
                this.resultMessage(modelNoInsertResult), modelNoInsertResult);

        log.info("구독 CTU 작업 테이블 초기화 완료");
    }

    private String resultMessage(int result) {
        return result > 0? "OK" : "ERROR";
    }
}
