package com.enuri.ctu.dao.eloc;

import com.enuri.ctu.dto.pricelist.MsSqlPriceList;
import com.enuri.ctu.vo.MsSqlPriceListVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MsSqlElocPriceListDao {

    // setDbPriceListSoldOut
    void updateStatus(MsSqlPriceList priceList);

    MsSqlPriceListVO fetchPriceListData(long plNo);

    void setDbLogListProc(MsSqlPriceList priceList);
    void setDbLogProc(long plNo, int modelNoKey);

    Integer fetchModelNoKey(long plNo);

    void setDbPriceListDelvUpdate(MsSqlPriceList priceList);

    void setDbPlDateUpdate(MsSqlPriceList priceList);

    void setDbCouponProc(MsSqlPriceList priceList);

    void setDbPriceListUpdate(MsSqlPriceList priceList);
}
