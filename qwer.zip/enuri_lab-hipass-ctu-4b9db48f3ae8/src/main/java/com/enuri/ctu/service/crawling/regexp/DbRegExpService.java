package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.dto.crawling.RegExpObj;
import com.enuri.ctu.dto.crawling.RegExpParameter;

public interface DbRegExpService {

    RegExpObj fetchRegExpList(RegExpParameter param);
}
