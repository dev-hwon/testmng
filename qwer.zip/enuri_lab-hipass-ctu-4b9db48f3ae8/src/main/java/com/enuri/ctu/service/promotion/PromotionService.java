package com.enuri.ctu.service.promotion;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.dto.promotion.PromotionResult;
import com.enuri.ctu.vo.TblPriceListDataVO;

public interface PromotionService {

    PromotionResult getCtuPromotion(TblPriceList priceList, TblPriceListDataVO originalPriceList, CrawlingParameter param);
}
