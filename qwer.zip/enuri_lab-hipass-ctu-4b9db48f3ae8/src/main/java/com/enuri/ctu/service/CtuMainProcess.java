package com.enuri.ctu.service;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.DivideCode;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.dto.CrawlProcessResult;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.ems.EmsCall;
import com.enuri.ctu.dto.nuribot.NuriBotLog;
import com.enuri.ctu.dto.pricelist.PriceListCollection;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.autotest.AutoTestService;
import com.enuri.ctu.service.ems.EmsService;
import com.enuri.ctu.service.goods.GoodsService;
import com.enuri.ctu.service.pricelist.PriceListService;
import com.enuri.ctu.service.pricelist.PriceListUpdateService;
import com.enuri.ctu.service.pricelist.pricelimit.PriceLimitProcessService;
import com.enuri.ctu.service.soldout.SoldOutService;
import com.enuri.ctu.vo.AutoTestLogVO;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import com.enuri.ctu.vo.GoodsInfoVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Future;


@Slf4j
@Service
@RequiredArgsConstructor
public class CtuMainProcess implements CtuProcess {

    private final ClickToUpdateService ctuService;
    private final AutoTestService autoTestService;
    private final EmsService emsService;
    private final PriceListService priceListService;
    private final GoodsService goodsService;
    private final SoldOutService soldOutService;
    private final PriceListUpdateService priceListUpdateService;
    private final PriceLimitProcessService priceLimitProcessService;

    @Override
    @Async
    @LoggingProcessTime
    public Future<CommonResponse> processMain(CtuParamVOWrapper paramVO) {
        CrawlProcessResult crawlProcessResult = this.ctuService.crawling(paramVO);
        CrawlingParameter crawlingParameter = crawlProcessResult.getCrawlingParameter();
        CommonResponse commonResponse = crawlProcessResult.getCommonResponse();
        TblPriceListDataVO originalPriceList = crawlingParameter.getTblPriceListData();

        /*
        * source: com.enuri.service.CtuService::svrMainCtuProcReal
        * line: 1055 ~ 1067
        * 실패인경우를 먼저 처리 -> 리턴
        * */
        if (!ResultMessageCode.isSuccess(commonResponse.getResultMsg()) ||
                !ResultDataSub.class.isAssignableFrom(commonResponse.getResultData().getClass())) {

            log.error("Crawling Failed : {}", commonResponse.getResultMsg());

            if (CtuTest.REAL_TEST == paramVO.getCtuTest() && crawlingParameter.getAutoTestLog().getTestCode() != 0L) {
                // autoTest logging
                this.autoTestService.updateAutoTestCrawlingFail(crawlingParameter, commonResponse.getResultMsg());
            }

            return new AsyncResult<>(commonResponse);
        }

        /*
        * 가격이 10억(1_000_000_000)이 넘으면 EMS SEND
        * */
        ResultDataSub resultDataSub = (ResultDataSub) commonResponse.getResultData();
        if (resultDataSub.needToCheckPrice()) {
            EmsCall emsCall = this.emsService.checkPrice(resultDataSub);
            if (emsCall.isNeedToCall()) {
                this.emsService.emsCall(crawlingParameter.getModelNo(), originalPriceList.getPlNo(),
                        emsCall.getEmsCallPrice());
            }
        }
        commonResponse.setResultData(resultDataSub);

        // priceList set + promotion 적용
        PriceListCollection priceListCollection = this.priceListService
                .setUpPriceLists(crawlProcessResult, originalPriceList);

        ShopCode shopCode = ShopCode.getShopCode(crawlingParameter.getShopCode());
        if (ShopCode.SSG_DEPT == shopCode) {
            crawlingParameter.setShopCode(ShopCode.SSG_MALL.getCode());
            priceListCollection.getPriceList().setShopCode(ShopCode.SSG_MALL.getCode());
        }

        //##13-13. 특정 몰에 대한 특정 카테고리 CTU 처리 불가 => SR45028 해당 로직 삭제 => 원복 =>  SR45078 할부원금이슈로 인터파크 모바일만 해당 로직 유지
        this.realTestProcess(shopCode, crawlingParameter);

        NuriBotLog nuriBotLog = NuriBotLog.ofOriginalPriceList(originalPriceList);
        GoodsInfoVO minPriceGoodsInfo = this.goodsService.getMinPriceGoodsInfo(originalPriceList.getModelNo());
        long modelMinPrice = minPriceGoodsInfo == null? 0L : minPriceGoodsInfo.getMinPrice();

        if (minPriceGoodsInfo != null) {
            Long rank = this.goodsService.getModelPopularRank(originalPriceList);
            nuriBotLog.setPopular(rank);
        }

        List<String> exceptionPlDate = this.goodsService.getExceptionPlDate(priceListCollection.getPriceList());
        if (!exceptionPlDate.isEmpty()) {
            priceListCollection.getSqlPriceList().setExceptionPlDate(exceptionPlDate);
        }

        //##13-16-3. 품절 처리
        if (resultDataSub.isSoldOut() &&
                crawlingParameter.isRealTest() &&
                crawlingParameter.getAutoTestLog().getTestCode() != 0 &&
                DivideCode.SOLD_OUT != DivideCode.getDivideCode(crawlingParameter.getDivis())) {
            resultDataSub.setSoldOut(null);
        }

        if (resultDataSub.isSoldOut() &&
                (originalPriceList.getGoodsCode() != null || originalPriceList.getPlNo() != null)) {
            // 품절처리
            this.soldOutService.soldOutProcess(nuriBotLog, crawlingParameter, modelMinPrice);
        } else {
            // Oracle - MsSql 싱크
            this.priceListUpdateService.sync(originalPriceList, priceListCollection.getSqlPriceList(), nuriBotLog);

            // 배송비 로직
            this.priceListUpdateService.deliveryInfoUpdate(priceListCollection, crawlingParameter, nuriBotLog, resultDataSub);

            // autotest-delivery info
            this.autoTestDeliveryInfo(crawlingParameter, priceListCollection.getOraclePriceList());

            // coupon
            this.priceListUpdateService.couponUpdate(priceListCollection, crawlingParameter, nuriBotLog, resultDataSub);

            // 가격 제한가 처리
            this.priceLimitProcessService.process(crawlingParameter, priceListCollection, resultDataSub, nuriBotLog, modelMinPrice);
        }

        if (crawlingParameter.isRealTest() && crawlingParameter.getAutoTestLog().getTestCode() != 0) {
            this.autoTestService.updateNotApplicable(crawlingParameter);
            throw new CtuException(ResultMessageCode.NOT_APPLICABLE);
        }

        return new AsyncResult<>(commonResponse);
    }

    private void realTestProcess(ShopCode shopCode, CrawlingParameter crawlingParameter) {
        if (isProcessDeny(shopCode, crawlingParameter.getDevice(), crawlingParameter.getTblPriceListData())) {
            ResultMessageCode resultMessageCode = ResultMessageCode.FAIL_CATEGORY_DENY;
            if (crawlingParameter.isRealTest() && crawlingParameter.getAutoTestLog().getTestCode() != 0L) {
                resultMessageCode = ResultMessageCode.CATEGORY_DENY;
                this.autoTestService.updateCategoryDeny(crawlingParameter.getAutoTestLog(), crawlingParameter.getAutoTestTbl());
            }

            throw new CtuException(resultMessageCode,
                    "Category Deny => " + crawlingParameter.getTblPriceListData().getCaCode());
        }
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 621 ~ 625
     *
     * ##13-13. 특정 몰에 대한 특정 카테고리 CTU 처리 불가 => SR45028 해당 로직 삭제 => 원복 =>  SR45078 할부원금이슈로 인터파크 모바일만 해당 로직 유지 =>230117 로직삭제요청=>바로다시원복요청(PC가 모바일가 다름)
     * #8741 인터파크 모바일일경우 030401, 030403, 030405 카테고리만 CTU 미처리
     * </pre>
     */
    private boolean isProcessDeny(ShopCode shopCode, DeviceType deviceType, TblPriceListDataVO originalPriceList) {
        if (originalPriceList == null) {
            return true;    // category deny
        }

        List<String> denyStartWith = Arrays.asList("030401", "030403", "030405");
        String cateCode = originalPriceList.getCaCode();

        return ShopCode.INTERPARK == shopCode &&
                DeviceType.MOBILE == deviceType &&
                StringUtils.hasText(cateCode) &&
                cateCode.length() > 3 &&
                denyStartWith.stream().anyMatch(cateCode::startsWith);
    }

    private void autoTestDeliveryInfo(CrawlingParameter param, TblPriceList oraclePriceList) {

        TblPriceListDataVO originalPriceList = param.getTblPriceListData();
        AutoTestLogDto autoTestLog = param.getAutoTestLog();
        AutoTestLogVO autoTestTbl = param.getAutoTestTbl();

        if (param.isRealTest() && "5".equals(param.getDivideName()) && autoTestLog.getTestCode() != 0) {
            this.autoTestService.updateDeliveryInfo(autoTestLog, autoTestTbl, oraclePriceList, originalPriceList);
            throw new CtuException(ResultMessageCode.REAL_TEST_DELIVERY_PRICE, oraclePriceList.getDeliveryinfo());
        }
    }


}
