package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.AkMallRule;
import com.enuri.ctu.service.rules.shop.AuctionRule;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.GsShopRule;
import com.enuri.ctu.service.rules.shop.HomePlusRule;
import com.enuri.ctu.service.rules.shop.InterParkRule;
import com.enuri.ctu.service.rules.shop.shockingdeal.ShockingDealRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import com.enuri.ctu.service.rules.shop.cjmall.CjMallRule;
import com.enuri.ctu.service.rules.shop.coupang.CoupangRule;
import com.enuri.ctu.service.rules.shop.timon.TimonRule;
import com.enuri.ctu.service.rules.shop.wemap.WeMapRule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class DeliveryInfoRuleFactory {
    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;
    private final ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        CjMallRule cjMallRule = this.applicationContext.getBean(CjMallRule.class);
        AuctionRule auctionRule = this.applicationContext.getBean(AuctionRule.class);
        HomePlusRule homePlusRule = this.applicationContext.getBean(HomePlusRule.class);
        TimonRule tmonRule = this.applicationContext.getBean(TimonRule.class);
        GsShopRule gsShopRule = this.applicationContext.getBean(GsShopRule.class);
        ShockingDealRule shockingDealRule = this.applicationContext.getBean(ShockingDealRule.class);
        WeMapRule weMapRule = this.applicationContext.getBean(WeMapRule.class);
        CoupangRule coupangRule = this.applicationContext.getBean(CoupangRule.class);
        InterParkRule interParkRule = this.applicationContext.getBean(InterParkRule.class);
        SsgRule ssgRule = this.applicationContext.getBean(SsgRule.class);
        AkMallRule akMallRule = this.applicationContext.getBean(AkMallRule.class);

        // CJ_MALL
        RULE_MAP.put(ShopCode.CJ_MALL, cjMallRule);

        // AUCTION
        RULE_MAP.put(ShopCode.AUCTION, auctionRule);

        // HOMEPLUS DELIVERY MALL
        RULE_MAP.put(ShopCode.HOMEPLUS_DELIVERY_MALL, homePlusRule);

        // TMON
        RULE_MAP.put(ShopCode.TIMON, tmonRule);

        // GS_SHOP
        RULE_MAP.put(ShopCode.GS_SHOP, gsShopRule);

        // SHOCKING_DEAL
        RULE_MAP.put(ShopCode.SHOCKING_DEAL, shockingDealRule);

        // WEMAP
        RULE_MAP.put(ShopCode.WEMAP, weMapRule);

        // COUPANG
        RULE_MAP.put(ShopCode.COUPANG, coupangRule);

        // INTERPARK
        RULE_MAP.put(ShopCode.INTERPARK, interParkRule);

        // SSG
        RULE_MAP.put(ShopCode.SSG_MALL, ssgRule);
        RULE_MAP.put(ShopCode.SSG_DEPT, ssgRule);

        // AK MALL
        RULE_MAP.put(ShopCode.AK_MALL, akMallRule);

    }

    public ShopRule getDeliveryInfoRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            return this.defaultShopRule;
        }

        return shopRule;
    }
}
