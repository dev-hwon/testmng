package com.enuri.ctu.util;

import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpUtils {

    private static final String EMPTY_STRING = "";
    private static final String PATTERN_NOT_NUMBER = "\\D";     // not digit, equals [^0-9]

    private RegExpUtils() {
        throw new IllegalStateException("Util Class");
    }

    public static String getRegExpData(String source, String pattern) {
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(source);
        while (matcher.find()) {
            String s = matcher.group(1);
            if (StringUtils.hasText(s)) {
                return s;
            }
        }

        return EMPTY_STRING;
    }

    public static Object numberOnly(Object value) {
        if (String.class.isAssignableFrom(value.getClass())) {
            String strValue = String.valueOf(value);
            return strValue.replace(PATTERN_NOT_NUMBER, "");
        }

        return value;
    }

    public static double getBelowDecimalPlace(String str) {
        String patter = "\\.(\\d+)";
        Pattern compiledPattern = Pattern.compile(patter);
        Matcher matcher = compiledPattern.matcher(str);
        while (matcher.find()) {
            String s = matcher.group(1);
            if (StringUtils.hasText(s)) {
                return Double.parseDouble("0." + s);
            }
        }

        return 0;
    }
}
