package com.enuri.ctu.config.mybatis;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CtuBooleanTypeHandler extends BaseTypeHandler<Boolean> {
    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, Boolean parameter, JdbcType jdbcType) throws SQLException {
        ps.setString(i, this.booleanToVarchar(parameter));
    }

    @Override
    public Boolean getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return this.varcharToBoolean(rs.getString(columnName));
    }

    @Override
    public Boolean getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return this.varcharToBoolean(rs.getString(columnIndex));
    }

    @Override
    public Boolean getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return this.varcharToBoolean(cs.getString(columnIndex));
    }

    private String booleanToVarchar(Boolean b) {
        return Boolean.TRUE.equals(b) ? "Y" : "N";
    }

    @SuppressWarnings("java:S2447")
    private Boolean varcharToBoolean(String s) {
        if (s == null) {
            return null;
        }
        return s.equalsIgnoreCase("Y");
    }
}
