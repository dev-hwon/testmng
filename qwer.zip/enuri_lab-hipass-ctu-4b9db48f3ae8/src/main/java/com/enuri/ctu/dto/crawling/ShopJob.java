package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.vo.CtuShopJobVO;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class ShopJob implements Serializable {
    private Long shopCode;
    private String shopName;
    private Boolean priceYn;
    private Boolean cardPriceYn;
    private Boolean deliveryYn;
    private Boolean couponYn;
    private Boolean mobileYn;
    private Boolean soldYn;

    public static ShopJob of(CtuShopJobVO vo) {
        return ShopJob.builder()
                .shopCode(vo.getShopCode())
                .shopName(vo.getShopName())
                .priceYn(vo.getPriceYn())
                .cardPriceYn(vo.getCardPriceYn())
                .deliveryYn(vo.getDeliveryYn())
                .couponYn(vo.getCouponYn())
                .mobileYn(vo.getMobileYn())
                .soldYn(vo.getSoldYn())
                .build();
    }

    public void localTestSetting() {
        this.priceYn = true;
        this.cardPriceYn = true;
        this.mobileYn = true;
        this.deliveryYn = true;
        this.soldYn = true;
    }

    public boolean isAvailable() {
        return this.priceYn
                || this.cardPriceYn
                || this.deliveryYn
                || this.couponYn
                || this.mobileYn
                || this.soldYn;
    }
}
