package com.enuri.ctu.dto.ems;

import lombok.Getter;

@Getter
public class EmsCall {
    private final int emsCallType;
    private final long emsCallPrice;
    private final boolean needToCall;

    public EmsCall(int emsCallType, long emsCallPrice) {
        this.emsCallType = emsCallType;
        this.emsCallPrice = emsCallPrice;
        this.needToCall = emsCallType > 0;
    }
}
