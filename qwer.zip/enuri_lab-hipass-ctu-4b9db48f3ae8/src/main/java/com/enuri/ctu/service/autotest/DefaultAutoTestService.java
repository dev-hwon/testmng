package com.enuri.ctu.service.autotest;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dao.oracle.OracleAutoTestDao;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.autotest.AutoTestLogDto;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.vo.AutoTestLogVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DefaultAutoTestService implements AutoTestService {

    private final OracleAutoTestDao oracleAutoTestDao;

    @Override
    public AutoTestLogVO fetchAutoTestTbl(Long testCode) {
        return this.oracleAutoTestDao.fetchAutoTestList(testCode);
    }

    public void updateAutoTestNoProduct(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl, DeviceType deviceType) {

        final Long testCode = autoTestLog.getTestCode();
        final String defaultResultUp = "No product information";

        if (DeviceType.PC == deviceType) {
            String resultPcUp = autoTestTbl.getResultPcUp();
            autoTestLog.setResultPcOrg(resultPcUp);
            autoTestLog.setResultPcUp(defaultResultUp);
            this.oracleAutoTestDao.updateAutoTestResult(resultPcUp, defaultResultUp, testCode);
        } else {
            String resultMobileUp = autoTestTbl.getResultMobileUp();
            autoTestLog.setResultMobileOrg(resultMobileUp);
            autoTestLog.setResultMobileUp(defaultResultUp);
            this.oracleAutoTestDao.updateAutoTestMobileResult(resultMobileUp, defaultResultUp, testCode);
        }

        this.oracleAutoTestDao.updateAutoTestProcTime(testCode);
    }

    @Override
    public void updateAutoTestCrawlingFail(CrawlingParameter parameter, ResultMessageCode resultMessageCode) {
        final long testCode = parameter.getAutoTestLog().getTestCode();
        if (DeviceType.PC == parameter.getDevice()) {
            String resultPcUp = parameter.getAutoTestTbl().getResultPcUp();
            this.oracleAutoTestDao.updateAutoTestResult(resultPcUp, resultMessageCode.getMessage(), testCode);
        } else {
            String resultMobileUp = parameter.getAutoTestTbl().getResultMobileUp();
            this.oracleAutoTestDao.updateAutoTestMobileResult(resultMobileUp, resultMessageCode.getMessage(), testCode);
        }

        this.oracleAutoTestDao.updateAutoTestProcTime(testCode);
    }

    @Override
    public void updateCategoryDeny(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl) {
        String resultMobileOrg = autoTestTbl.getResultMobileUp();
        String resultMobileUp = "Category Deny";
        this.oracleAutoTestDao.updateAutoTestMobileResult(resultMobileOrg, resultMobileUp, autoTestLog.getTestCode());
        this.oracleAutoTestDao.updateAutoTestProcTime(autoTestLog.getTestCode());
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 713 ~ 724
     * </pre>
     */
    @Override
    public void updateSoldOut(AutoTestLogDto autoTestLog, String status) {
        String resultOrg = "5".equals(status)? "Sold out" : status;
        String resultUp = "Sold out";

        this.oracleAutoTestDao.updateAutoTestResult(resultOrg, resultUp, autoTestLog.getTestCode());
        this.oracleAutoTestDao.updateAutoTestProcTime(autoTestLog.getTestCode());
    }

    @Override
    public void updateDeliveryInfo(AutoTestLogDto autoTestLog, AutoTestLogVO autoTestTbl, TblPriceList oraclePriceList,
                                   TblPriceListDataVO originalPriceList) {
        String org = autoTestTbl.getResultPcUp();
        String up = oraclePriceList.getDeliveryinfo() == null?
                originalPriceList.getDeliveryInfo() : oraclePriceList.getDeliveryinfo();

        this.oracleAutoTestDao.updateAutoTestResult(org, up, autoTestLog.getTestCode());
        this.oracleAutoTestDao.updateAutoTestProcTime(autoTestLog.getTestCode());
    }

    @Override
    public void updateCoupon(AutoTestLogDto autoTestLogDto, AutoTestLogVO autoTestTbl, TblPriceList priceList) {
        String org = autoTestTbl.getResultPcUp();
        String up = priceList.getCaCode();

        this.oracleAutoTestDao.updateAutoTestResult(org, up, autoTestLogDto.getTestCode());
        this.oracleAutoTestDao.updateAutoTestProcTime(autoTestLogDto.getTestCode());
    }

    @Override
    public void updatePrice(CrawlingParameter param, TblPriceList priceList, ResultDataSub resultDataSub) {
        AutoTestLogDto autoTestLog = param.getAutoTestLog();

        if (!param.isRealTest() || autoTestLog.getTestCode() == 0) {
            return;
        }

        AutoTestLogVO autoTestTbl = param.getAutoTestTbl();
        String org = autoTestTbl.getResultPcUp();
        String up = "";

        ResultMessageCode resultMessageCode = ResultMessageCode.FAIL;
        if ("4".equals(param.getDivis()) && priceList.getPriceCard() != null) {
            up = priceList.getPriceCard().toString();
            resultMessageCode = ResultMessageCode.REAL_TEST_CARD_PRICE;
        } else if ("1".equals(param.getDivis())) {
            up = resultDataSub.getNormalPrice().toString();
            resultMessageCode = ResultMessageCode.REAL_TEST_NORMAL_PRICE;
        } else if ("2".equals(param.getDivis())) {
            up = resultDataSub.getSalePrice().toString();
            resultMessageCode = ResultMessageCode.REAL_TEST_SALE_PRICE;
        }

        if (DeviceType.PC == param.getDevice()) {
            this.oracleAutoTestDao.updateAutoTestResult(org, up, autoTestLog.getTestCode());
            this.oracleAutoTestDao.updateAutoTestProcTime(autoTestLog.getTestCode());
        } else {
            this.oracleAutoTestDao.updateAutoTestMobileResult(org, up, autoTestLog.getTestCode());
        }

        throw new CtuException(resultMessageCode, up);
    }

    @Override
    public void updateNotApplicable(CrawlingParameter param) {
        Long testCode = param.getAutoTestLog().getTestCode();
        String org = param.getAutoTestTbl().getResultPcUp();
        String up = "Not Applicable";

        this.oracleAutoTestDao.updateAutoTestResult(org, up, testCode);

        List<String> divisList = Arrays.asList("1", "2", "3", "4");
        if (divisList.contains(param.getDivis())) {
            org = param.getAutoTestTbl().getResultMobileUp();
            this.oracleAutoTestDao.updateAutoTestMobileResult(org, up, testCode);
        }

        this.oracleAutoTestDao.updateAutoTestProcTime(testCode);
    }
}
