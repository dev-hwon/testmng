package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.CtuShopJobVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleShopJobDao {

    CtuShopJobVO fetchShopJob(long shopCode);

    CtuShopJobVO fetchSmartStoreShopJob(long shopCode);
}
