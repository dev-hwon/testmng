package com.enuri.ctu.dao.oracle;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleTestDao {

    int connectTest();
}
