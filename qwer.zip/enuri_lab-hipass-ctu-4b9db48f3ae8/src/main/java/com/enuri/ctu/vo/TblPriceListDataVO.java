package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
public class TblPriceListDataVO {
    private final Long modelNo;
    private final Long plNo;
    private final Long shopCode;
    private final String goodsCode;
    private final String goodsNm;
    private final String note;
    private final String caCode;
    private final Long price;
    private final Long priceCard;
    private final Long instancePrice;
    private final String url;
    private final Long coupon;
    private final Long delPrice;
    private final String deliveryInfo;
    private final String deliveryInfo2;
    private final String deliveryType2;
    private final String optionFlag;
    private final String optionFlag2;
    private final String airconFeeType;
    private final String srvflag;
    private final String status;


/*    쿼리에서 사용하지 않는 필드들
    private final Long shopCodeSub; //SR48189
    private final String etc;
    private final String authFlag;
    private final String authDate;
    private final String soldFlag;
    private final String soldDate;
    private final String uDate;
    private final String rightNLeft;
    private final String multiFlag;
    private final String multiComment;
    private final String flag;
    private final String esStockFlag;
    private final String esOptFlag;
    private final String imgUrl;
    private final Long authVCode;
    private final String jobType;
    private final Long stockCount;
    private final Long regTerm;
    private final String origin;
    private final String delFeeType;
    private final String delFeeDesc;
    private final String delAreaDesc;
    private final Long basisTo;
    private final String deliveryFlag;
    private final Long basisFrom;
    private final String delAreaType;
    private final String airconDesc;
    private final String specFlag;
    private final String accountYn;
    private final String imgUrlFlag;
    private final String pJobCode;
    private final Long finalUsedFlag;
    private final String goodsFactory;
    private final String searchFlag;
    private final String subsideLevel;
    private final String nointMonth;
    private final String nointSdate;
    private final String nointEdate;
    private final Long cashback;
    private final Long subside;
    private final String freeInterest;
    private final Long agreeMonth;
    private final Long popular;
    private final String homeFlag;
    private final String openSeller;
    private final String catalogFlag;
    private final String powerFlag;
    private final String bidFlag;
    private final String enuriUserId;
    private final String priceFlag;
    private final String deliveryLev;
    private final String setYn;
    private final String storeFlag;
    private final String caCodeDept;
    private final String goodsBrand;
    private final String mobileFlag;
    private final String mobileBidFlag;
    private final String delvValue;
    private final List<String> exceptionPlNo;
    */
}
