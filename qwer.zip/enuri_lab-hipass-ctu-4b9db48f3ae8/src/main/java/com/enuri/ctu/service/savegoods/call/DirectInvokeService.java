package com.enuri.ctu.service.savegoods.call;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.service.CtuProcess;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import com.enuri.ctu.vo.GoodsCodeVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@Slf4j
@Service("DirectInvokeService")
@RequiredArgsConstructor
public class DirectInvokeService implements InnerCallService {

    private final CtuProcess ctuProcess;

    @Async
    @Override
    public CompletableFuture<String> call(GoodsCodeVO goodsCodeVO, CtuTest ctuTest, IpType ipType) {
        // goodsCodeVO -> CtuParamVOWrapper
        CtuParamVOWrapper pcParam = CtuParamVOWrapper.copyOfSaveGoods(goodsCodeVO, ctuTest, DeviceType.PC, ipType);
        CtuParamVOWrapper mobileParam = CtuParamVOWrapper.copyOfSaveGoods(goodsCodeVO, ctuTest, DeviceType.MOBILE, ipType);

        Future<CommonResponse> pcFuture = this.ctuProcess.processMain(pcParam);
        Future<CommonResponse> mobileFuture = this.ctuProcess.processMain(mobileParam);
        try {
            CommonResponse pcResponse = pcFuture.get();
            CommonResponse mobileResponse = mobileFuture.get();

            log.info("GOODS_CODE[{}] SHOP_CODE[{}] PC RESULT : {}",
                    goodsCodeVO.getGoodsCode(), goodsCodeVO.getShopCode(), pcResponse.getResultMsg());

            log.info("GOODS_CODE[{}] SHOP_CODE[{}] MOBILE RESULT : {}",
                    goodsCodeVO.getGoodsCode(), goodsCodeVO.getShopCode(), mobileResponse.getResultMsg());
        } catch (InterruptedException | ExecutionException e) {
            log.error("CTU Process Future stopped! : ", e);
            Thread.currentThread().interrupt();
        }

        return CompletableFuture.completedFuture("OK");
    }
}
