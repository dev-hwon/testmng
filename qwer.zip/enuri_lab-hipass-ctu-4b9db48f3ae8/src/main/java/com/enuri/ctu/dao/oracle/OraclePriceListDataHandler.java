package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.GoodsCodeVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.sql.SQLException;
import java.util.List;

@Component
@RequiredArgsConstructor
public class OraclePriceListDataHandler {

    private final OraclePriceListDao priceListDao;
    private final OracleMemberSaveGoodsDao memberSaveGoodsDao;

    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public TblPriceListDataVO getOriginalPriceList(@Nonnull Long shopCode, String goodsCode, String plNo) {
        return this.priceListDao.fetchTblPriceListData(shopCode, goodsCode, plNo);
    }

    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public List<GoodsCodeVO> getGoodsCodeByModelNo(long modelNo) {
        return this.memberSaveGoodsDao.fetchGoodsCodeByModelNo(modelNo);
    }

    @Retryable(
            value = {SQLException.class, DataAccessException.class},
            maxAttempts = 5,
            backoff = @Backoff(delay = 100)
    )
    public Long getSmartStoreShopCode(@Nonnull String goodsCode) {
        return this.priceListDao.fetchSmartStoreShopCodeByGoodsCode(goodsCode);
    }
}
