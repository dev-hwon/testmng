package com.enuri.ctu.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Slf4j
@EnableAsync(proxyTargetClass = true)
@Configuration
public class AsyncConfig implements AsyncConfigurer {

    @Override
    public Executor getAsyncExecutor() {
        int numOfCores = Runtime.getRuntime().availableProcessors();
        int maxPoolSize = (numOfCores * 2) + 1;
        log.info("Async Core Set - CorePoolSize[{}] - MaxPoolSize[{}]", numOfCores, maxPoolSize);

        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setQueueCapacity(numOfCores);     // queue limit. capacity size 가 넘어가면 새로운 쓰레드 +1
        executor.setMaxPoolSize(maxPoolSize);         // queue capacity 에 따라 + 될때 최대 늘어날 수 있는 사이즈
        executor.setCorePoolSize(numOfCores);        // 기본적으로 동시에 실행시킬 worker 쓰레드 개수
        executor.setThreadNamePrefix("ctu-async-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());    // 쓰레드 생성 실패시 메인 쓰레드에서 실행하는 정책
        executor.setTaskDecorator(new CustomTaskDecorator());   // MDC context 복사한 Decorator
        executor.initialize();
        return executor;
    }

    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return (ex, method, params) ->
                log.error("Method name : {}, param Count : {}\n\nException Cause -{}",
                        method.getName(), params.length, ex.getMessage());
    }
}
