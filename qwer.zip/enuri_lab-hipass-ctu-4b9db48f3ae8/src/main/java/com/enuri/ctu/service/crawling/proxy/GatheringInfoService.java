package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;

public interface GatheringInfoService {

    default GatheringInfo initGatheringInfo(CrawlingParameter crawlingParam) {
        return GatheringInfo.of(crawlingParam);
    }

    GatheringInfo fetchAndConvert(CrawlingParameter crawlingParam);
}
