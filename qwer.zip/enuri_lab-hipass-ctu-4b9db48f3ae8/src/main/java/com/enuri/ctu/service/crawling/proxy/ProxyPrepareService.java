package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.RegExpObj;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.service.crawling.PreCrawlingService;
import com.enuri.ctu.service.crawling.header.HeaderService;
import com.enuri.ctu.service.crawling.regexp.RegExpService;
import com.enuri.ctu.service.logging.CtuLoggingService;
import com.enuri.ctu.service.rules.ProxyReplaceUrlRuleFactory;
import com.enuri.ctu.vo.CtuHeaderVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <pre>
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * line: 172 ~ 462
 *
 * ctuGatheringData -> GatheringInfo
 * ctuHeader -> CtuHeaderVO
 * ctuRegexp -> CtuRegExpVO
 * urlLink -> ReplacedUrlLink
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class ProxyPrepareService implements PreCrawlingService {

    private final HeaderService headerService;
    private final RegExpService regExpService;
    private final ProxyReplaceUrlRuleFactory urlRuleFactory;
    private final CtuLoggingService loggingService;
    private final GeneralGatheringInfoService gatheringInfoService;

    @Override
    @LoggingProcessTime
    public CrawlingUnit getCrawlingUnit(CrawlingParameter crawlingParam) {
        final Long shopCode = crawlingParam.getShopCode();

        // init + gatheringInfo
        GatheringInfo gatheringInfo = this.gatheringInfoService.fetchAndConvert(crawlingParam);
        log.info("GatheringInfo : {}", gatheringInfo);

        // header setting
        List<CtuHeaderVO> headers = this.headerService.getCrawlingHeaders(crawlingParam, gatheringInfo);
        log.info("CTU HEADER Size : {}", headers.size());

        // regexp
        RegExpObj regExpObj = this.regExpService.getCtuRegExpList(crawlingParam, gatheringInfo);

        if (regExpObj.isEmpty()) {
            log.error("ctuRegExp Not Found - shopCode: {} /goodsCode: {} /service: {} /ctuDevice: {}",
                    shopCode, crawlingParam.getGoodsCode(), crawlingParam.getService().getCode(),
                    crawlingParam.getDevice().getCode());
            FailLog failLog = FailLog.builder()
                    .crawlingUrl("")
                    .gtrTimeOut(gatheringInfo.getGtrTimeOut())
                    .failType(6)
                    .build();
            this.loggingService.loggingFail(failLog);
            throw new CtuDataNotFoundException(ResultMessageCode.FAIL_6);
        }

        // shopCode 별로 크롤링 URL 을 변환: ShopRule.java::replaceProxyUrlLink 참고
        // line: 231 ~ 462
        ReplacedUrlLink urlLink = this.urlRuleFactory.getUrlRule(ShopCode.getShopCode(shopCode))
                .replaceProxyUrlLink(crawlingParam, gatheringInfo);
        log.info("Original URL SHOP_CODE[{}-{}] : {}", ShopCode.getShopCode(shopCode), shopCode, gatheringInfo.getGtrUrl());
        log.info("Replaced URL SHOP_CODE[{}-{}] : {}", ShopCode.getShopCode(shopCode), shopCode, urlLink.getUrlLink());

        return CrawlingUnit.builder()
                .gatheringInfo(gatheringInfo)
                .headerList(headers)
                .regExpList(regExpObj.getCtuRegExpVOList())
                .shopJobData(regExpObj.getShopJobData())
                .replacedUrlLink(urlLink)
                .paramGoodsCode(crawlingParam.getGoodsCode())
                .paramCtuTest(crawlingParam.getCtuTest())
                .paramUrl(crawlingParam.getUrl())
                .paramDevice(crawlingParam.getDevice())
                .paramGoodsName(crawlingParam.getGoodsNm())
                .paramIpType(crawlingParam.getIpType())
                .tblPriceListData(crawlingParam.getTblPriceListData())
                .build();
    }
}
