package com.enuri.ctu.service.cache;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.dao.redis.CtuParamRedisRepository;
import com.enuri.ctu.entity.CtuParamEntity;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * [original source info]
 * package: com.enuri.service
 * class name: CtuRedisServiceTest.java
 * </pre>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RedisCacheService implements CacheService {

    private final CtuParamRedisRepository ctuParamRedisRepository;

    /**
     * <pre>
     * source: com.enuri.service.CtuRedisServiceTest::getRedisTest
     * 
     * Redis Key : "shopCode/goodsCode/device"
     * 동일한 key 로 저장되어 있는지 확인
     * </pre>
     * @see CtuParamEntity
     */
    @LoggingProcessTime
    @Override
    public boolean isDuplicated(CtuParamVOWrapper paramVO) {
        CtuParamEntity entity = new CtuParamEntity(paramVO);
        boolean present = this.ctuParamRedisRepository
                .findById(entity.getId())
                .isPresent();

        if (present) {
            log.info("Duplicated Redis Data [Key(shopCode/goodsCode/Device): {}]", entity.getId());
        }

        return present;
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuRedisServiceTest::setRedisTest
     *
     * Redis Key : "shopCode/goodsCode/device"
     * Redis Value : now yyyy-MM-dd HH:mm:ss (com.enuri.ctu.util.CommonUtil::getLocalDateTime)
     * Redis 저장
     * </pre>
     * @see CtuParamEntity
     * @see com.enuri.ctu.util.CommonUtil
     */
    @LoggingProcessTime
    @Override
    public void caching(CtuParamVOWrapper paramVO) {
        CtuParamEntity entity = new CtuParamEntity(paramVO);
        this.ctuParamRedisRepository.save(entity);
        log.info("Redis Stored [Key(shopCode/goodsCode/Device): {}]", entity.getId());
    }
}
