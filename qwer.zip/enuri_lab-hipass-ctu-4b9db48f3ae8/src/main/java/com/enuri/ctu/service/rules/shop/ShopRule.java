package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.service.rules.delivery.DeliveryInfoHelper;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import org.springframework.util.StringUtils;

public interface ShopRule {

    // shop 별 db 조회결과(originalPriceList) 체크
    default ResultMessageCode checkOriginalPriceList(TblPriceListDataVO originalPriceList) {
        // default nulll -> 정상
        return null;
    }

    // GTR_CODE 변환
    default long replaceGtrCode(long originalGtrCode, long shopCode, String device) {
        // default nothing to do
        return originalGtrCode;
    }

    // proxy 를 사용하는 url 변환
    default ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String url = param.getUrl();
        String gtrUrl = gatheringInfo.getGtrUrl();

        String urlLink;
        if (StringUtils.hasText(param.getPlNo()) && ShopCode.G_MARKET == ShopCode.getShopCode(param.getShopCode())) {
            String gtrGoodsSubCode = RegExpUtils.getRegExpData(url, "goodscode=([0-9]{1,20}.*?)");
            urlLink = gtrUrl.replace("GTR_GOODS_CODE", gtrGoodsSubCode);
            param.setGoodsCode(gtrGoodsSubCode);
        } else {
            urlLink = gtrUrl.replace("GTR_GOODS_CODE", param.getGoodsCode());
        }

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .build();
    }

    // proxy 를 사용하지 않는 url 변환
    default ReplacedUrlLink replaceNonProxyUrlLink(CrawlingParameter parameter, GatheringInfo gatheringInfo) {
        final Long shopCode = parameter.getShopCode();
        final String goodsCode = parameter.getGoodsCode();

        String urlBuilder = "http://cws.enuri.com/cws/getCwsData.cws?shopCode=" + shopCode +
                "&goodsCode=" +
                goodsCode +
                "&device=" +
                parameter.getDevice().getCode() +
                "&service=1&cwsType=1&siteNo=" +
                "&salestrNo=";

        return ReplacedUrlLink.builder()
                .urlLink(urlBuilder)
                .build();
    }

    // webClient call 에서 실패한 경우를 대비하여 실행되는 프로세스
    default CrawlingResponse fallbackProcess(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, CrawlingResponse response) {
        // default nothing to do
        return response;
    }

    default ParsingResult beforeParsing(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        // default nothing to do
        return ParsingResult.builder()
                .ctuHtmlData(crawlingResult)
                .resultDataSub(new ResultDataSub())
                .build();
    }

    default void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service,
                                     CrawlingUnit unit) {
        // default nothing to do
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 70 ~ 770
     * 
     * shopCode 가 있는 조건문을 제외하고 delvMsg 만 가지고 생성하는 로직
     * </pre>
     */
    default DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        return DeliveryInfoHelper.getDeliveryInfoClass(deliveryInfoParam);
    }
}
