package com.enuri.ctu.service.rules.shop.cjmall;

import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CjMallRuleHelper {

    private final SimpleWebClient simpleWebClient;

    public String subCall(String goodsCode) {
        String urlLink = "https://display.cjonstyle.com/c/rest/item/GTR_GOODS_CODE/deliveryInfo.json?unitCode=GTR_GOODS_CODE&channelCode=30002002";
        urlLink = urlLink.replace("GTR_GOODS_CODE", goodsCode);

        return this.simpleWebClient.get(urlLink, null).getBody();
    }
}
