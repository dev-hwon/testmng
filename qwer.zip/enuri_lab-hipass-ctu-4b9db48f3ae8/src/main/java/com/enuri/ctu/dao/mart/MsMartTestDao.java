package com.enuri.ctu.dao.mart;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MsMartTestDao {

//    int connectMartTest();
}
