package com.enuri.ctu.service.parse;

import com.enuri.ctu.constant.DeliveryPriceCode;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.DivideCode;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.parse.AsyncParsingParameter;
import com.enuri.ctu.dto.parse.AsyncParsingResult;
import com.enuri.ctu.dto.parse.ParsingDataParameter;
import com.enuri.ctu.service.rules.shop.lotte.LotteRule;
import com.enuri.ctu.util.ParsingUtil;
import com.enuri.ctu.vo.CtuRegExpVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Component
@RequiredArgsConstructor
public class AsyncParser {

    private final LotteRule lotteRule;


    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 615 ~ 626
     * </pre>
     */
    @Async
    public CompletableFuture<AsyncParsingResult> extractParsingValue(AsyncParsingParameter asyncParsingParameter) {
        log.debug("Async Parsing start");
        ShopCode shopCode = asyncParsingParameter.getShopCode();
        RequestService service = asyncParsingParameter.getService();
        int interParkType = asyncParsingParameter.getInterParkType();
        DeviceType deviceType = asyncParsingParameter.getDeviceType();
        String htmlData = asyncParsingParameter.getHtmlData();
        CtuRegExpVO regExpVO = asyncParsingParameter.getRegExpVO();

        String regexpRetType = regExpVO.getRegexpGetType();
        String extractedData;               // retData
        if (this.isInterParkOtpGoods(service, interParkType, deviceType, regExpVO.getRegexpDivis(), htmlData)) {
            ParsingDataParameter parsingDataParameter = ParsingDataParameter.builder()
                    .startStr("dcPriceOpt")
                    .endStr("spsaleYn")
                    .allStr("dcPriceOpt\":(.*?),")
                    .sourceHtml(htmlData)
                    .service(service)
                    .regExpRetType(regexpRetType)
                    .build();
            extractedData = ParsingUtil.parseHtmlData(parsingDataParameter);
        } else if ("1".equals(regexpRetType)) {
            ParsingDataParameter parsingDataParameter = ParsingDataParameter.builder()
                    .startStr(regExpVO.getRegexpStartStr())
                    .endStr(regExpVO.getRegexpEndStr())
                    .allStr(regExpVO.getRegexpAllStr())
                    .sourceHtml(htmlData)
                    .service(service)
                    .build();
            extractedData = ParsingUtil.parseHtmlData(parsingDataParameter);
        } else if ("2".equals(regexpRetType)) {
            ParsingDataParameter parsingDataParameter = ParsingDataParameter.builder()
                    .sourceHtml(htmlData)
                    .allStr(regExpVO.getRegexpAllStr())
                    .build();
            extractedData = ParsingUtil.parseHtmlDataByIndex(parsingDataParameter);
        } else {
            return CompletableFuture.completedFuture(null);
        }

        if (!StringUtils.hasText(extractedData)) {
            return CompletableFuture.completedFuture(null);
        }

        AsyncParsingResult result = AsyncParsingResult.builder()
                .key(regExpVO.getDivideKeyName())
                .extractedData(extractedData)
                .regexpDivis(regExpVO.getRegexpDivis())
                .regExpReturnType(regExpVO.getRegexpRetType())
                .build();

        // line: 629 ~ 676
        if (DivideCode.isDeliveryPrice(regExpVO.getRegexpDivis())) {
            extractedData = this.getDeliveryPriceWord(extractedData, shopCode);

            result.setHasDeliveryPrice(true);
            result.setDeliveryPrice(extractedData);
        }

        return CompletableFuture.completedFuture(result);
    }


    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider.getProxyWebSpiderContent
     * line: 565
     * </pre>
     *
     * 인터파크 otp 상품 가격처리(정규식 바꿔줘야해) //pc조건추가 SR34198
     */
    private boolean isInterParkOtpGoods(RequestService service, int interParkType, DeviceType deviceType,
                                        String regexpDivis, String htmlData) {
        List<String> allowedDivisList = Arrays.asList("1", "2");

        return RequestService.HOMEPAGE == service &&
                interParkType == 1 &&
                DeviceType.PC == deviceType &&
                allowedDivisList.contains(regexpDivis) &&
                !htmlData.contains("\"dcPriceOpt\":0,");
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 629 ~ 676
     * </pre>
     */
    public String getDeliveryPriceWord(String str, ShopCode shopCode) {
        DeliveryPriceCode deliveryPriceCode = DeliveryPriceCode.getDeliveryPriceCode(str);
        if (deliveryPriceCode != null) {
            return deliveryPriceCode.getDeliveryPriceValue(str);
        }

        if (StringUtils.hasText(str) && str.contains("distCost\":0\"")) {
            return null;
        }

        if(ShopCode.isLotte(shopCode)) {
            return this.lotteRule.getDeliveryPriceWord(str);
        }

        return null;
    }
}
