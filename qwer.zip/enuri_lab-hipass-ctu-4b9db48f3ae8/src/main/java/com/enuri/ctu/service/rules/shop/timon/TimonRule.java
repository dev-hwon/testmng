package com.enuri.ctu.service.rules.shop.timon;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.connect.CtuWebClient;
import com.enuri.ctu.service.logging.CtuLoggingService;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.util.CommonUtil;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Component
@RequiredArgsConstructor
public class TimonRule implements ShopRule {

    private static final String PROTOCOL_HTTP = "http";
    private static final String PROTOCOL_HTTPS = "https";

    private final CtuWebClient webClient;
    private final CtuLoggingService loggingService;

    private final TimonRuleHelper helper;

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String urlLink = this.makeUrlLink(param);
        gatheringInfo.setGtrUrl(urlLink);
        int tmonType = 0;

        if (!param.getUrl().contains("o_no")) {
            tmonType = 1;
        }

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(param.getGoodsCode())
                .tmonType(tmonType)
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 736 ~
     * TIMON(6641) http 로 호출했을때 결과가 없으면 https 프로토콜 변경하여 재호출
     *
     * </pre>
     */
    @Override
    public CrawlingResponse fallbackProcess(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, CrawlingResponse response) {
        if (StringUtils.hasText(response.getHtmlContent())) {
            return response;
        }

        log.info("TMon Crawling fallback process");

        String timonResult = response.getHtmlContent();
        final ShopCode shopCode = ShopCode.getShopCode(unit.getGatheringInfo().getShopCode());
        if (ShopCode.TIMON == shopCode && unit.getReplacedUrlLink().getUrlLink().contains(PROTOCOL_HTTP)) {
            String httpsUrlLink = unit.getReplacedUrlLink().getUrlLink().replace(PROTOCOL_HTTP, PROTOCOL_HTTPS);
            unit.getReplacedUrlLink().setUrlLink(httpsUrlLink);
            timonResult = this.webClient.connectWithProxy(proxyInfo, unit).getHtmlContent();

            if (!StringUtils.hasText(timonResult)) {
                log.error("It has failed to crawl to the ShoppingMall2(tmon)");
                FailLog failLog = FailLog.builder()
                        .crawlingUrl(httpsUrlLink)
                        .failType(15)
                        .build();
                this.loggingService.loggingFail(failLog);
                throw new CtuException(ResultMessageCode.FAIL_15);
            }
        }

        response.setHtmlContent(timonResult);
        return response;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 526 ~ 540
     * 
     * 옵션 전체 매진 상품 처리
     * </pre>
     */
    @Override
    public ParsingResult beforeParsing(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        // 옵션상품이 아니면 default
        if (!crawlingResult.contains("<div class=\"prch-option\">")) {
            return ShopRule.super.beforeParsing(param, unit, crawlingResult);
        }

        final String urlLink = unit.getReplacedUrlLink().getUrlLink();
        String categoryNo = RegExpUtils.getRegExpData(crawlingResult, "sDepth1No : '(.*?)',");
        int lastIndex = urlLink.contains("?") ? urlLink.indexOf("?") : urlLink.length();
        String tmonNo = urlLink.substring(urlLink.indexOf("deal/") + 5, lastIndex);

        String result = this.helper.soldOutCheckCall(categoryNo, tmonNo);

        ResultDataSub resultDataSub = new ResultDataSub();
        if (result.contains("\"soldOut\"") && !result.contains("\"soldOut\":false")) {
            resultDataSub.setSoldOut("1");
        }

        return ParsingResult.builder()
                .resultDataSub(resultDataSub)
                .ctuHtmlData(crawlingResult)
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 475 ~ 490
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service, CrawlingUnit unit) {
        // tmonCardYn
        String tmonCardYn = unit.getReplacedUrlLink().getTmonCardYn();
        long normalPrice = CommonUtil.convertToLongType(resultDataSub.getNormalPrice());
        long salePrice = CommonUtil.convertToLongType(resultDataSub.getSalePrice());

        boolean isPC = unit.getParamDevice() == DeviceType.PC;
        boolean isTmonCardTrue = StringUtils.hasText(tmonCardYn) && "Y".equals(tmonCardYn);
        boolean isContainCardWord = CommonUtil.checkSimpleCardWord(unit.getTblPriceListData().getGoodsNm());

        if (isPC && isTmonCardTrue && (normalPrice != 0L || salePrice != 0L) && isContainCardWord) {
            long tmonPrice = (salePrice != 0) ? salePrice : normalPrice;
            // 티몬 카드가 call
            long cardPrice = this.helper.cardPriceCall(tmonPrice, resultDataSub.getInstChargePrice());

            if (cardPrice != 0L) {
                resultDataSub.setCardPrice(cardPrice);
            }
        }
    }

    private String makeUrlLink(CrawlingParameter param) {
        boolean checkQuestionMark = false;

        String url = param.getUrl();
        String regExpData = RegExpUtils.getRegExpData(url, "p_no=([0-9]{1,20}.*?)");
        String defaultGtrUrl = "http://www.tmon.co.kr/deal/GTR_GOODS_CODE";
        String urlLink = defaultGtrUrl.replace("GTR_GOODS_CODE", regExpData);

        if (url.contains("o_no")) {
            checkQuestionMark = true;
            String optDealSrl = RegExpUtils.getRegExpData(url, "o_no=([0-9]{1,20}.*?)");
            urlLink += "?opt_deal_srl=" + optDealSrl;
        }

        if (url.contains("coupon_srl")) {
            if (checkQuestionMark) {
                urlLink += "&";
            } else {
                urlLink += "?";
            }
            String couponSrl = RegExpUtils.getRegExpData(url, "coupon_srl=([0-9]{1,20}.*?)");
            urlLink += "coupon_srl" + couponSrl;
        }

        if (DeviceType.MOBILE == param.getDevice() && "커스텀뷰".equals(param.getCpSection1())) {
            String urlLinkSubString = urlLink.substring(urlLink.lastIndexOf("deal/") + 5);
            String tourUrlLink = "http://mbiz-capi.ticketmonster.co.kr/api/1/tour/get_deal/GTR_GOODS_CODE";
            urlLink = tourUrlLink.replace("GTR_GOODS_CODE", urlLinkSubString);
        }

        return urlLink;
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 157 ~ 189
     * source 의 221 ~ 325 라인은 if/else 의 특성상 위(157라인)에서 이미 처리 된 뒤라 실행되지 않으므로 옮기지 않음
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        Pattern pattern = Pattern.compile("\"(.*?)\"\"deliveryType\":\"(.*?)\"\"deliveryProductType\":\"(.*?)\"\"minTotalPaidForFreeDelivery\":(.*?)\"deliveryFee\":(\\d*)");
        Matcher matcher = pattern.matcher(deliveryInfoParam.getDeliveryMessage());

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        while (matcher.find()) {
            if ("AFTER".equals(matcher.group(1))) {
                deliveryInfoClass.setDeliveryInfo("착불");
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryType2("0");
                deliveryInfoClass.setRightnLeft("2");
            } else if (!matcher.group(4).isEmpty()) {
                long tempLong = Long.parseLong(matcher.group(4));
                if (tempLong > deliveryInfoParam.getCrawlingPrice()) {
                    deliveryInfoClass.setDeliveryInfo(matcher.group(5));
                    deliveryInfoClass.setDeliveryInfo2(matcher.group(5));
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("2");
                } else {
                    deliveryInfoClass.setDeliveryInfo("무료배송");
                    deliveryInfoClass.setDeliveryInfo2("0");
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("1");
                }
            }
        }

        return deliveryInfoClass;
    }
}
