package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <pre>
 *     DB: Oracle eloc
 *     Table: CTU_SHOP_INFO
 * </pre>
 */
public enum ShopCode {
    GALLERIA_MALL(6620),            // 갤러리아몰
    QOO10(7857),                    // Qoo10
    TAILLIST(8090),                 // 테일리스트
    ICODA(273),                     // 아이코다
    COMPUZONE(1634),                // 컴퓨존
    DN_SHOP(1878),                  // 디앤샵
    JOYZEN(4841),                   // 조이젠
    POST(5438),                     // 우체국
    DONGWON_MALL(6193),             // 동원몰
    GABANGPOP(6377),                // 가방팝
    SSG(6665),                      // SSG.COM
    INTERPARK_ITOYS(6780),          // 인터파크 아이토이즈
    REEBONZ(7797),                  // reebonz
    SSG_DEPT(144),                  // 신세계백화점
    SSG_MALL(47),                   // 신세계몰
    LOTTE_ON(49),                   // 롯데ON
    INTERPARK(55),                  // 인터파크
    H_MALL(57),                     // Hmall
    GS_SHOP(75),                    // GS SHOP
    AK_MALL(90),                    // AKmall
    EMART_MALL(374),                // 이마트몰
    G_MARKET(536),                  // G마켓
    LOTTE_I_MALL(663),              // 롯데i몰
    CJ_MALL(806),                   // CJmall
    NS_MALL(974),                   // NSMall
    AUCTION(4027),                  // 옥션
    SHOCKING_DEAL(5910),            // 쇼킹딜
    HI_MART(6252),                  // 하이마트
    HOMEPLUS_DELIVERY_MALL(6361),   // 홈플러스_택배몰
    FASHION_PLUS(6389),             // 패션플러스
    WEMAP(6508),                    // 위메프
    EL_LOTTE(6547),                 // 엘롯데
    HOME_AND_SHOPPING(6588),        // 홈&쇼핑
    TIMON(6641),                    // 티몬
    HALF_CLUB(6644),                // 하프클럽
    O_CLOCK(6688),                  // 오클락
    G9(7692),                       // G9
    COUPANG(7861),                  // 쿠팡
    TIME_2_PRICE(7885),             // 타임투프라이스
    HOMEPLUS_MART(7890),            // 홈플러스_마트
    CJ_ON_MART(6165),               // CJ 온마트
    DAISO_MALL(8032),               // 다이소몰
    SK_STORE(9011),                 // SK스토아
    LOTTE_MART_MALL(7455),          // 롯데마트몰
    SMART_STORE(0);                 // 스마트스토어

    private static final ImmutableMap<Long, ShopCode> SHOP_CODE_IMMUTABLE_MAP;

    static {
        Map<Long, ShopCode> mutableMap = Arrays.stream(ShopCode.values())
                .collect(Collectors.toMap(ShopCode::getCode, e -> e));
        SHOP_CODE_IMMUTABLE_MAP = ImmutableMap.copyOf(mutableMap);
    }

    private final long code;

    ShopCode(long code) {
        this.code = code;
    }

    public static ShopCode getShopCode(Long code) {
        ShopCode shopCode = SHOP_CODE_IMMUTABLE_MAP.get(code);
        if (shopCode == null) {
            return SMART_STORE;
        }
        return shopCode;
    }

    public long getCode() {
        return code;
    }

    public static boolean isLotte(ShopCode shopCode) {
        return LOTTE_ON == shopCode ||
                EL_LOTTE == shopCode ||
                LOTTE_MART_MALL == shopCode;
    }
}
