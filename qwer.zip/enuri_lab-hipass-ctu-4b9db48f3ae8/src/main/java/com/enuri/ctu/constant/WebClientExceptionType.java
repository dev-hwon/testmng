package com.enuri.ctu.constant;

public enum WebClientExceptionType {
    CONNECTION_TIME_OUT("100_1"),
    READ_TIME_OUT("100_2"),
    OTHERS("100_3");

    private final String code;

    WebClientExceptionType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
