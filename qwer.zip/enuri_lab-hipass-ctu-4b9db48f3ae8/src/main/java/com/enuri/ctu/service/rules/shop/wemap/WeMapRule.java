package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dao.oracle.OraclePopularDao;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

@Component
@RequiredArgsConstructor
public class WeMapRule implements ShopRule {

    private static final List<String> CATE_LIST =
            Stream.of("08", "09", "0930", "10", "12", "14", "16", "18", "15", "21")
            .collect(collectingAndThen(toList(), Collections::unmodifiableList));
    private static final String STRING_PRICE_SKIP = "<span class=\"nor_text\">즉시할인가</span>";
    private final OraclePopularDao popularDao;
    private final WeMapHelper helper;


    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        return WeMapUrlConverterFactory
                .getRefineService(param.getUrl(), param.getService())
                .refine(param, gatheringInfo);
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 485 ~ 506
     * </pre>
     */
    @Override
    public ParsingResult beforeParsing(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        if (unit.getReplacedUrlLink().getWmpType() == 2) {
            return ShopRule.super.beforeParsing(param, unit, crawlingResult);
        }

        boolean isSkipCate = this.isSkipCate(param.getCateCode1());
        boolean isNotPopular = this.isNotPopularModel(param.getModelNo());

        String wmpType = null;
        if (isSkipCate) {
            wmpType = "skip_cate:" + param.getCateCode1();
            unit.getReplacedUrlLink().setWmpType(3);
        } else if (isNotPopular) {
            wmpType = "skip_notpopular:";
            unit.getReplacedUrlLink().setWmpType(3);
        } else {
            // source: com.enuri.common.util.WebSpider::isWmpPriceSkipCase
            // line: 1159 ~ 1166
            boolean priceSkip = crawlingResult.contains(STRING_PRICE_SKIP);
            boolean isContainCardWord = CommonUtil.checkDetailCardWord(param.getGoodsNm());

            if (priceSkip) {
                wmpType = "skip";
                unit.getReplacedUrlLink().setWmpType(3);
            } else if (isContainCardWord) {
                wmpType = "skip_include card in the goodsname";
                unit.getReplacedUrlLink().setWmpType(3);
            }
        }

        return ParsingResult.builder()
                .ctuHtmlData(crawlingResult)
                .resultDataSub(new ResultDataSub())
                .wmpType(wmpType)
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 772 ~ 785
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service, CrawlingUnit unit) {
        boolean isFromHomePage = RequestService.isHomePage(service);
        boolean isSoldOutEmpty = resultDataSub.getSoldOut() != null;
        boolean isShopJobDataSoldY = Boolean.TRUE.equals(unit.getShopJobData().getSoldYn());
        boolean isUrlStartWith = unit.getReplacedUrlLink().getUrlLink().startsWith("https://front.wemakeprice.com/product");

        if (isFromHomePage && isSoldOutEmpty && isShopJobDataSoldY && isUrlStartWith) {
            // payload setting -> call -> status code is 422 ?
            boolean isSoldOut = this.helper.isSoldOut(html);
            if (isSoldOut) {
                resultDataSub.setSoldOut("1");
            }
        }

        int wmpType = unit.getReplacedUrlLink().getWmpType();
        if (wmpType == 3) { // 3: skip
            resultDataSub.setSalePrice(null);
            resultDataSub.setNormalPrice(null);
            resultDataSub.setCardPrice(null);
        }
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 426 ~ 461
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        int groupType = 2;
        int groupType2 = 1;
        Pattern pt;

        if (deliveryMessage.contains("이상")) {
            pt = Pattern.compile("(\\d*)/(\\d*)");
        } else {
            pt = Pattern.compile("(\\d*)\"shipFee\":(\\d*)");
            groupType = 1;
            groupType2 = 2;
        }

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        Matcher mc = pt.matcher(deliveryMessage);
        if (mc.find()) {
            String s = mc.group(groupType);
            if (StringUtils.hasText(s) && Long.parseLong(s) > deliveryInfoParam.getOriginalPriceList().getPrice()) {
                String s2 = mc.group(groupType2);
                deliveryInfoClass.setDeliveryInfo(s2);
                deliveryInfoClass.setDeliveryInfo2(s2);
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("2");
            } else {
                deliveryInfoClass.setDeliveryInfo("무료배송");
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("1");
            }

            return deliveryInfoClass;
        }

        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::isNotPopularModel
     * line: 1178 ~ 1185
     *
     * getCountPopular count == 0 (true), count != 0 (false)
     * </pre>
     */
    public boolean isNotPopularModel(long modelNo) {
        int count = this.popularDao.getCountPopular(modelNo);
        return count == 0;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::isSkipCate
     * line: 1168 ~ 1176
     *
     * TRUE: cateCode 의 앞자리 문자가 CATE_LIST와 일치하지 않으면
     * FALSE: 일치하는게 있으면
     * </pre>
     */
    public boolean isSkipCate(String cateCode) {
        return CATE_LIST.stream()
                .noneMatch(cateCode::startsWith);
    }

}
