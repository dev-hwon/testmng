package com.enuri.ctu.dto.parse;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AsyncParsingResult {
    private String key;
    private String extractedData;
    private String regexpDivis;
    private String regExpReturnType;

    private boolean hasDeliveryPrice;
    private String deliveryPrice;
}
