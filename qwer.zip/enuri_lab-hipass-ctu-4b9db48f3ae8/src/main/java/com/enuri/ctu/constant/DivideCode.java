package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.lang.Nullable;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * [oracle] `CTU_PARSE_DIVIDE_INFO` Table 참조
 */
public enum DivideCode {
    NORMAL_PRICE("NormalPrice", "1", "판매가"),
    SALE_PRICE("SalePrice", "2", "할인가"),
    SALE_RATE("SaleRate", "3", "할인율"),
    CARD_PRICE("CardPrice", "4", "카드가"),
    DELIVERY_PRICE("DeliveryPrice", "5", "배송비"),
    SOLD_OUT("SoldOut", "6", "품절"),
    COUPON("Coupon", "7", "쿠폰"),
    COMMISSION("Commission", "8", "수수료"),
    INSTALL_CHARGE_PRICE("InstChargePrice", "9", "설치비"),
    INSTALL_CHARGE_MSG("InstChargeMsg", "10", "상품명"),
    GOODS_IMG_URL("GoodsImgUrl", "11", "상품 대표 이미지"),
    SATISFACTION("Satisfaction", "12", "만족도"),
    MAKER("Maker", "13", "제조사"),
    BRAND("Brand", "14", "브랜드"),
    MAKE_DATE("MakeDate", "15", "제조일자"),
    SELLER_COMPANY("SellerCompany", "16", "판매자 업체"),
    SELLER_NAME("SellerName", "17", "판매자 대표자명"),
    SELLER_ID("SellerId", "18", "판매자 아이디"),
    SELLER_TEL("SellerTel", "19", "판매자 연락처"),
    SELLER_CORP_NUMBER("SellerCorpNumber", "20", "사업자 번호"),
    SELLER_EMAIL("SellerEmail", "21", "판매자 이메일주소"),
    GOODS_PRECAUTION("GoodsPrecaution", "22", "주의 사항"),
    GOODS_CONTENTS("GoodsContens", "23", "본문 내용"),
    SELLER_NICKNAME("SellerNickName", "24", "판매자닉네임"),
    CATEGORY_NAME("CategoryName", "25", "카테고리"),
    ADULT("Adult", "26", "성인인증"),
    NOTIFICATION_PRODUCT_NAME("NotificationProductName", "27", "고시_품명"),
    NOTIFICATION_MATERIAL("NotificationMaterial", "28", "고시_소재"),
    NOTIFICATION_COLOR("NotificationColor", "29", "고시_색상"),
    NOTIFICATION_SIZE("NotificationSize", "30", "고시_치수"),
    NOTIFICATION_MANUFACTURER("NotificationManufacturer", "31", "고시_제조자수입자"),
    NOTIFICATION_COUNTRY("NotificationCountry", "32", "고시_제조국"),
    NOTIFICATION_MANUFACTURING_INFO("NotificationManufacturingInfo", "33", "고시_제조년월일"),
    NOTIFICATION_KIND("NotificationKind", "34", "고시_종류"),
    NOTIFICATION_SIZE_WEIGHT("NotificationSizeWeight", "35", "고시_크기중량"),
    NOTIFICATION_QUALITY("NotificationQuality", "36", "고시_재질"),
    NOTIFICATION_CONSTITUTION("NotificationConstitution", "37", "고시_제품구성"),
    NOTIFICATION_DETAILS("NotificationDetails", "38", "고시_세부사항");

    private final String keyName;
    private final String code;
    private final String desc;

    // cache: get enums with code
    private static final ImmutableMap<String, DivideCode> DIVIDE_CODE_MAP;

    static {
        Map<String, DivideCode> mutableMap = Arrays.stream(DivideCode.values())
                .collect(Collectors.toMap(DivideCode::getCode, e -> e));
        DIVIDE_CODE_MAP = ImmutableMap.copyOf(mutableMap);
    }

    DivideCode(String keyName, String code, String desc) {
        this.keyName = keyName;
        this.code = code;
        this.desc = desc;
    }

    @Nullable
    public static DivideCode getDivideCode(String code) {
        if (code == null || code.isEmpty()) {
            return null;
        }
        return DIVIDE_CODE_MAP.get(code);
    }

    public String getKeyName() {
        return keyName;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static boolean isDeliveryPrice(String code) {
        return DELIVERY_PRICE.getCode().equals(code);
    }
}
