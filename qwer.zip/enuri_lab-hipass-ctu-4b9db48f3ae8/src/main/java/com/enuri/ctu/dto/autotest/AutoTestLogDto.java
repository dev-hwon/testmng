package com.enuri.ctu.dto.autotest;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AutoTestLogDto {
    private Long testCode;
    private Long shopCode;
    private String shopName;
    private String divideCode;
    private String divideName;
    private String goodsCode;
    private String resultPcOrg;
    private String resultPcUp;
    private String resultMobileOrg;
    private String resultMobileUp;
    private String lastProcTime;
    private String memo;
    private String status;
    private String addDate;
    private String modDate;
    private String delDate;
}
