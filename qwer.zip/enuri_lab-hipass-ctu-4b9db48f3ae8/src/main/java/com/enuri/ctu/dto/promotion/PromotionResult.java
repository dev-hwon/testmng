package com.enuri.ctu.dto.promotion;

import com.enuri.ctu.constant.ResultMessageCode;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PromotionResult {

    @JsonProperty("resultMsg")
    private ResultMessageCode resultMessage;

    @JsonProperty("Coupon")
    private String coupon;

    @JsonProperty("promotionRate")
    private String promotionRate;

    @JsonProperty("PromotionPrice")
    private String promotionPrice;

    @JsonProperty("PromotionCardPrice")
    private String promotionCardPrice;

    public boolean isEmpty() {
        return resultMessage == null &&
                coupon == null &&
                promotionRate == null &&
                promotionPrice == null &&
                promotionCardPrice == null;
    }
}
