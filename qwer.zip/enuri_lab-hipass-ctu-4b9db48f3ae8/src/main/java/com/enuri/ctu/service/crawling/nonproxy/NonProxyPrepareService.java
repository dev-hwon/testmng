package com.enuri.ctu.service.crawling.nonproxy;

import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.oracle.OracleGatheringDao;
import com.enuri.ctu.dao.oracle.OracleShopJobDao;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.crawling.ShopJob;
import com.enuri.ctu.service.crawling.PreCrawlingService;
import com.enuri.ctu.service.rules.NonProxyReplaceUrlRuleFactory;
import com.enuri.ctu.vo.CtuShopJobVO;
import com.enuri.ctu.vo.GatheringInfoVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class NonProxyPrepareService implements PreCrawlingService {

    private final OracleGatheringDao oracleGatheringDao;
    private final OracleShopJobDao oracleShopJobDao;

    private final NonProxyReplaceUrlRuleFactory replaceUrlRuleFactory;


    @Override
    public CrawlingUnit getCrawlingUnit(CrawlingParameter parameter) {

        final ShopCode shopCode = ShopCode.getShopCode(parameter.getShopCode());

        GatheringInfo gatheringInfo = this.initGatheringInfo(parameter);
        ShopJob shopJob = this.initShopJob(parameter);

        ReplacedUrlLink replacedUrlLink = this.replaceUrlRuleFactory
                .getUrlRule(shopCode)
                .replaceNonProxyUrlLink(parameter, gatheringInfo);

        return CrawlingUnit.builder()
                .gatheringInfo(gatheringInfo)
                .replacedUrlLink(replacedUrlLink)
                .shopJobData(shopJob)
                .build();
    }


    private GatheringInfo initGatheringInfo(CrawlingParameter parameter) {
        // gathering
        GatheringInfo gatheringInfo = GatheringInfo.of(parameter);

        // gatheringInfoVO
        final Long shopCode = parameter.getShopCode();
        final RequestService service = parameter.getService();
        GatheringInfoVO gatheringInfoVO = this.oracleGatheringDao.fetchGatheringInfoForReal(shopCode,
                parameter.getDevice().getCode(), service.getCode()).get(0);

        gatheringInfo.convertWithGatheringInfo(gatheringInfoVO);

        return gatheringInfo;
    }

    private ShopJob initShopJob(CrawlingParameter parameter) {
        ShopJob shopJob;

        if (RequestService.HOMEPAGE == parameter.getService()) {
            CtuShopJobVO ctuShopJobVO = this.oracleShopJobDao.fetchShopJob(parameter.getShopCode());
            shopJob = ShopJob.of(ctuShopJobVO);
        } else {
            shopJob = ShopJob.builder().build();
        }

        if (Boolean.TRUE.equals(IpType.isLocal(parameter.getIpType()))) {
            shopJob.localTestSetting();
        }

        return shopJob;
    }
}
