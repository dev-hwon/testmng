package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.dao.oracle.OracleSmartStoreDao;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.service.crawling.connect.CtuWebClient;
import com.enuri.ctu.vo.CtuRegExpVO;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SmartStoreRule implements ShopRule {

    private final OracleSmartStoreDao smartStoreDao;
    private final CtuWebClient ctuWebClient;

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String baseStoreUrl = smartStoreDao.fetchSmartStoreUrl(param.getShopCode());
        String mallName = baseStoreUrl.substring(baseStoreUrl.indexOf("com/") + 4);
        String gtrUrl = gatheringInfo.getGtrUrl().replace("GTR_GOODS_CODE", param.getGoodsCode());
        String replaced = gtrUrl.replace("GTR_MALL_NAME", mallName);

        return ReplacedUrlLink.builder()
                .urlLink(replaced)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }

    @Override
    public CrawlingResponse fallbackProcess(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, CrawlingResponse response) {
        CrawlingResponse crawlingResponse = this.ctuWebClient.connectWithProxy(proxyInfo, unit);
        CtuRegExpVO smartStoreRegExp = CtuRegExpVO.builder()
                .regexpStartStr(".")
                .regexpEndStr(".")
                .regexpAllStr("\"productNo\":null,")
                .regexpName("500_품절처리")
                .regexpCode(0L)
                .regexpGetType("2")
                .build();

        unit.getRegExpList().add(smartStoreRegExp);

        return crawlingResponse;
    }
}
