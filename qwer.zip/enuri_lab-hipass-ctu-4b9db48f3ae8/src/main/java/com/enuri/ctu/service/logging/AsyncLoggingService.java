package com.enuri.ctu.service.logging;

import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.dao.newcws.NewCwsProxyInfoDao;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.dto.logging.ProxyAccessLog;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Slf4j
@RequiredArgsConstructor
@Service
public class AsyncLoggingService implements CtuLoggingService {

    private final CtuLogDao ctuLogDao;
    private final NewCwsProxyInfoDao newCwsProxyInfoDao;

    @Async
    @Override
    public void loggingFail(FailLog failLog) {
        log.info("logging failure : {}", failLog.toString());
        this.ctuLogDao.insertFailLog(failLog);
        log.info("fail log insert complete");
    }

    @Async
    @Override
    public void loggingProxyAccess(ProxyConnectInfoVO proxyConnectInfoVO, CrawlingUnit unit, HttpStatus httpStatus) {

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREA));
        ProxyAccessLog proxyAccessLog = ProxyAccessLog.builder()
                .dateNo(today)
                .ip(proxyConnectInfoVO.getProxyIp())
                .serviceType(unit.getGatheringInfo().getCtuService())
                .cpnCd(proxyConnectInfoVO.getProxyCompanyCd())
                .build();

        if (httpStatus.is2xxSuccessful()) {
            this.newCwsProxyInfoDao.insertSuccessProxyAccessLog(proxyAccessLog);
        } else {
            this.newCwsProxyInfoDao.insertFailProxyAccessLog(proxyAccessLog);
        }

    }
}
