package com.enuri.ctu.dto.pricelist;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class MsSqlPriceList {
    private Long plNo;
    private Long plModelno;
    private Long plVcode;
    private String plCategory;
    private String plGoodsnm;
    private Long plPrice;
    private String plUrl;
    private String plNote;
    private String plSrvflag;
    private String plStatus;
    private String plEtc;
    private String plAuthflag;
    private String plAuthdate;
    private Long plSoldoutflag;
    private String plSoldoutdate;
    private String plDate;
    private String plRightnleft;
    private String plMultiflag;
    private String plMulticomment;
    private String plFlag;
    private String plImgurl;
    private Long plCoupon;
    private String plJobtype;
    private Long plStockcount;
    private Long plRegterm;
    private String plSpecflag;
    private String plOrigin;
    private String plDelfeetype;
    private String plDelareatype;
    private Long plDelprice;
    private String plDelfeedesc;
    private String plDelareadesc;
    private Long plBasisfrom;
    private Long plBasisto;
    private String plDeliveryflag;
    private String plAirconfeetype;
    private String plAircondesc;
    private String plAccountYn;
    private String plEsstockflag;
    private Long plInstancePrice;
    private Long plFinalusedflag;
    private String plGoodsfactory;
    private String plGoodscode;
    private String plJobcode;
    private Long plDutycode;
    private Long plGoodsnmCs;
    private Long plUrlCs;
    private String plEsoptflag;
    private String plSearchflag;
    private String plImgurlflag;
    private String plDeliveryinfo;
    private String plSubsideLevel;
    private Long plSubside;
    private String plFreeinterest;
    private String plNochange;
    private Long plGoodscodeCs;
    private Long plAgreeMonth;
    private String plHomeflag;
    private String plOpenSeller;
    private Long plPriceCard;
    private String optionFlag2;
    private String catalogFlag;
    private Long plCashback;
    private Long plTagPrice;
    private String plCallPlan;
    private String plInFeeYn;
    private String plShipFeeYn;
    private Long plBondFee;
    private Long plPenalityFee;
    private String plDeliveryLev;
    private String plSetYn;
    private String plStoreFlag;
    private String plCaCodeDept;
    private String plMobileFlag;
    private Long plDeliveryinfo2;
    private String plDeliverytype2;
    private Long plCopyplno;
    private List<String> exceptionPlNo;
    private List<String> exceptionPlDate; //#SR 26652
    private int modelNoKey; // oracle의 modelno값 사용시 이슈가 있어 mssql에서 조회해 insert하는 것으로 변경 SR181116
    private List<String> notExceptionPlNo; //#SR 38249

    public void setDelivery(DeliveryInfoClass deliveryInfoClass) {
        this.plDeliveryinfo = deliveryInfoClass.getDeliveryInfo();
        this.plDeliveryinfo2 = Long.parseLong(deliveryInfoClass.getDeliveryInfo2());
        this.plDeliverytype2 = deliveryInfoClass.getDeliveryType2();
        this.plRightnleft = deliveryInfoClass.getRightnLeft();
    }

    public boolean validNotExceptionPlNo() {
        return this.notExceptionPlNo != null && this.notExceptionPlNo.size() > 1;
    }
}
