package com.enuri.ctu.service.crawling;

import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;

public interface CrawlingService {

    CrawlingResponse crawling(CrawlingUnit unit);
}
