package com.enuri.ctu.service.rules.delivery;

import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeliveryInfoHelper {
    private static final Map<Predicate<String>, Function<DeliveryInfoParam, DeliveryInfoClass>> CONDITION_MAP;

    static {
        CONDITION_MAP = new LinkedHashMap<>();
        CONDITION_MAP.put(
                predicateOfList(Arrays.asList("무료", "직접배달", "무료배송", "직접배송")),
                byStaticValue("무료배송", "0", "1", "1")
        );
        CONDITION_MAP.put(
                predicateOfString("착불"),
                byStaticValue("착불", "0", "1", "2")
        );
        CONDITION_MAP.put(
                predicateOfList(Arrays.asList("유무료", "수령후지불")),
                byStaticValue("유무료", "0", "0", "2")
        );
        CONDITION_MAP.put(
                predicateOfString("개미만"),
                onlyUnder()
        );
        CONDITION_MAP.put(
                predicateOfString("이상"),
                onlyOver()
        );
    }

    private DeliveryInfoHelper() {
        throw new IllegalStateException("util class");
    }

    public static DeliveryInfoClass getDeliveryInfoClass(DeliveryInfoParam param) {
        String deliveryMessage = param.getDeliveryMessage();
        Optional<Map.Entry<Predicate<String>, Function<DeliveryInfoParam, DeliveryInfoClass>>> optional = CONDITION_MAP.entrySet().stream()
                .filter(entry -> entry.getKey().test(deliveryMessage))
                .findFirst();

        if (optional.isPresent()) {
            return optional.get().getValue().apply(param);
        }

        return DeliveryInfoClass.builder().build();
    }

    private static Predicate<String> predicateOfList(List<String> list) {
        return message -> list.stream().anyMatch(message::contains);
    }

    private static Predicate<String> predicateOfString(String str) {
        return message -> message.contains(str);
    }

    private static Function<DeliveryInfoParam, DeliveryInfoClass> byStaticValue(String s1, String s2, String s3, String s4) {
        return param -> DeliveryInfoClass.builder()
                .deliveryInfo(s1)
                .deliveryInfo2(s2)
                .deliveryType2(s3)
                .rightnLeft(s4)
                .build();
    }

    private static Function<DeliveryInfoParam, DeliveryInfoClass> onlyUnder() {
        return param -> {
            String deliveryMessage = param.getDeliveryMessage();
            Pattern pattern = Pattern.compile("개미만:((?:\\d*\\.)?\\d+)/.*");
            Matcher matcher = pattern.matcher(deliveryMessage);
            String delvCntPrice = null;
            while (matcher.find()) {
                delvCntPrice = matcher.group(1);
            }

            return DeliveryInfoClass.builder()
                    .deliveryInfo(delvCntPrice)
                    .deliveryInfo2(delvCntPrice)
                    .deliveryType2("1")
                    .rightnLeft("2")
                    .build();
        };
    }

    private static Function<DeliveryInfoParam, DeliveryInfoClass> onlyOver() {
        return param -> {
            String deliveryMessage = param.getDeliveryMessage();
            Pattern pt = Pattern.compile("(?:\\d*\\.)?\\d+");
            Matcher mc = pt.matcher(deliveryMessage);

            String delvPriceCondition = "";
            String delvFreePrice = "";
            Long originalPrice = param.getOriginalPriceList().getPrice();
            Long price = param.getPriceList().getPrice();

            if (mc.find()) {
                delvFreePrice = mc.group(0);
                delvPriceCondition = getDelvPriceCondition(deliveryMessage, delvPriceCondition, delvFreePrice, originalPrice);
            }

            if (!StringUtils.hasText(delvFreePrice)) {
                pt = Pattern.compile("(?:\\d*\\.)?\\d+");
                mc = pt.matcher(deliveryMessage);
                if (mc.find()) {
                    delvFreePrice = mc.group(0);
                }
                Pattern ptDelvPrice = Pattern.compile("미만:((?:\\d*\\.)?\\d+)");
                Matcher mcDelvPrice = ptDelvPrice.matcher(deliveryMessage);
                if (mcDelvPrice.find()) {
                    delvPriceCondition = mcDelvPrice.group(1);
                }
            }

            DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
            if (StringUtils.hasText(delvFreePrice) && (price != null || originalPrice != null)) {
                deliveryInfoClass = getDeliveryInfoClassByDelvFreePrice(price, originalPrice, delvFreePrice, delvPriceCondition);
            }

            return deliveryInfoClass;
        };
    }

    private static String getDelvPriceCondition(String deliveryMessage, String delvPriceCondition, String delvFreePrice, Long originalPrice) {
        if (StringUtils.hasText(delvFreePrice) && Long.parseLong(delvFreePrice) > originalPrice) {
            Pattern ptDelvPrice = Pattern.compile("미만:((?:\\d*\\.)?\\d+)");
            Matcher mcDelvPrice = ptDelvPrice.matcher(deliveryMessage);

            if (mcDelvPrice.find()) {
                String s2 = mcDelvPrice.group(0);
                if (StringUtils.hasText(s2) && Long.parseLong(s2) > originalPrice) {
                    delvPriceCondition = mcDelvPrice.group(1);
                }
            }
        }
        return delvPriceCondition;
    }

    private static DeliveryInfoClass getDeliveryInfoClassByDelvFreePrice(Long price, Long originalPrice,
                                                                         String delvFreePrice, String delvPriceCondition) {
        Long delvComparePrice = price;
        if (delvComparePrice == null) {
            delvComparePrice = originalPrice;
        }

        if (Long.parseLong(delvFreePrice) <= delvComparePrice) {
            return DeliveryInfoClass.builder()
                    .deliveryInfo("무료배송")
                    .deliveryInfo2("0")
                    .deliveryType2("1")
                    .rightnLeft("1")
                    .build();
        } else if (StringUtils.hasText(delvPriceCondition)) {
            return DeliveryInfoClass.builder()
                    .deliveryInfo2(delvPriceCondition)
                    .deliveryInfo(delvPriceCondition)
                    .deliveryType2("1")
                    .rightnLeft("2")
                    .build();
        }

        return DeliveryInfoClass.builder().build();
    }
}
