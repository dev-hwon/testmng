package com.enuri.ctu.controller;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.service.savegoods.SaveGoodsService;
import com.enuri.ctu.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("manage")
@RequiredArgsConstructor
public class ManagementController {

    private final SaveGoodsService saveGoodsService;
    private final CtuLogDao ctuLogDao;

    @PostMapping("save-goods/{ctuTest}")
    public ResponseEntity<String> manualStartSaveGoodsTask(@PathVariable String ctuTest, HttpServletRequest request) {
        IpType ipType = CommonUtil.getIpTypeFromRequest(request);
        this.saveGoodsService.saveGoodsProcess(CtuTest.getCtuTest(ctuTest), ipType);

        return ResponseEntity.ok("OK");
    }

    @DeleteMapping("save-goods/{id}")
    public ResponseEntity<String> manualCleanSaveGoodsTask(@PathVariable String id) {
        this.ctuLogDao.deleteSaveGoodsProcessId(id);
        return ResponseEntity.ok("OK");
    }
}
