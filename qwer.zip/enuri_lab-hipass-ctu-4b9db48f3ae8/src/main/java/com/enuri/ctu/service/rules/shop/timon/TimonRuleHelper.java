package com.enuri.ctu.service.rules.shop.timon;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.parse.ParsingDataParameter;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.enuri.ctu.util.ParsingUtil;
import com.enuri.ctu.util.RegExpUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TimonRuleHelper {

    private static final String URL_CHECK_SOLD_OUT = "http://www.tmon.co.kr/api/deals/option/tree/";
    private static final String URL_CHECK_CARD_PRICE = "http://img1.tmon.kr/fe/release/staticResource/deals_v3/m/js/bundle/deals_v3.bundle.js?v="; //SR43484

    private final SimpleWebClient simpleWebClient;

    public String soldOutCheckCall(String categoryNo, String tmonNo) {
        String url = URL_CHECK_SOLD_OUT + tmonNo + "?categoryNo=" + categoryNo + "&calendar=false";
        return simpleWebClient.get(url, this.soldOutCheckHeaders()).getBody();
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuMakePriceService::srvTmonCardPrice
     * line: 21 ~ 59
     * </pre>
     */
    public long cardPriceCall(long tmonPrice, Object instChargePrice) {
        String tmonCardPriceUrl = URL_CHECK_CARD_PRICE + instChargePrice.toString();

        ResponseEntity<String> responseEntity = this.simpleWebClient.get(tmonCardPriceUrl, null);
        if (responseEntity.getBody() == null) {
            log.error("TMON CardPrice Call Failed : {}", tmonCardPriceUrl);
            throw new CtuException(ResultMessageCode.FAIL);
        }

        String html = responseEntity.getBody();
        ParsingDataParameter parsingDataParameter = ParsingDataParameter.builder()
                .startStr("카드 결제")
                .endStr("Math.floor(t)")
                .allStr("var n=function\\(e\\)\\{var t=(.*?)\\*e;return Math.floor\\(t\\)")
                .service(RequestService.HOMEPAGE)
                .sourceHtml(html)
                .regExpRetType("3")
                .build();

        String extractedData = ParsingUtil.parseHtmlData(parsingDataParameter);
        long cardPrice = 0L;
        if (extractedData.contains(".")) {
            double numberOfBelowDecimalPlace = RegExpUtils.getBelowDecimalPlace(extractedData);
            cardPrice = (long) Math.floor(tmonPrice * numberOfBelowDecimalPlace);
        }

        return cardPrice;
    }



    private HttpHeaders soldOutCheckHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Referer", "http://www.tmon.co.kr/deal/3181175818?coupon_srl=2568654&utm_source=enuri&utm_medium=affiliate&utm_term=205013_%EC%97%90%EB%88%84%EB%A6%ACDB&utm_content=&utm_campaign=%EC%97%90%EB%88%84%EB%A6%AC_DB");
        return httpHeaders;
    }
}
