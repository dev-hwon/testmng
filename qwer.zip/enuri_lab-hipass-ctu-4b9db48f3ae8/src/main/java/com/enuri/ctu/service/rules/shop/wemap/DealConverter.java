package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.util.RegExpUtils;

class DealConverter implements WeMapUrlConverter {
    @Override
    public ReplacedUrlLink refine(CrawlingParameter param, GatheringInfo gatheringInfo) {
        final String url = param.getUrl();

        int wmpType = 0;
        String urlLink;
        String gtrGoodsCode;
        // dealNo=
        if (url.contains("dealNo=")) {
            urlLink = this.getDealNoUrlLink(param.getDevice());
            gtrGoodsCode = RegExpUtils.getRegExpData(url, "&dealNo=([0-9]{1,20}.*?)");
        } else {
            urlLink = "http://www.wemakeprice.com/deal/adeal/GTR_GOODS_CODE?utm_source=enuri&utm_medium=PRICE_af&utm_campaign=null";
            gtrGoodsCode = RegExpUtils.getRegExpData(url, "&adeal=([0-9]{1,20}.*?)");
        }

        // ----------

        // aoptid
        if (url.contains("aoptid")) {
            String gtrSubGoodsCode = RegExpUtils.getRegExpData(url, "&aoptid=([0-9]{1,20}.*?)");
            urlLink = url + "&aoptid=" + gtrSubGoodsCode;
            wmpType = 2;
        }

        ReplacedUrlLink replacedUrlLink = ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(gtrGoodsCode)
                .wmpType(wmpType)
                .build();
        this.replaceGtrGoodsCode(replacedUrlLink);
        return replacedUrlLink;
    }

    private String getDealNoUrlLink(DeviceType deviceType) {
        if (DeviceType.MOBILE == deviceType) {
            return "https://mw.wemakeprice.com/deal/GTR_GOODS_CODE?utm_source=enuri&utm_medium=PRICE_af&utm_campaign=null";
        }
        return "https://front.wemakeprice.com/deal/GTR_GOODS_CODE?utm_source=enuri&utm_medium=PRICE_af&utm_campaign=null";
    }
}
