package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;

public enum PromotionOperator {
    CEIL("1") {
        @Override
        public double calc(double promotionApplied, double promotionRoundLength) {
            return Math.ceil((promotionApplied / (promotionRoundLength * 10))) * (promotionRoundLength * 10);
        }
    },
    FLOOR("2") {
        @Override
        public double calc(double promotionApplied, double promotionRoundLength) {
            return Math.floor((promotionApplied / (promotionRoundLength * 10))) * (promotionRoundLength * 10);
        }
    },
    ROUND("3") {
        @Override
        public double calc(double promotionApplied, double promotionRoundLength) {
            return Math.round((promotionApplied / (promotionRoundLength * 10))) * (promotionRoundLength * 10);
        }
    };

    private static final ImmutableMap<String, PromotionOperator> OPERATOR_MAP;

    static {
        OPERATOR_MAP = ImmutableMap.<String, PromotionOperator>builder()
                .put(CEIL.roundDivide, CEIL)
                .put(FLOOR.roundDivide, FLOOR)
                .put(ROUND.roundDivide, ROUND)
                .build();
    }
    private final String roundDivide;

    PromotionOperator(String roundDivide) {
        this.roundDivide = roundDivide;
    }

    public abstract double calc(double promotionApplied, double promotionRoundLength);

    public static PromotionOperator getOperator(String roundDivide) {
        return OPERATOR_MAP.get(roundDivide);
    }
}
