package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.vo.CtuRegExpVO;

import javax.annotation.Nullable;
import java.util.List;

public class RegExpObj {
    private final List<CtuRegExpVO> ctuRegExpVOList;
    private final ShopJob shopJobData;

    public RegExpObj(List<CtuRegExpVO> ctuRegExpVOList, ShopJob shopJobData) {
        this.ctuRegExpVOList = ctuRegExpVOList;
        this.shopJobData = shopJobData;
    }

    public List<CtuRegExpVO> getCtuRegExpVOList() {
        return ctuRegExpVOList;
    }

    @Nullable
    public ShopJob getShopJobData() {
        return shopJobData;
    }

    public boolean isEmpty() {
        return this.ctuRegExpVOList == null || this.ctuRegExpVOList.isEmpty();
    }
}
