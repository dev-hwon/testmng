package com.enuri.ctu.service.crawling;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.ShopJob;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.service.logging.CtuLoggingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class ResultCheckService {

    private final CtuLoggingService loggingService;

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 786 ~ 810
     * </pre>
     */
    public CommonResponse checkCrawlingResponse(CrawlingParameter parameter, CrawlingUnit unit,
                                                CrawlingResponse crawlingResponse) {
        Long shopCode = parameter.getShopCode();
        CommonResponse response = CommonResponse.builder()
                .goodsUrl(unit.getReplacedUrlLink().getUrlLink())
                .shopCode(shopCode)
                .goodsCode(parameter.getGoodsCode())
                .build();

        // timeout?
        if (crawlingResponse.isTimeOut()) {
            // timeout result
            response.setResultMsg(ResultMessageCode.FAIL_18);
            response.setResultData(crawlingResponse.getHtmlContent());
            this.failLogging(unit, 11);
        }

        // no content?
        if (!StringUtils.hasText(crawlingResponse.getHtmlContent())) {
            // empty crawling result
            response.setResultMsg(ResultMessageCode.FAIL_17);
            response.setResultData(ResultMessageCode.FAIL_17.getData());
            this.failLogging(unit, 11);
        } else {
            final String denyMessage = "<title>Sorry! Access denied</title>";
            if (ShopCode.COUPANG == ShopCode.getShopCode(shopCode) && crawlingResponse.getHtmlContent().contains(denyMessage)) {
                response.setResultMsg(ResultMessageCode.FAIL);
                response.setResultData("coupang Access denied");
            }
        }

        return response;
    }

    public void checkResultDataSub(CrawlingParameter parameter, CrawlingUnit unit, CommonResponse commonResponse,
                                   ResultDataSub resultDataSub) {
        // success
        if (!resultDataSub.isEmpty()) {
            commonResponse.setResultMsg(ResultMessageCode.SUCCESS);
            commonResponse.setResultData(resultDataSub);
            commonResponse.setWmpType(resultDataSub.getWmpType());

            this.timonProcess(parameter, unit);
            return;
        }

        // empty
        if (parameter.isRealTest() && StringUtils.hasText(parameter.getDivis())) {
            commonResponse.setResultMsg(ResultMessageCode.NOT_APPLICABLE);
            commonResponse.setResultData(ResultMessageCode.NOT_APPLICABLE.getData());
        } else {
            commonResponse.setResultMsg(ResultMessageCode.FAIL_12);
            commonResponse.setResultData(ResultMessageCode.FAIL_12.getData());
            this.failLogging(unit, 12);
        }

    }

    private void failLogging(CrawlingUnit unit, int failType) {
        FailLog failLog =  FailLog.builder()
                .crawlingUrl(unit.getReplacedUrlLink().getUrlLink())
                .gtrTimeOut(unit.getGatheringInfo().getGtrTimeOut())
                .failType(failType)
                .build();

        this.loggingService.loggingFail(failLog);
    }

    private void timonProcess(CrawlingParameter parameter, CrawlingUnit unit) {
        ShopCode shopCode = ShopCode.getShopCode(parameter.getShopCode());
        if (ShopCode.TIMON != shopCode) {
            return;
        }

        int tmonType = unit.getReplacedUrlLink().getTmonType();
        if (tmonType > 1) {
            unit.getReplacedUrlLink().setTmonType(tmonType);
        }

        ShopJob shopJobData = unit.getShopJobData();
        if (Boolean.TRUE.equals(shopJobData.getCardPriceYn())) {
            unit.getReplacedUrlLink().setTmonCardYn("Y");
        }
    }

}
