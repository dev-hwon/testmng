package com.enuri.ctu.dao.oracle;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleSmartStoreDao {

    String fetchSmartStoreUrl(long shopCode);

}
