package com.enuri.ctu.service;

import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.vo.CtuParamVOWrapper;

import java.util.concurrent.Future;

public interface CtuProcess {

    Future<CommonResponse> processMain(CtuParamVOWrapper paramVO);
}
