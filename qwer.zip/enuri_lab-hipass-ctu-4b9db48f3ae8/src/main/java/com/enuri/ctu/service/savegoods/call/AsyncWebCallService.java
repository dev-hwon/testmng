package com.enuri.ctu.service.savegoods.call;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dao.ctulog.CtuLogDao;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.enuri.ctu.vo.GoodsCodeVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class AsyncWebCallService implements InnerCallService {

    private final SimpleWebClient simpleWebClient;
    private final CtuLogDao ctuLogDao;

    @Value("${ctu.docker.portal-url}")
    private String portalUrl;

    @Async
    @Override
    public CompletableFuture<String> call(GoodsCodeVO goodsCodeVO, CtuTest ctuTest, IpType ipType) {
        final String url = this.generateUrlWithQueryString(goodsCodeVO, ctuTest);
        LocalDateTime requestAt = LocalDateTime.now();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setConnection("keep-alive");

        log.info("MODEL_NO[{}] URL : {}", goodsCodeVO.getModelNo(), url);
        ResponseEntity<String> responseEntity = null;
        String result;
        try {
            responseEntity = this.simpleWebClient.getWithResponseType(url, httpHeaders, String.class);
            result = "OK";
        } catch (WebClientRequestException | WebClientResponseException webClientException) {
            log.error("CTU Call error: {}", webClientException.getMessage());
            result = "ERROR : " + webClientException.getMessage();
        } finally {
            this.insertResult(goodsCodeVO, requestAt, responseEntity, ctuTest);
        }

        return CompletableFuture.completedFuture(result);
    }

    private void insertResult(GoodsCodeVO goodsCodeVO, LocalDateTime requestAt, ResponseEntity<String> responseEntity,
                              CtuTest ctuTest) {
        String response;
        if (this.isError(responseEntity)) {
            log.error("Response Failed : MODEL_NO[{}], SHOP_CODE[{}], GOODS_CODE[{}]",
                    goodsCodeVO.getModelNo(), goodsCodeVO.getShopCode(), goodsCodeVO.getGoodsCode());
            response = null;
        } else {
            response = responseEntity.getBody();
        }

        this.ctuLogDao.insertSaveGoodsResult(goodsCodeVO, requestAt, LocalDateTime.now(), response, ctuTest.getCode());
    }

    private boolean isError(ResponseEntity<String> responseEntity) {
        return responseEntity == null ||
                responseEntity.getStatusCode() != HttpStatus.OK ||
                responseEntity.getBody() == null;
    }


    private String generateUrlWithQueryString(GoodsCodeVO goodsCodeVO, CtuTest ctuTest) {
        return UriComponentsBuilder.fromHttpUrl(this.portalUrl + "/ctuApi/getCtuData.enuri")
                .queryParam("ctu_test", ctuTest.getCode())
                .queryParam("divis", "")
                .queryParam("device", DeviceType.PC.getCode())
                .queryParam("service", RequestService.HOMEPAGE.getCode())
                .queryParam("system_type", SystemType.MINI_BOT.getCode())
                .queryParam("pl_no", "")
                .queryParam("user_ip", "")
                .queryParam("goods_seq", "")
                .queryParam("shop_code", goodsCodeVO.getShopCode())
                .queryParam("goods_code", goodsCodeVO.getGoodsCode())
                .queryParam("shop_type", goodsCodeVO.getShopType())
                .build()
                .toString();
    }
}
