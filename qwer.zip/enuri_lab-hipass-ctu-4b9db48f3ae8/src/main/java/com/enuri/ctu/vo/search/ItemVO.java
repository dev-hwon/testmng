package com.enuri.ctu.vo.search;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ItemVO {
    @JsonProperty("group_flag")
    private Long groupFlag;

    @JsonProperty("modelno_group")
    private String modelNoGroup;

    @JsonProperty("modelno")
    private String modelNo;
}
