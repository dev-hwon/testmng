package com.enuri.ctu.service.rules.shop.wemap;

import com.enuri.ctu.constant.RequestService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class WeMapUrlConverterFactory {
    private WeMapUrlConverterFactory() {
        throw new IllegalStateException("Util Class");
    }

    private static final DefaultConverter DEFAULT_CONVERTER = new DefaultConverter();
    private static final DealConverter DEAL_CONVERTER = new DealConverter();
    private static final ProdNoConverter PROD_NO_CONVERTER = new ProdNoConverter();
    private static final OthersConverter OTHERS_CONVERTER = new OthersConverter();

    static WeMapUrlConverter getRefineService(String url, RequestService service) {
        WeMapUrlConverter converter;
        // service: Homepage(1)
        if (RequestService.HOMEPAGE == service) {
            if (url.contains("prodNo")) {
                converter = PROD_NO_CONVERTER;
            } else if (url.contains("deal")) {
                converter = DEAL_CONVERTER;
            } else {
                converter = OTHERS_CONVERTER;
            }
        } else {
            converter = DEFAULT_CONVERTER;
        }

        // others
        return converter;
    }
}
