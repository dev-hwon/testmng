package com.enuri.ctu.dao.cws;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MariaCwsTestDao {

    int connectCwsTest();
}
