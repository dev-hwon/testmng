package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class GalleriaRule implements ShopRule {

    private static final long REPLACEMENT_GALLERIA_GTR_CODE = 526;

    @Override
    public long replaceGtrCode(long originalGtrCode, long shopCode, String device) {
        log.info("Galleria Replace GTR_CODE : ORIGINAL[{}], SHOP_CODE[{}], DEVICE[{}]", originalGtrCode, shopCode, device);
        if (DeviceType.isMobile(device)) {
            return REPLACEMENT_GALLERIA_GTR_CODE;
        }
        return originalGtrCode;
    }

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String urlLink = param.getUrl();
        gatheringInfo.setGtrUrl(urlLink);
        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }
}
