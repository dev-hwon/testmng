package com.enuri.ctu.service.promotion;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dao.oracle.OraclePromotionDao;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.dto.promotion.CtuPromotionParam;
import com.enuri.ctu.dto.promotion.PromotionResult;
import com.enuri.ctu.vo.CtuPromotionVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class CtuPromotionService implements PromotionService {

    private final OraclePromotionDao oraclePromotionDao;
    private final PromotionHelper promotionHelper;

    /**
     * <pre>
     * source: com.enuri.service.CtuPromotionService::svrCtuPromotion
     * line: 66 ~ 171
     * </pre>
     */
    @Override
    public PromotionResult getCtuPromotion(TblPriceList priceList, TblPriceListDataVO originalPriceList,
                                           CrawlingParameter param) {
        ShopCode shopCode = ShopCode.getShopCode(param.getShopCode());
        CtuPromotionParam promotionParam = CtuPromotionParam.builder()
                .shopCode(shopCode.getCode())
                .testCk(param.getCtuTest().getCode())
                .ctuDevice(param.getDevice().getCode())
                .ctuService(param.getService().getCode())
                .build();

        RequestService service = param.getService();

        CtuPromotionVO saleInfo = this.oraclePromotionDao.getDbPromotionSaleInfo(promotionParam);
        CtuPromotionVO rateInfo = this.oraclePromotionDao.getDbPromotionRateInfo(promotionParam);

        String promotionValue;
        if (ShopCode.AK_MALL == shopCode && StringUtils.hasText(priceList.getEtc())) {
            promotionValue = priceList.getEtc();
        } else {
            promotionValue = this.promotionHelper.getPromotionValue(originalPriceList, shopCode, service, saleInfo);
        }

        if (!StringUtils.hasText(promotionValue)) {
            return PromotionResult.builder().build();
        }

        return this.promotionHelper
                .getPromotionResult(promotionValue, saleInfo, rateInfo, originalPriceList, priceList, param);
    }


}
