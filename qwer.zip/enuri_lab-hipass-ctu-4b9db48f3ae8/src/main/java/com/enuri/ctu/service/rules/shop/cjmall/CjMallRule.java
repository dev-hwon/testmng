package com.enuri.ctu.service.rules.shop.cjmall;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.parse.ParsingResult;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.util.RegExpUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CjMallRule implements ShopRule {

    private final CjMallRuleHelper helper;

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 545 ~ 550
     * </pre>
     */
    @Override
    public ParsingResult beforeParsing(CrawlingParameter param, CrawlingUnit unit, String crawlingResult) {
        RequestService service = param.getService();
        Boolean deliveryYn = unit.getShopJobData().getDeliveryYn();

        if (RequestService.HOMEPAGE == service && Boolean.TRUE.equals(deliveryYn)) {
            String subCallResultJson = this.helper.subCall(param.getGoodsCode());
            return ParsingResult.builder()
                    .ctuHtmlData(crawlingResult + subCallResultJson)
                    .resultDataSub(new ResultDataSub())
                    .build();
        }

        return ShopRule.super.beforeParsing(param, unit, crawlingResult);
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::cjDeliveryLogic
     * line: 56 ~ 67
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        final String sourceStr = deliveryInfoParam.getDeliveryMessage() + "}";
        final String deliveryPricePattern = "\"price\":(.*?)\"minorAmount";
        final String minorAmountPattern = "minorAmount\":(\\d+)}";

        String deliveryPriceStr = RegExpUtils.getRegExpData(sourceStr, deliveryPricePattern);
        String minorAmountStr = RegExpUtils.getRegExpData(sourceStr, minorAmountPattern);

        long minorAmount = Long.parseLong(minorAmountStr);

        DeliveryInfoClass deliveryInfoClass;
        if (deliveryInfoParam.getCrawlingPrice() >= minorAmount) {
            deliveryInfoClass = DeliveryInfoClass.builder()
                    .deliveryInfo("무료배송")
                    .deliveryInfo2("0")
                    .deliveryType2("1")
                    .rightnLeft("1")
                    .build();
        } else {
            deliveryInfoClass = DeliveryInfoClass.builder()
                    .deliveryInfo(deliveryPriceStr)
                    .deliveryInfo2(deliveryPriceStr)
                    .deliveryType2("1")
                    .rightnLeft("2")
                    .build();
        }

        return deliveryInfoClass;
    }


}
