package com.enuri.ctu.dto;

import com.enuri.ctu.constant.MinibotResult;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.promotion.PromotionResult;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonResponse implements Serializable {

    // CTU 처리 성공여부
    private ResultMessageCode resultMsg;

    private Object resultData;

    // 모델최저가
    private Long modelMinPrice;

    // 상품카테고리
    private String goodsCategory;

    // 상품코드
    @JsonProperty("GoodsCode")
    private String goodsCode;

    // 미니봇 처리용
    @JsonProperty("resultMinibotMsg")
    private MinibotResult minibotResult;

    // 쇼핑몰코드
    @JsonProperty("ShopCode")
    private Long shopCode;

    // 호출 타겟 URL
    @JsonProperty("GoodsUrl")
    private String goodsUrl;

    @JsonProperty("resultDataPromotion")
    private PromotionResult resultDataPromotion;

    // 단종비율
    private Double hasBeenPer;

    // 단종
    private Boolean hasBeenCk;

    private String wmpType;


}
