package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.RegExpObj;
import com.enuri.ctu.dto.crawling.RegExpParameter;
import com.enuri.ctu.dto.logging.FailLog;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.service.logging.CtuLoggingService;
import com.enuri.ctu.service.rules.GtrCodeRuleFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CtuRegExpService implements RegExpService {

    private final CtuLoggingService loggingService;
    private final GtrCodeRuleFactory gtrCodeRuleFactory;

    @Override
    @LoggingProcessTime
    public RegExpObj getCtuRegExpList(CrawlingParameter crawlingParam, GatheringInfo gatheringInfo) {

        final RequestService service = crawlingParam.getService();
        final Long shopCode = crawlingParam.getShopCode();
        final String deviceCode = crawlingParam.getDevice().getCode();

        // line: 229 ~ 236
        RegExpParameter regExpParameter = RegExpParameter.of(crawlingParam, gatheringInfo);
        log.debug(regExpParameter.toString());

        // shopCode 에 따라 gtrCode 변경: Lotte 계열과 SSG only
        // line 247 ~ 260
        long replaceGtrCode = this.gtrCodeRuleFactory.getGtrCodeRule(ShopCode.getShopCode(shopCode))
                .replaceGtrCode(regExpParameter.getGtrCode(), shopCode, deviceCode);
        log.info("GTR_CODE ORIGINAL[{}] -> REPLACED[{}]", regExpParameter.getGtrCode(), replaceGtrCode);
        regExpParameter.setGtrCode(replaceGtrCode);

        log.debug("Fetch RegExp from DB : SERVICE[{}-{}]", service.name(), service.getCode());
        RegExpObj regExpObj = DbRegExpFactory
                .getService(service)
                .fetchRegExpList(regExpParameter);

        if (regExpObj.isEmpty()) {
            log.error("ctuRegExp Not Found shopCode: {} /goodsCode: {} /Service: {} /ctuDevice: {}",
                    shopCode, crawlingParam.getGoodsCode(), crawlingParam.getService().getCode(),
                    deviceCode
            );

            FailLog failLog = FailLog.builder()
                    .crawlingUrl("")
                    .gtrTimeOut(gatheringInfo.getGtrTimeOut())
                    .failType(6)
                    .build();

            this.loggingService.loggingFail(failLog);

            throw new CtuDataNotFoundException(ResultMessageCode.FAIL_6);
        }

        return regExpObj;
    }


}
