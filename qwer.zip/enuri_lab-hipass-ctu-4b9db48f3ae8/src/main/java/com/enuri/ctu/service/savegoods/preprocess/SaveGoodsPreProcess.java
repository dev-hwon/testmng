package com.enuri.ctu.service.savegoods.preprocess;

public interface SaveGoodsPreProcess {

    void initWorkingTable();
}
