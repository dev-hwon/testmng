package com.enuri.ctu.service.crawling.proxy;

import com.enuri.ctu.constant.CtuTest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class GatheringInfoFactory {
    private static final Map<CtuTest, GatheringInfoService> GATHERING_INFO_SERVICE_MAP = new EnumMap<>(CtuTest.class);

    private final CrawlerTestGatheringInfoService testGatheringInfoService;
    private final GeneralGatheringInfoService generalGatheringInfoService;

    @PostConstruct
    public void init() {
        GATHERING_INFO_SERVICE_MAP.put(CtuTest.ONLY_FOR_CRAWLER_TEST, this.testGatheringInfoService);
        GATHERING_INFO_SERVICE_MAP.put(CtuTest.RELEASE, this.generalGatheringInfoService);
        GATHERING_INFO_SERVICE_MAP.put(CtuTest.REAL_TEST, this.generalGatheringInfoService);
    }

    public static GatheringInfoService getService(CtuTest key) {
        return GATHERING_INFO_SERVICE_MAP.get(key);
    }
}
