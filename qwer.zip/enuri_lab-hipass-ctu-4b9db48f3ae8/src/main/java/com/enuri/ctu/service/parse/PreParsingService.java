package com.enuri.ctu.service.parse;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.parse.ParsingResult;

public interface PreParsingService {

    ParsingResult preParse(CrawlingParameter param, CrawlingUnit unit, String crawlingResult);
}
