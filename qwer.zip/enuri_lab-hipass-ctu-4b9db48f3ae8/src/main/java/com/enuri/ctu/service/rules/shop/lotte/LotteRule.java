package com.enuri.ctu.service.rules.shop.lotte;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.shop.LottePayload;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.util.RegExpUtils;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;

@Slf4j
@Component
@RequiredArgsConstructor
public class LotteRule implements ShopRule {

    private static final long REPLACEMENT_LOTTE_GTR_CODE = 401;

    private final LotteRuleHelper lotteRuleHelper;


    @Override
    public long replaceGtrCode(long originalGtrCode, long shopCode, String device) {
        log.info("Lotte Replace GTR_CODE : ORIGINAL[{}], SHOP_CODE[{}], DEVICE[{}]", originalGtrCode, shopCode, device);
        if (shopCode == ShopCode.LOTTE_ON.getCode() && !DeviceType.isMobile(device)) {
            return originalGtrCode;
        }
        return REPLACEMENT_LOTTE_GTR_CODE;
    }

    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        final String targetWord = "GTR_GOODS_CODE";
        final String pattern = "sitmNo=(.*?)&";
        final String sourceUrl = param.getUrl();

        String extractRegExp = RegExpUtils.getRegExpData(sourceUrl, pattern);
        String replaced = gatheringInfo.getGtrUrl().replace(targetWord, extractRegExp);

        return ReplacedUrlLink.builder()
                .urlLink(replaced)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 513 ~ 523
     * 
     * 크롤링 결과가 ""(emtpy) 거나 "100_*"(timeout exception) 이면 다른 url로 재호출
     * </pre>
     */
    @Override
    public CrawlingResponse fallbackProcess(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, CrawlingResponse response) {
        if (StringUtils.hasText(response.getHtmlContent()) && !response.isTimeOut()) {
            return response;
        }

        log.info("Lotte Crawling fallback process");

        // lotteGetPayloadParameter
        LottePayload payloadData = LottePayload.of(response.getHtmlContent(), unit.getParamUrl());
        String fallbackResult = this.lotteRuleHelper.fallbackCall(payloadData);
        response.setHtmlContent(fallbackResult);
        return response;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 653 ~ 675
     * 
     * resultJsonDataSub DeliveryPrice value 생성
     * CHECK: 롯데 이외에 다른 shopCode 에도 적용해야할 "DeliveryPrice" 룰이 있다면 ShopRule.java 에 추가할 것(현재는 롯데만)
     * </pre>
     */
    @Nullable
    public String getDeliveryPriceWord(String str) {
        if (!StringUtils.hasText(str)) {
            return null;
        }

        String word;
        if ("0".equals(str) || str.startsWith("0.0")) {
            word = "무료";
        } else if (str.contains(".")) {
            word = str.substring(0, str.indexOf("."));
        } else {
            word = null;
        }

        /*
           아래 코드는 원본(WebSpider.java::getProxyWebSpiderContent, line: 661 ~ 674) 에 해당하는 코드.
           resultJsonDataSub.containsKey("SalePrice"), resultJsonDataSub.containsKey("NormalPrice")
           의 코드가 실행되기 이전에 (Map<String, Object>) resultJsonDataSub.put 을 수행한적이 없으므로
           도달할 수 없는 코드라서 여기에는 옮기지 않았음.
           - fixme 원프로젝트와 테스트시에 확인해볼 것
         */
//        // 롯데 관련 배송비 처리
//        String martDelivery = regExp.getGatheringHtmlIndex("\"dlvInfo\"", "\"dvPdTypCd\"", "마트 매장배송", tempHtmlData, "매장배송확인", 0L);
//        //매장배송 케이스
//        if(martDelivery.equals("1")){
//            if(resultJsonDataSub.containsKey("SalePrice")){
//                retData = (Long.parseLong(resultJsonDataSub.get("SalePrice").toString())>=40000)?"무료":"3000";
//            }else if(resultJsonDataSub.containsKey("NormalPrice")){
//                retData = (Long.parseLong(resultJsonDataSub.get("NormalPrice").toString())>=40000)?"무료":"3000";
//            }
//            resultJsonDataSub.put("DeliveryPrice",retData);
//        }else{
//            System.out.println("=========lotte sample:"+ctuProcessLog.getGoodsCode());
//        }

        return word;
    }
}
