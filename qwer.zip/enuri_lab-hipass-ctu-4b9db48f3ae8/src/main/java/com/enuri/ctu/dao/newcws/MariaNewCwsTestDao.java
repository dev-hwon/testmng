package com.enuri.ctu.dao.newcws;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MariaNewCwsTestDao {

    int connectNewCwsTest();
}
