package com.enuri.ctu.service.rules.shop.shockingdeal;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.dto.pricelist.TblPriceList;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import com.enuri.ctu.vo.TblPriceListDataVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@RequiredArgsConstructor
public class ShockingDealRule implements ShopRule {

    private final ShockingDealHelper shockingDealHelper;

    private static final String SEPARATOR = "_";
    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String goodsCode = param.getGoodsCode();
        String gtrUrl = gatheringInfo.getGtrUrl();

        String urlLink;
        if (goodsCode.contains(SEPARATOR)) {
            urlLink = this.replaceWithSeparator(goodsCode, gtrUrl);
        } else {
            urlLink = this.replaceWithOutSeparator(goodsCode, gtrUrl);
        }

        return ReplacedUrlLink.builder()
                .urlLink(urlLink)
                .gtrGoodsCode(goodsCode)
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 376 ~ 425
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();
        if (deliveryMessage.contains("이상") || deliveryMessage.contains("미만")) {
            String delvPriceCondition = this.getDeliveryPriceCondition(deliveryMessage);
            String delvFreePrice = this.getDeliveryFreePrice(deliveryMessage);
            TblPriceList priceList = deliveryInfoParam.getPriceList();
            TblPriceListDataVO originalPriceList = deliveryInfoParam.getOriginalPriceList();

            DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
            if (StringUtils.hasText(delvFreePrice) && (priceList.getPrice() != null || originalPriceList.getPrice() != null)) {

                Long delvComparePrice = priceList.getPrice();
                if (delvComparePrice == null) {
                    delvComparePrice = originalPriceList.getPrice();
                }

                if (Long.parseLong(delvFreePrice) > delvComparePrice) {
                    deliveryInfoClass.setDeliveryInfo2(delvPriceCondition);
                    deliveryInfoClass.setDeliveryInfo(delvPriceCondition);
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("2");
                } else {
                    deliveryInfoClass.setDeliveryInfo2("0");
                    deliveryInfoClass.setDeliveryInfo("무료배송");
                    deliveryInfoClass.setDeliveryType2("1");
                    deliveryInfoClass.setRightnLeft("1");
                }
            }
        }

        // default
        return ShopRule.super.getDeliveryInfo(deliveryInfoParam);
    }

    @Override
    public CrawlingResponse fallbackProcess(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, CrawlingResponse response) {
        if (StringUtils.hasText(response.getHtmlContent()) && !response.isTimeOut()) {
            return response;
        }

        return this.shockingDealHelper.fallbackCall(proxyInfo, unit);
    }

    private String replaceWithSeparator(String goodsCode, String gtrUrl) {
        String[] split = goodsCode.split(SEPARATOR);
        return gtrUrl.replace("GTR_GOODS_CODE", split[0])
                .replace("GTR_GOODS_SUB_CODE", split[1]);
    }

    private String replaceWithOutSeparator(String goodsCode, String gtrUrl) {
        return gtrUrl.replace("GTR_GOODS_SUB_CODE", "")
                .replace("GTR_GOODS_CODE", goodsCode);
    }

    private String getDeliveryPriceCondition(String deliveryMessage) {
        Pattern pt = Pattern.compile("((?:\\d*\\.)?\\d+)\\(");
        if (deliveryMessage.contains("미만")) {
            pt = Pattern.compile("^(\\d+)");
        }

        String delvPriceCondition = "";
        Matcher mc = pt.matcher(deliveryMessage);
        while (mc.find()) {
            delvPriceCondition = mc.group(1);
        }

        return delvPriceCondition;
    }

    private String getDeliveryFreePrice(String deliveryMessage) {
        Pattern pt = Pattern.compile("((?:\\d*\\.)?\\d+)이상");
        if(deliveryMessage.indexOf("미만") > -1){
            pt = Pattern.compile("(\\d+)미만");
        }

        String delvFreePrice = "";
        Matcher mc = pt.matcher(deliveryMessage);
        while (mc.find()) {
            delvFreePrice = mc.group(1);
        }

        return delvFreePrice;
    }
}
