package com.enuri.ctu.dto;

import com.enuri.ctu.dto.crawling.CrawlingParameter;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class CrawlProcessResult {
    private final CrawlingParameter crawlingParameter;      // ctuProcessLog
    private final CommonResponse commonResponse;            // resultJsonData
}
