package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.dto.promotion.CtuPromotionParam;
import com.enuri.ctu.vo.CtuPromotionVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OraclePromotionDao {

    CtuPromotionVO getDbPromotionSaleInfo(CtuPromotionParam param);

    CtuPromotionVO getDbPromotionRateInfo(CtuPromotionParam param);
}
