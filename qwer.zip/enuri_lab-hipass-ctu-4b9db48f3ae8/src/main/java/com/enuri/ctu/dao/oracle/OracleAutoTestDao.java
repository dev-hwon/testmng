package com.enuri.ctu.dao.oracle;

import com.enuri.ctu.vo.AutoTestLogVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OracleAutoTestDao {

    AutoTestLogVO fetchAutoTestList(Long testCode);

    void updateAutoTestResult(String resultPcOrg, String resultPcUp, Long testCode);

    void updateAutoTestMobileResult(String resultMobileOrg, String resultMobileUp, Long testCode);

    void updateAutoTestProcTime(Long testCode);
}
