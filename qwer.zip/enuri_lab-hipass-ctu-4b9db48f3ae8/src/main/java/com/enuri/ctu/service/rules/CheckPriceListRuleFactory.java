package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.EMartMallRule;
import com.enuri.ctu.service.rules.shop.InterParkRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class CheckPriceListRuleFactory {

    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;
    private final InterParkRule interParkRule;
    private final EMartMallRule eMartMallRule;

    @PostConstruct
    public void init() {
        RULE_MAP.put(ShopCode.INTERPARK, this.interParkRule);
        RULE_MAP.put(ShopCode.EMART_MALL, this.eMartMallRule);
    }

    public ShopRule getCheckOriginalPriceListRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            return this.defaultShopRule;
        }

        return shopRule;
    }
}
