package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.data.redis.cache.RedisCacheConfiguration;

import java.time.Duration;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum RedisCacheType {
    GATHERING_INFO(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(30))),
    HEADERS(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(30))),
    SHOP_JOB(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(30))),
    REG_EXP_LIST(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(30))),
    CPN_STATUS(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofHours(1))),
    SAVE_GOODS_SETTING(RedisCacheConfiguration
            .defaultCacheConfig()
            .entryTtl(Duration.ofDays(1))
    );

    private static final ImmutableMap<String, RedisCacheConfiguration> CACHE_CONFIGURATION_MAP;

    static {
        Map<String, RedisCacheConfiguration> tempMap = Arrays.stream(RedisCacheType.values())
                .collect(Collectors.toMap(Enum::name, e -> e.redisCacheConfiguration));

        CACHE_CONFIGURATION_MAP = ImmutableMap.copyOf(tempMap);
    }

    private final RedisCacheConfiguration redisCacheConfiguration;

    RedisCacheType(RedisCacheConfiguration redisCacheConfiguration) {
        this.redisCacheConfiguration = redisCacheConfiguration;
    }

    public static Map<String, RedisCacheConfiguration> getCacheConfigurationMap() {
        return CACHE_CONFIGURATION_MAP;
    }
}
