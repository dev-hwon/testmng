package com.enuri.ctu.service.crawling.connect;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.connect.preset.AbstractWebClientPreset;
import com.enuri.ctu.service.crawling.connect.preset.NonProxyWebClientPreset;
import com.enuri.ctu.service.crawling.connect.preset.ProxyWebClientPreset;
import com.enuri.ctu.service.crawling.header.HeaderService;
import com.enuri.ctu.service.logging.CtuLoggingService;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * <pre>
 * source: com.enuri.common.util.WebConnect::TargetWebDivideConnectCTU
 * line: 81 ~ 219
 *
 * Sync + Blocking http connector
 * RestTemplate 은 곧 deprecated 될 예정이라 (webflux) WebClient 사용
 * </pre>
 *
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SyncWebClient implements CtuWebClient {

    private static final String PROTOCOL_HTTPS = "https";

    private final CtuLoggingService ctuLoggingService;
    private final ApplicationContext applicationContext;
    private final HeaderService ctuHeaderService;

    /**
     * Proxy 를 통한 http(s) call
     */
    @LoggingProcessTime
    @Override
    public CrawlingResponse connectWithProxy(ProxyConnectInfoVO proxyConnectInfoVO, CrawlingUnit unit)
            throws WebClientException {

        boolean isHttps = unit.getGatheringInfo().getGtrUrl().contains(PROTOCOL_HTTPS);
        final String targetUrl = unit.getReplacedUrlLink().getUrlLink();

        CrawlingResponse response;
        try {
            if ("EL".equals(proxyConnectInfoVO.getProxyCompanyCd())) {
                WebClient webClient = this.getWebClient(true).getWebClient(proxyConnectInfoVO, unit, isHttps);
                response = call(targetUrl, webClient);
            } else {
                response = restTemplateCall(proxyConnectInfoVO, unit, targetUrl);
            }

            // async logging
            this.ctuLoggingService.loggingProxyAccess(proxyConnectInfoVO, unit, response.getHttpStatus());
        } catch (Exception e) {
            // async logging
            log.error("Call Exception : ", e);
            this.ctuLoggingService.loggingProxyAccess(proxyConnectInfoVO, unit, HttpStatus.INTERNAL_SERVER_ERROR);
            throw new CtuException(ResultMessageCode.FAIL, "Call Failed");
        }

        return response;
    }

    private CrawlingResponse restTemplateCall(ProxyConnectInfoVO proxyConnectInfoVO, CrawlingUnit unit, String targetUrl) {
        RestTemplate restTemplate = this.httpProxyRestTemplate(proxyConnectInfoVO, unit);
        HttpHeaders replacedHttpHeaders = this.ctuHeaderService.getReplacedHttpHeaders(unit);
        HttpEntity entity = new HttpEntity(replacedHttpHeaders);
        ResponseEntity<String> responseEntity;
        try {
            responseEntity = restTemplate.exchange(targetUrl, HttpMethod.GET, entity, String.class);
        } catch (RestClientException e) {
            log.error("Call URL[{}] Error : {}", targetUrl, e.getMessage());
            this.ctuLoggingService.loggingProxyAccess(proxyConnectInfoVO, unit, HttpStatus.INTERNAL_SERVER_ERROR);
            throw new CtuException(ResultMessageCode.FAIL, e.getMessage());
        }
        return this.makeResponse(responseEntity, false, targetUrl);
    }

    /**
     * Proxy 를 사용하지 않는 http(s) call
     */
    @LoggingProcessTime
    @Override
    public CrawlingResponse connect(CrawlingUnit unit) throws WebClientException {
        boolean isHttps = unit.getGatheringInfo().getGtrUrl().contains(PROTOCOL_HTTPS);
        final String targetUrl = unit.getReplacedUrlLink().getUrlLink();

        WebClient webClient = this.getWebClient(false).getWebClient(null, unit, isHttps);
        return call(targetUrl, webClient);
    }

    /**
     * proxy / non-proxy 설정을 미리 해둔 preset 선택
     */
    private AbstractWebClientPreset getWebClient(boolean isProxy) {
        if (isProxy) {
            return this.applicationContext.getBean(ProxyWebClientPreset.class);
        }

        return this.applicationContext.getBean(NonProxyWebClientPreset.class);
    }

    /**
     * proxy/non-proxy 로 설정된 WebClient 를 통해서 call
     * @return CrawlingResponse
     */
    private CrawlingResponse call(String targetUrl, WebClient webClient) {
        ResponseEntity<String> responseEntity = null;
        boolean isTimeOut = false;
        try {
            responseEntity = webClient.get()
                    .uri(targetUrl)
                    .retrieve()
                    .toEntity(String.class)
                    .block();
        } catch (WebClientRequestException | WebClientResponseException webClientException) {
            log.error("error: {}", webClientException.getMessage());
            isTimeOut = true;
        }

        return this.makeResponse(responseEntity, isTimeOut, targetUrl);
    }


    /**
     * call 결과를 가지고 CrawlingResponse 를 생성
     */
    private CrawlingResponse makeResponse(ResponseEntity<String> responseEntity, boolean isTimeOut, String targetUrl) {
        HttpStatus httpStatus;
        CrawlingResponse response = CrawlingResponse.builder()
                .isTimeOut(isTimeOut)
                .build();
        if (responseEntity == null) {
            final String message = "Crawling Failed - ResponseEntity is null: " + targetUrl;
            log.error(message);
            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            response.setMessage(message);
        } else {
            httpStatus = responseEntity.getStatusCode();
            response.setHtmlContent(responseEntity.getBody());
        }
        response.setHttpStatus(httpStatus);

        return response;
    }

    private RestTemplate httpProxyRestTemplate(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit) {
        InetSocketAddress inetSocketAddress = new InetSocketAddress(proxyInfo.getProxyIp(), Integer.parseInt(proxyInfo.getProxyPort()));
        Proxy proxy = new Proxy(Proxy.Type.HTTP, inetSocketAddress);
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setProxy(proxy);
        factory.setConnectTimeout(5 * 1000);    // default
        factory.setReadTimeout(unit.getGatheringInfo().getGtrTimeOut());
        return new RestTemplate(factory);
    }
}
