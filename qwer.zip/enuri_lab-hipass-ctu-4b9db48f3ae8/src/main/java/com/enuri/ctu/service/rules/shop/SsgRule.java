package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingParameter;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.dto.crawling.GatheringInfo;
import com.enuri.ctu.dto.crawling.ReplacedUrlLink;
import com.enuri.ctu.dto.delivery.DeliveryInfoClass;
import com.enuri.ctu.dto.delivery.DeliveryInfoParam;
import com.enuri.ctu.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Component
public class SsgRule implements ShopRule {

    private static final long REPLACEMENT_SSG_MOBILE_GTR_CODE = 2461;
    private static final long REPLACEMENT_SSG_GTR_CODE = 811;

    @Override
    public long replaceGtrCode(long originalGtrCode, long shopCode, String device) {
        log.info("SSG Replace GTR_CODE : ORIGINAL[{}], SHOP_CODE[{}], DEVICE[{}]", originalGtrCode, shopCode, device);
        if (DeviceType.isMobile(device)) {
            return REPLACEMENT_SSG_MOBILE_GTR_CODE;
        }

        return REPLACEMENT_SSG_GTR_CODE;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::makeGtrUrl
     * line: 1474 ~ 1482
     * </pre>
     */
    @Override
    public ReplacedUrlLink replaceProxyUrlLink(CrawlingParameter param, GatheringInfo gatheringInfo) {
        String url = gatheringInfo.getGtrUrl();
        if (param.getUrl().contains("sivillage.ssg.com")) {
            if (DeviceType.MOBILE == param.getDevice()) {
                url = "http://m.sivillage.ssg.com/item/itemView.ssg?itemId=GTR_GOODS_CODE&siteNo=6300&ckwhere=s_enuri&appPopYn=n";
            } else {
                url = "http://sivillage.ssg.com/item/itemView.ssg?itemId=GTR_GOODS_CODE&siteNo=6300&ckwhere=s_enuri&appPopYn=n";
            }
        }

        return ReplacedUrlLink.builder()
                .urlLink(url)
                .gtrGoodsCode(param.getGoodsCode())
                .build();
    }

    /**
     * <pre>
     * source: com.enuri.common.util.CwsWebSpider::getCwsWebSpiderContent
     * line: 129 ~ 162
     * </pre>
     */
    @Override
    public ReplacedUrlLink replaceNonProxyUrlLink(CrawlingParameter parameter, GatheringInfo gatheringInfo) {
        final String pattern = "siteNo=(.*?)&salestrNo=(.*?)&";
        String goodsUrl = parameter.getUrl();

        String siteNo = "";
        String saleStrNo = "";

        Pattern pt = Pattern.compile(pattern);
        Matcher mc = pt.matcher(goodsUrl);
        if (mc.find()) {
            siteNo = mc.group(1);
            saleStrNo = mc.group(2);
        }

        ReplacedUrlLink replacedUrlLink = ShopRule.super.replaceNonProxyUrlLink(parameter, gatheringInfo);
        String defaultReplacedUrlLink = replacedUrlLink.getUrlLink();
        String ssgUrlLink = defaultReplacedUrlLink.replace("siteNo=", "siteNo=" + siteNo);
        ssgUrlLink = ssgUrlLink.replace("salestrNo=", "salestrNo=" + saleStrNo);

        replacedUrlLink.setUrlLink(ssgUrlLink);

        return replacedUrlLink;
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuService::svrMainCtuProcReal
     * line: 409 ~ 411
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service,
                                    CrawlingUnit unit) {
        String goodsName = unit.getParamGoodsName();
        boolean isContainCardWord = CommonUtil.checkDetailCardWord(goodsName);
        // goodsName 에 카드문구가 없는데 카드값이 있는 경우 카드값 null 처리
        if (DeviceType.PC == unit.getParamDevice() && !isContainCardWord && resultDataSub.getCardPrice() != null) {
            resultDataSub.setCardPrice(null);
        }
    }

    /**
     * <pre>
     * source: com.enuri.service.CtuDeliveryService::srvGetDeliveryInfo
     * line: 680 ~ 711
     * </pre>
     */
    @Override
    public DeliveryInfoClass getDeliveryInfo(DeliveryInfoParam deliveryInfoParam) {
        String deliveryMessage = deliveryInfoParam.getDeliveryMessage();

        DeliveryInfoClass deliveryInfoClass = DeliveryInfoClass.builder().build();
        if (StringUtils.hasText(deliveryMessage)) {
            if (deliveryMessage.contains("(") && deliveryMessage.contains("만원")) {
                this.setDeliveryInfo(deliveryInfoClass, deliveryMessage, deliveryInfoParam.getOriginalPriceList().getPrice());
            } else if ("무".equals(deliveryMessage)) {
                deliveryInfoClass.setDeliveryInfo("무료배송");
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("1");
            } else if (deliveryMessage.contains("만원이상")) {
                deliveryMessage += " 무료";
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryInfo(deliveryMessage);
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("2");
            } else if (Long.parseLong(deliveryMessage) > 0L) {
                deliveryInfoClass.setDeliveryInfo2(deliveryMessage);
                deliveryInfoClass.setDeliveryInfo(deliveryMessage);
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("2");
            }

        }

        return deliveryInfoClass;
    }


    private void setDeliveryInfo(DeliveryInfoClass deliveryInfoClass, String deliveryMessage, Long originalPrice) {
        long makeNum = 0L;
        Pattern pt = Pattern.compile("(.*?)원[0-9a-zA-Zㄱ-ㅎ가-힇<>:/_\"!.&?()-= ]{0,100}\\((.*?)&");
        Matcher mc = pt.matcher(deliveryMessage);

        if (mc.find()) {
            if(mc.group(2).contains("만원")){
                makeNum = Long.parseLong(mc.group(2).substring(0,mc.group(2).indexOf("만원")));
                makeNum *= 10000L;
            }else if(mc.group(2).contains("천원")){
                makeNum = Long.parseLong(mc.group(2).substring(mc.group(2).indexOf("천원")));
                makeNum *= 1000L;
            }

            if (originalPrice >= makeNum) {
                deliveryInfoClass.setDeliveryInfo("무료배송");
                deliveryInfoClass.setDeliveryInfo2("0");
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("1");
            } else {
                String delvPriceCondition = mc.group(1);
                deliveryInfoClass.setDeliveryInfo(delvPriceCondition);
                deliveryInfoClass.setDeliveryInfo2(delvPriceCondition);
                deliveryInfoClass.setDeliveryType2("1");
                deliveryInfoClass.setRightnLeft("2");
            }
        }
    }
}
