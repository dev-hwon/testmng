package com.enuri.ctu.dao.ctulog;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MariaCtuLogTestDao {

    int connectCtuLogTest();
}
