package com.enuri.ctu.service;

import com.enuri.ctu.dto.CrawlProcessResult;
import com.enuri.ctu.vo.CtuParamVOWrapper;

public interface ClickToUpdateService {
    CrawlProcessResult crawling(CtuParamVOWrapper paramVO);
}
