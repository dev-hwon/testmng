package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum DeviceType {
    PC("1"),
    MOBILE("2");

    private final String code;

    private static final ImmutableMap<String, DeviceType> DEVICE_TYPE_MAP;

    static {
        Map<String, DeviceType> mutableMap = Arrays.stream(DeviceType.values())
                .collect(Collectors.toMap(DeviceType::getCode, e -> e));
        DEVICE_TYPE_MAP = ImmutableMap.copyOf(mutableMap);
    }

    DeviceType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    @Nullable
    public static DeviceType getDeviceType(String code) {
        if (!StringUtils.hasText(code)) {
            return null;
        }
        return DEVICE_TYPE_MAP.get(code);
    }

    public static boolean isMobile(String code) {
        return MOBILE == getDeviceType(code);
    }
}
