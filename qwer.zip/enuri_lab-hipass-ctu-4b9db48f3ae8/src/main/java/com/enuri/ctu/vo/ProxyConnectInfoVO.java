package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ProxyConnectInfoVO {
    private int proxySeq;
    private String proxyIp;
    private String proxyPort;
    private String proxyId;
    private String proxyPw;
    private String proxyCompanyNm;
    private String proxyCompanyCd;
    private int useCnt;
    private int successCnt;
    private int failCnt;
    private String useStatus;
    private String pauseStatus;
}
