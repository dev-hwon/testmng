package com.enuri.ctu.service.ems;

import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.ems.EmsCall;
import com.enuri.ctu.service.crawling.connect.SimpleWebClient;
import com.enuri.ctu.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class DefaultEmsService implements EmsService {

    private static final long BILLION = 1_000_000_000L; // 10억
    private static final String EMS_URL = "http://100.100.100.198:8080/jqgrid/push/push_proc_ems_ajax.jsp";

    private final SimpleWebClient simpleWebClient;

    @Override
    public EmsCall checkPrice(ResultDataSub resultDataSub) {
        long normalPrice = this.getPrice(resultDataSub.getNormalPrice());
        if (normalPrice > BILLION) {
            resultDataSub.setNormalPrice(null);
            return new EmsCall(1, normalPrice);
        }

        long salePrice = this.getPrice(resultDataSub.getSalePrice());
        if (salePrice > BILLION) {
            resultDataSub.setSalePrice(null);
            return new EmsCall(2, salePrice);
        }

        long cardPrice = this.getPrice(resultDataSub.getCardPrice());
        if (cardPrice > BILLION) {
            resultDataSub.setCardPrice(null);
            return new EmsCall(3, cardPrice);
        }

        return new EmsCall(0, 0L);
    }

    @Override
    public void emsCall(Long modelNo, Long plNo, long emsCallPrice) {
        String message = "model_no:" + modelNo + "/pl_no:" + plNo + "/ctu:" + emsCallPrice;
        String url  = EMS_URL + "?title=ctu&msg=" + message;

        ResponseEntity<String> responseEntity = this.simpleWebClient.get(url, null);
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            log.info("<<<<<<<<<<ems send success: {}", url);
        }
    }

    private long getPrice(Object value) {
        if (value != null &&
                String.class.isAssignableFrom(value.getClass()) &&
                CommonUtil.isNumeric(String.valueOf(value))) {
            return Long.parseLong(String.valueOf(value));
        }
        return 0L;
    }
}
