package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum RequestService {
    HOMEPAGE("1"),
    SOCIAL_DIFF("2"),
    FOREIGN_MALL_TARGET("3"),
    ETC("4"),
    SDUL("5"),
    DEAL("6"),
    AL_TOOLBAR("7"),
    DW_CRAWLING("8"),
    DEAL_EVENT("10"),
    OTHER(null);

    private final String code;

    private static final ImmutableMap<String, RequestService> REQUEST_SERVICE_MAP;

    static {
        Map<String, RequestService> mutableMap = Arrays.stream(RequestService.values())
                .filter(e -> e.code != null)
                .collect(Collectors.toMap(RequestService::getCode, e -> e));
        REQUEST_SERVICE_MAP = ImmutableMap.copyOf(mutableMap);
    }

    RequestService(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    @Nullable
    public static RequestService getRequestService(String code) {
        if (!StringUtils.hasText(code)) {
            return null;
        }
        return REQUEST_SERVICE_MAP.get(code);
    }

    public static boolean isHomePage(RequestService service) {
        return HOMEPAGE == service;
    }
}
