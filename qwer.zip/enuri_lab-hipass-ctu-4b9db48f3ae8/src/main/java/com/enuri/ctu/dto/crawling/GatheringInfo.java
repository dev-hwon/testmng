package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.constant.ShopType;
import com.enuri.ctu.vo.GatheringInfoVO;
import lombok.Builder;
import lombok.Data;

/**
 * (enuriCTU_v2.1) CtuGathering.java
 */
@Builder
@Data
public class GatheringInfo {

    private Long gtrCode;
    private String gtrName;
    private String gtrUrl;
    private int gtrTimeOut;
    private String gtrLang;
    private String ctuDevice;
    private String ctuService;
    private Long shopCode;
    private String status;
    private String addId;
    private String addName;
    private String addIp;
    private String addDate;
    private String modId;
    private String modName;
    private String modIp;
    private String modDate;
    private String delId;
    private String delName;
    private String delIp;
    private String delDate;
    private String gtrUrlRegexp;

    public static GatheringInfo of(CrawlingParameter parameterDto) {
        GatheringInfo gatheringInfo = GatheringInfo.builder()
                .shopCode(parameterDto.getShopCode())
                .ctuDevice(parameterDto.getDevice().getCode())
                .ctuService(parameterDto.getService().getCode())
                .build();

        if (ShopType.isSmartStore(parameterDto.getShopType())) {
            gatheringInfo.setShopCode(ShopType.SMART_STORE.getShopCode());
        }

        return gatheringInfo;
    }

    public void convertWithGatheringInfo(GatheringInfoVO gatheringInfoVO) {
        this.gtrCode = gatheringInfoVO.getGtrCode();
        this.gtrName = gatheringInfoVO.getGtrName();
        this.gtrUrl = gatheringInfoVO.getGtrUrl();
        this.gtrTimeOut = gatheringInfoVO.getGtrTimeOut();
        this.gtrLang = gatheringInfoVO.getGtrLang();
        this.ctuDevice = gatheringInfoVO.getCtuDevice();
        this.ctuService = gatheringInfoVO.getCtuService();
        this.shopCode = gatheringInfoVO.getShopCode();
        this.gtrUrlRegexp = gatheringInfoVO.getGtrUrlRegexp();
    }
}
