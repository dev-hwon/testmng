package com.enuri.ctu.service.savegoods;

import com.enuri.ctu.aop.SaveGoodsTask;
import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.service.savegoods.call.AsyncWebCallService;
import com.enuri.ctu.service.savegoods.call.InnerCallService;
import com.enuri.ctu.service.savegoods.preprocess.SaveGoodsPreProcess;
import com.enuri.ctu.vo.GoodsCodeVO;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ScheduledSaveGoodsService implements SaveGoodsService {

    private final SaveGoodsDataHandler dataHandler;
    private final SaveGoodsPreProcess preProcess;
    private final InnerCallService innerCallService;

    @Value("${ctu.save-goods.interval-millis}")
    private Long intervalMillis;

    @Value("${ctu.save-goods.partition-size}")
    private Integer partitionSize;

    @Autowired
    public ScheduledSaveGoodsService(SaveGoodsDataHandler dataHandler, SaveGoodsPreProcess preProcess,
                                     AsyncWebCallService innerCallService) {
        this.dataHandler = dataHandler;
        this.preProcess = preProcess;
        this.innerCallService = innerCallService;
    }

    @Override
    @Async
    @SaveGoodsTask
    public void saveGoodsProcess(CtuTest ctuTest, IpType ipType) {
        // 대상 model 추출 -> 작업테이블 이동
        this.preProcess.initWorkingTable();

        // 구독 모델
        List<Long> allModelNo = this.dataHandler.getAllModelNo();
        List<List<Long>> partition = Lists.partition(allModelNo, this.partitionSize);
        log.info("Partition Size : {}", partition.size());

        int order = 1;
        for (List<Long> subList : partition) {
            List<String> resultList = this.toJoinWorkers(subList, ctuTest, ipType);
            log.info("Model SubList Async Runner Finish [{}/{}] : {}", order, partition.size(), resultList.size());
            this.sleepMillis();
            order++;
        }

    }

    public List<String> toJoinWorkers(List<Long> subList, CtuTest ctuTest, IpType ipType) {
        List<GoodsCodeVO> goodsCodeList = subList.stream()
                .map(this.dataHandler::getGoodsCode)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        log.info("Partitioned GoodsCodeList Size : {}", goodsCodeList.size());

        List<CompletableFuture<String>> futureList = goodsCodeList.stream()
                .map(goodsCodeVO -> this.innerCallService.call(goodsCodeVO, ctuTest, ipType))
                .collect(Collectors.toList());

        return CompletableFuture
                .allOf(futureList.toArray(new CompletableFuture[0]))
                .thenApply(result -> futureList.stream()
                        .map(CompletableFuture::join)
                        .collect(Collectors.toList()
                        )
                )
                .join();
    }

    private void sleepMillis() {
        try {
            TimeUnit.MILLISECONDS.sleep(this.intervalMillis);
        } catch (InterruptedException e) {
            log.error("Interrupted!!");
            Thread.currentThread().interrupt();
        }
    }

}
