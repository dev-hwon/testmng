package com.enuri.ctu.controller;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.constant.SystemType;
import com.enuri.ctu.dto.CommonResponse;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.CtuProcess;
import com.enuri.ctu.vo.CtuParamVO;
import com.enuri.ctu.vo.CtuParamVOWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * <pre>
 * package: com.enuri.controller
 * class file: CtuController.java
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("ctuApi")
public class CtuRestController {

    private final CtuProcess ctuProcess;
    private final ObjectMapper objectMapper;

    /**
     * <pre>
     * source: com.enuri.controller.CtuController::ctuGetDataCtlReal
     * line: 226 ~ 351
     *     
     * 필수값 null check 는 validation(JSR-303, spring-boot-starter-validation) 으로 대체
     * </pre>
     */
    @GetMapping(value = "getCtuData.enuri", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getCtuData(@Valid CtuParamVO paramVO,
                                                     BindingResult bindingResult) throws ExecutionException, InterruptedException {
        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getAllErrors().stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage)
                    .collect(Collectors.joining(" | "));

            throw new CtuException(ResultMessageCode.FAIL, errorMessage);
        }

        log.info("Request Param : {}", paramVO.toString());
        CtuParamVOWrapper paramVOWrapper = new CtuParamVOWrapper(paramVO);

        Future<CommonResponse> asyncProcess = this.ctuProcess.processMain(paramVOWrapper);
        CommonResponse mobileResult = null;
        SystemType systemType = SystemType.getSystemType(paramVOWrapper.getSystemType());

        if (SystemType.MINI_BOT == systemType) {
            log.info("MINI_BOT System Type, Start Mobile Process");
            CtuParamVOWrapper mobileWrapper = CtuParamVOWrapper.copyOf(paramVO, DeviceType.MOBILE);
            Future<CommonResponse> asyncMobileProcess = this.ctuProcess.processMain(mobileWrapper);
            mobileResult = asyncMobileProcess.get();
        }

        CommonResponse result = asyncProcess.get();

        log.info("final result : {}", this.toJsonString(result));
        if (mobileResult != null) {
            log.info("final mobile result : {}", this.toJsonString(mobileResult));
        }

        return ResponseEntity.ok(result);
    }

    private String toJsonString(CommonResponse commonResponse) {
        try {
            return this.objectMapper.writeValueAsString(commonResponse);
        } catch (JsonProcessingException e) {
            log.error("result json serialize error ",e);
            return "result json serialize error ";
        }
    }
}
