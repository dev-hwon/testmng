package com.enuri.ctu.exception;

import com.enuri.ctu.constant.ResultMessageCode;
import lombok.Getter;

@Getter
public class CtuDataNotFoundException extends CtuException {

    public CtuDataNotFoundException(ResultMessageCode resultMessageCode, Object data) {
        super(resultMessageCode, data);
    }

    public CtuDataNotFoundException(ResultMessageCode resultMessageCode) {
        super(resultMessageCode);
    }
}
