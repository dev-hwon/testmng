package com.enuri.ctu.service.rules.shop.shockingdeal;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.dto.crawling.CrawlingResponse;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.service.crawling.connect.CtuWebClient;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class ShockingDealHelper {

    private final CtuWebClient webClient;

    public CrawlingResponse fallbackCall(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit) {
        String fallbackUrl;
        if (DeviceType.PC == unit.getParamDevice()) {
            fallbackUrl = "https://www.11st.co.kr/products/v1/pc/products/GTR_GOODS_CODE/detail?utm_term=&utm_campaign=%BF%A1%B4%A9%B8%AEpc_%B0%A1%B0%DD%BA%F1%B1%B3%B1%E2%BA%BB&utm_source=%BF%A1%B4%A9%B8%AE_PC_PCS&utm_medium=%B0%A1%B0%DD%BA%F1%B1%B3";
        } else {
            fallbackUrl = "http://m.11st.co.kr/products/v1/mw/products/GTR_GOODS_CODE/detail?utm_term=&utm_campaign=%BF%A1%B4%A9%B8%AEpc_%B0%A1%B0%DD%BA%F1%B1%B3%B1%E2%BA%BB&utm_source=%BF%A1%B4%A9%B8%AE_PC_PCS&utm_medium=%B0%A1%B0%DD%BA%F1%B1%B3";
        }

        fallbackUrl = fallbackUrl.replace("GTR_GOODS_CODE", unit.getParamGoodsCode());

        log.info("SHOCKING_DEAL Fallback call : {}", fallbackUrl);
        unit.getReplacedUrlLink().setUrlLink(fallbackUrl);

        return webClient.connectWithProxy(proxyInfo, unit);
    }
}
