package com.enuri.ctu.vo;

import com.enuri.ctu.constant.CtuTest;
import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.DivideCode;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.constant.SystemType;

/**
 * <pre>
 * Request 받은 Query String Parameter : CtuParamVO 는 setter 를 가지고 있어 중간에 데이터의 변조가 이뤄질 수 있으므로
 * wrapper 로 한번 감싸고 setter 를 없애고 getter 와 일부 변환, 그리고 생성자를 포함한다.
 * </pre>
 */
public final class CtuParamVOWrapper {

    // final field
    private final CtuParamVO paramVO;

    // constructor
    public CtuParamVOWrapper(CtuParamVO paramVO) {
        // source: com.enur.service.CtuService::svrMainCtuProcReal
        // line: 179 ~ 183
        if (ShopCode.SSG_DEPT.getCode() == Long.parseLong(paramVO.getShop_code())) {
            paramVO.setShop_code(String.valueOf(ShopCode.SSG_MALL.getCode()));
        }
        this.paramVO = paramVO;
    }



    public CtuTest getCtuTest() {
        return CtuTest.getCtuTest(this.paramVO.getCtu_test());
    }

    public String getShopCode() {
        return this.paramVO.getShop_code();
    }

    public String getGoodsCode() {
        return this.paramVO.getGoods_code();
    }

    public String getPriceListNo() {
        return this.paramVO.getPl_no();
    }

    public DivideCode getDivis() {
        return DivideCode.getDivideCode(this.paramVO.getDivis());
    }

    public DeviceType getDevice() {
        return DeviceType.getDeviceType(this.paramVO.getDevice());
    }

    public RequestService getServiceFrom() {
        return RequestService.getRequestService(this.paramVO.getService());
    }

    public String getUserIp() {
        return this.paramVO.getUser_ip();
    }

    public String getServerIp() {
        return this.paramVO.getServer_ip();
    }

    public String getSystemType() {
        return this.paramVO.getSystem_type();
    }

    public String getUserId() {
        return this.paramVO.getUser_id();
    }

    public String getUserName() {
        return this.paramVO.getUser_name();
    }

    public String getGoodsUrl() {
        return this.paramVO.getGoods_url();
    }

    public String getGoodsSeq() {
        return this.paramVO.getGoods_seq();
    }

    public String getShopType() {
        return this.paramVO.getShop_type();
    }

    public IpType getIpType() {
        return IpType.valueOf(this.paramVO.getIp_type());
    }
    public String getIpWithPort() {
        return this.paramVO.getIp_type();
    }


    public String getValueForLogging() {
        return this.paramVO.getShop_code() + "/" + this.paramVO.getGoods_code() + "/" + this.paramVO.getDevice();
    }

    // deep copy
    public static CtuParamVOWrapper copyOf(CtuParamVO param, DeviceType deviceType) {
        CtuParamVO copy = CtuParamVO.builder()
                .ctu_test(param.getCtu_test())
                .shop_code(param.getShop_code())
                .goods_code(param.getGoods_code())
                .pl_no(param.getPl_no())
                .divis(param.getDivis())
                .device(deviceType.getCode())
                .service(param.getService())
                .user_ip(param.getUser_ip())
                .server_ip(param.getServer_ip())
                .system_type(param.getSystem_type())
                .user_id(param.getUser_id())
                .user_name(param.getUser_name())
                .goods_url(param.getGoods_url())
                .goods_seq(param.getGoods_seq())
                .shop_type(param.getShop_type())
                .ip_type(param.getIp_type())
                .cp_pid(param.getCp_pid())
                .cp_id(param.getCp_id())
                .build();

        return new CtuParamVOWrapper(copy);
    }

    public static CtuParamVOWrapper copyOfSaveGoods(GoodsCodeVO goodsCodeVO, CtuTest ctuTest, DeviceType deviceType,
                                                    IpType ipType) {
        CtuParamVO copied = CtuParamVO.builder()
                .ctu_test(ctuTest.getCode())
                .divis("")
                .device(deviceType.getCode())
                .service(RequestService.HOMEPAGE.getCode())
                .system_type(SystemType.MINI_BOT.getCode())
                .pl_no("")
                .user_ip("")
                .goods_seq("")
                .shop_code(String.valueOf(goodsCodeVO.getShopCode()))
                .goods_code(goodsCodeVO.getGoodsCode())
                .ip_type(ipType.name())
                .build();

        return new CtuParamVOWrapper(copied);
    }
}
