package com.enuri.ctu.dao.newcws;

import com.enuri.ctu.dto.logging.ProxyAccessLog;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface NewCwsProxyInfoDao {

    // getProxyInfoSelectTempAuto
    ProxyConnectInfoVO fetchRandomProxyInfo();

    // getProxyInfoSelectTemp
    ProxyConnectInfoVO fetchRandomProxyInfoOrderByFailCnt();

    // getProxyInfoSelect
    ProxyConnectInfoVO fetchDefaultRandomProxyProxyInfo(String cpnCd, String dateNo);

    String getProxyCpnStatus(String serviceType);

    int insertSuccessProxyAccessLog(ProxyAccessLog proxyAccessLog);
    int insertFailProxyAccessLog(ProxyAccessLog proxyAccessLog);
}
