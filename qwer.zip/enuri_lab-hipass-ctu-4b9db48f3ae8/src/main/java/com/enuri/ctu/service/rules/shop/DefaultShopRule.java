package com.enuri.ctu.service.rules.shop;

import org.springframework.stereotype.Component;

@Component
public class DefaultShopRule implements ShopRule {
}
