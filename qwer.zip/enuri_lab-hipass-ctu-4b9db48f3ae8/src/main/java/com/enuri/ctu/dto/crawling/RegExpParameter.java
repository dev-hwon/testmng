package com.enuri.ctu.dto.crawling;

import com.enuri.ctu.constant.DeviceType;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.constant.ShopType;
import lombok.Builder;
import lombok.Data;
import org.springframework.util.StringUtils;

@Data
@Builder
public class RegExpParameter {
    private long gtrCode;
    private long shopCode;
    private String regexpDivis;
    private String testCk;
    private boolean smartStore;
    private IpType ipType;
    private DeviceType deviceType;

    public static RegExpParameter of(CrawlingParameter crawlingParam, GatheringInfo gatheringInfo) {
        long replacementShopCode = gatheringInfo.getShopCode();
        boolean isSmartStore = false;

        // line: 267 ~ 270
        if (ShopType.isSmartStore(crawlingParam.getShopType())) {
            replacementShopCode = ShopCode.SMART_STORE.getCode();
            isSmartStore = true;
        }

        // line: 228 ~ 245
        String divis = "";
        if (StringUtils.hasText(crawlingParam.getDivis())) {
            divis = crawlingParam.getDivis();
        }

        return RegExpParameter.builder()
                .gtrCode(gatheringInfo.getGtrCode())
                .shopCode(replacementShopCode)
                .regexpDivis(divis)
                .testCk(crawlingParam.getCtuTest().getCode())
                .smartStore(isSmartStore)
                .ipType(crawlingParam.getIpType())
                .deviceType(crawlingParam.getDevice())
                .build();
    }
}
