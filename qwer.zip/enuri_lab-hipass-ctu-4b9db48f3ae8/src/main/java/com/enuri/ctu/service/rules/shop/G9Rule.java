package com.enuri.ctu.service.rules.shop;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dto.ResultDataSub;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.util.RegExpUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class G9Rule implements ShopRule {

    public static final String PATTERN_EXPIRE_DATE = "\"expireDate\": \"(.*?) .*\",";

    /**
     * <pre>
     * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
     * line: 736 ~ 770
     * </pre>
     */
    @Override
    public void adjustResultDataSub(ResultDataSub resultDataSub, String html, RequestService service, CrawlingUnit unit) {
        String expData = RegExpUtils.getRegExpData(html, PATTERN_EXPIRE_DATE);

        if (StringUtils.hasText(expData)) {
            expData = expData.replace(" ", "");
            LocalDate expireDate = LocalDate.parse(expData, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate now = LocalDate.now();

            if (now.isAfter(expireDate)) {
                resultDataSub.setSoldOut("1");
            }
        }
    }
}
