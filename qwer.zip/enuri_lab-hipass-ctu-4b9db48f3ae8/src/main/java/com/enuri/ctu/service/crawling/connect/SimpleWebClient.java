package com.enuri.ctu.service.crawling.connect;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.exception.CtuException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

@Slf4j
@Component
@RequiredArgsConstructor
public class SimpleWebClient {

    private final ConnectionProvider connectionProvider;
    private final ExchangeStrategies exchangeStrategies;

    @LoggingProcessTime
    public ResponseEntity<String> post(String targetUrl, String jsonBody, HttpHeaders httpHeaders) {
        try {
            ResponseEntity<String> responseEntity = this.defaultWebClient()
                    .post()
                    .uri(targetUrl)
                    .headers(header -> header.addAll(httpHeaders))
                    .bodyValue(jsonBody)
                    .retrieve()
                    .toEntity(String.class)
                    .block();

            if (responseEntity == null) {
                final String message = "ResponseEntity is null: " + targetUrl;
                log.error(message);
                throw new CtuException(ResultMessageCode.FAIL);
            }

            return responseEntity;
        } catch (WebClientRequestException | WebClientResponseException webClientException) {
            log.error("SimpleWebClient timeout error: {}", webClientException.getMessage());
            throw new CtuException(ResultMessageCode.FAIL);
        }
    }

    @LoggingProcessTime
    public ResponseEntity<String> get(String targetUrl, HttpHeaders httpHeaders) {
        try {
            ResponseEntity<String> responseEntity = this.getWithResponseType(targetUrl, httpHeaders, String.class);

            if (responseEntity == null) {
                final String message = "ResponseEntity is null: " + targetUrl;
                log.error(message);
                throw new CtuException(ResultMessageCode.FAIL);
            }

            return responseEntity;
        } catch (WebClientRequestException | WebClientResponseException webClientException) {
            log.error("SimpleWebClient timeout error: {}", webClientException.getMessage());
            throw new CtuException(ResultMessageCode.FAIL);
        }
    }

    public <T> ResponseEntity<T> getWithResponseType(String targetUrl, HttpHeaders httpHeaders, Class<T> responseType) {
        return this.defaultWebClient()
                .get()
                .uri(targetUrl)
                .headers(header -> {
                    if (httpHeaders != null) {
                        header.addAll(httpHeaders);
                    }
                })
                .retrieve()
                .toEntity(responseType)
                .block();
    }

    private WebClient defaultWebClient() {
        HttpClient httpClient = HttpClient.create(this.connectionProvider)
                .httpResponseDecoder(httpResponseDecoderSpec -> httpResponseDecoderSpec.maxHeaderSize(32 * 1024));

        return WebClient.builder()
                .exchangeStrategies(this.exchangeStrategies)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }
}
