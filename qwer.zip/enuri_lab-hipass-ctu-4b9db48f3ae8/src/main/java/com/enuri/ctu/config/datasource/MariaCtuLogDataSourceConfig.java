package com.enuri.ctu.config.datasource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * <pre>
 *      MariaDB CTU-log DataSource
 *      property : spring.datasource.hikari.maria-ctu-log
 *      mapper : resources/mapper/maria-ctulog
 *      dao : com.enuri.ctu.dao.ctulog
 * </pre>
 */
@Configuration
@MapperScan(basePackages = "com.enuri.ctu.dao.ctulog", sqlSessionFactoryRef = "ctuLogSqlSessionFactory")
public class MariaCtuLogDataSourceConfig {
    @Bean
    @Qualifier("ctuLogHikariConfig")
    @ConfigurationProperties(prefix = "spring.datasource.hikari.maria-ctu-log")
    public HikariConfig ctuLogHikariConfig() {
        return new HikariConfig();
    }

    @Bean
    @Qualifier("ctuLogDataSource")
    public DataSource ctuLogDataSource() {
        return new HikariDataSource(ctuLogHikariConfig());
    }

    @Bean
    @Qualifier("ctuLogSqlSessionFactory")
    public SqlSessionFactory ctuLogSqlSessionFactory(@Qualifier("ctuLogDataSource") DataSource dataSource,
                                                   ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        factoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        factoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/maria-ctulog/**/*.xml"));
        factoryBean.setVfs(SpringBootVFS.class);

        return factoryBean.getObject();
    }

    @Bean
    @Qualifier("ctuLogSqlSessionTemplate")
    public SqlSessionTemplate ctuLogSqlSessionTemplate(
            @Qualifier("ctuLogSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
