package com.enuri.ctu.dto.shop;

import com.enuri.ctu.util.CommonUtil;
import com.enuri.ctu.util.RegExpUtils;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.function.BinaryOperator;

@Getter
@Setter
@Builder
public class LottePayload {

    @JsonProperty("slQty")
    private static final int SLQTY = 1;

    @JsonProperty("afflPdLwstMrgnRt")
    private static final String AFFLPDLWSTMRGNRT = null;

    @JsonProperty("infwMdiaCd")
    private static final String INFWMDIACD = "PC";

    @JsonProperty("chCsfCd")
    private static final String CHCSFCD = "PA";

    @JsonProperty("chTypCd")
    private static final String CHTYPCD = "PA08";

    private String spdNo;
    private String sitmNo;
    private String trGrpCd;
    private String trNo;
    private String lrtrNo;
    private String strCd;
    private String ctrtTypCd;
    private String slPrc;
    private String sfcoPdMrgnRt;
    private String sfcoPdLwstMrgnRt;
    private String afflPdMrgnRt;
    private String brdNo;
    private String cartDvsCd;
    private String dvCst;
    private String scatNo;
    private String thdyPdYn;

    private String chNo;
    private String chDtlNo;
    private String aplyStdDttm;

    private String fprdDvPdYn;
    private String maxPurQty;
    private String pcsLwstMrgnRt;

    /**
     * <pre>
     * source: com.enuri.service.CtuLotteService::lotteGetPayloadParameter
     * line: 87 ~ 138
     * </pre>
     * @param htmlContent 크롤링 결과 HTMl
     * @param url TBL_PRICELIST 에서 가져온 URL
     */
    public static LottePayload of(String htmlContent, String url) {
        BinaryOperator<String> regExpOperator = (source, pattern) -> {
            String str = RegExpUtils.getRegExpData(source, pattern);
            return CommonUtil.trimStr(str);
        };

        String sfcoPdMrgnRt = regExpOperator.apply(htmlContent, "\"sfcoPdMrgnRt\":(.*?),");
        if (sfcoPdMrgnRt.contains("0.0")) {
            sfcoPdMrgnRt = sfcoPdMrgnRt.substring(0, sfcoPdMrgnRt.indexOf("."));
        }

        String afflPdMrgnRt = regExpOperator.apply(htmlContent, "\"afflMrgnRt\":(.*?),");
        if (afflPdMrgnRt.contains("0.0")) {
            afflPdMrgnRt = afflPdMrgnRt.substring(0, afflPdMrgnRt.indexOf("."));
        }

        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        return LottePayload.builder()
                .spdNo(regExpOperator.apply(htmlContent, "\"spdNo\":\"(.*?)\","))
                .sitmNo(regExpOperator.apply(htmlContent, "\"sitmNo\":\"(.*?)\","))
                .trGrpCd(regExpOperator.apply(htmlContent, "\"trGrpCd\":\"(.*?)\","))
                .trNo(regExpOperator.apply(htmlContent, "\"trNo\":\"(.*?)\","))
                .lrtrNo(regExpOperator.apply(htmlContent, "\"lrtrNo\":\"(.*?)\","))
                .strCd(regExpOperator.apply(htmlContent, "\"strCd\":\"(.*?)\","))
                .ctrtTypCd(regExpOperator.apply(htmlContent, "\"ctrtTypCd\":\"(.*?)\","))
                .slPrc(regExpOperator.apply(htmlContent, "\"slPrc\":(.*?),"))
                .sfcoPdMrgnRt(sfcoPdMrgnRt)
                .sfcoPdLwstMrgnRt(regExpOperator.apply(htmlContent, "\"sfcoPdLwstMrgnRt\":(.*?),"))
                .afflPdMrgnRt(afflPdMrgnRt)
                .brdNo(regExpOperator.apply(htmlContent, "\"brdNo\":\"(.*?)\","))
                .cartDvsCd(regExpOperator.apply(htmlContent, "\"cartDvsCd\":\"(.*?)\","))
                .dvCst(regExpOperator.apply(htmlContent, "\"dvCst\":(.*?),"))
                .scatNo(regExpOperator.apply(htmlContent, "\"scatNo\":\"(.*?)\","))
                .thdyPdYn(regExpOperator.apply(htmlContent, "\"thdyPdYn\":\"(.*?)\","))
                .chNo(regExpOperator.apply(url, "ch_no=(.*?)&"))
                .chDtlNo(regExpOperator.apply(url, "ch_dtl_no=(.*?)&"))
                .aplyStdDttm(now)
                .pcsLwstMrgnRt(regExpOperator.apply(url, "\"pcsLwstMrgnRt\":(.*?),"))
                .fprdDvPdYn(regExpOperator.apply(url, "\"fprdDvPsbYn\":\"(.*?)\","))
                .maxPurQty(regExpOperator.apply(url, "\"maxPurQty\":(.*?),"))
                .build();
    }
}
