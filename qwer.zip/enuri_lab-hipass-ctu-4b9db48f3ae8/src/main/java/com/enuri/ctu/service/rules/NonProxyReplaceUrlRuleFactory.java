package com.enuri.ctu.service.rules;

import com.enuri.ctu.constant.ShopCode;
import com.enuri.ctu.service.rules.shop.coupang.CoupangRule;
import com.enuri.ctu.service.rules.shop.DefaultShopRule;
import com.enuri.ctu.service.rules.shop.ShopRule;
import com.enuri.ctu.service.rules.shop.SsgRule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.EnumMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class NonProxyReplaceUrlRuleFactory {

    private static final Map<ShopCode, ShopRule> RULE_MAP = new EnumMap<>(ShopCode.class);

    private final DefaultShopRule defaultShopRule;

    private final ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        CoupangRule coupangRule = this.applicationContext.getBean(CoupangRule.class);
        SsgRule ssgRule = this.applicationContext.getBean(SsgRule.class);

        // coupang(7861)
        RULE_MAP.put(ShopCode.COUPANG, coupangRule);

        // SSG(6665)
        RULE_MAP.put(ShopCode.SSG, ssgRule);
    }

    public ShopRule getUrlRule(ShopCode shopCode) {
        ShopRule shopRule = RULE_MAP.get(shopCode);
        if (shopRule == null) {
            shopRule = this.defaultShopRule;
        }

        return shopRule;
    }
}
