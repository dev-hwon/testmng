package com.enuri.ctu.util;

import com.enuri.ctu.constant.RequestService;
import com.enuri.ctu.dto.parse.ParsingDataParameter;
import com.enuri.ctu.dto.parse.ParsingPoint;
import org.springframework.util.StringUtils;

public class ParsingUtil {
    private static final int START_MARGIN = 200;
    private static final int END_MARGIN = 500;

    private ParsingUtil() {
        throw new IllegalStateException("util class");
    }

    /**
     * <pre>
     * source: source: com.enuri.common.util.RegExp::getGatheringHtmlData
     * line: 203 ~ 306
     *
     * </pre>
     */
    public static String parseHtmlData(ParsingDataParameter parseParam) {
        String subHtml = CommonUtil.removeCarriageReturn(parseParam.getSourceHtml());

        // startTag ~ endTag 부분만 cut
        String cut = cutByTag(subHtml, parseParam.getStartStr(), parseParam.getEndStr());
        if (!StringUtils.hasText(cut)) {
            return cut;     // return ""
        }

        // cut 에서 regexp 에 해당하는 부분만 extract
        String result = extract(cut, parseParam.getAllStr(), parseParam.getService());
        if (result.length() > 350 || !StringUtils.hasText(result)) {
            return "";
        }

        return exceptByRetType(result, parseParam.getRegExpRetType());
    }

    /**
     * <pre>
     * source: com.enuri.common.util.RegExp::getGatheringHtmlIndex
     * line: 309 ~ 335
     * </pre>
     */
    public static String parseHtmlDataByIndex(ParsingDataParameter parsingDataParameter) {
        String sourceHtml = parsingDataParameter.getSourceHtml();
        if (StringUtils.hasText(sourceHtml)) {
            String html = CommonUtil.removeCarriageReturn(sourceHtml);
            if (html.contains(parsingDataParameter.getAllStr())) {
                return "1";
            }
        }

        return "";
    }

    /**
     * <pre>
     * source: com.enuri.common.util.RegExp::getGatheringHtmlData
     * line: 300 ~ 304
     *
     * regExpReturnType != "3" && (extracted 가 "0" ||  숫자가 아님)
     * </pre>
     */
    public static String exceptByRetType(String extracted, String regExpReturnType) {
        if (!"3".equals(regExpReturnType) &&
                ("0".equals(extracted) || !CommonUtil.isNumeric(extracted))) {
            return "";
        }

        return extracted;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.RegExp::getGatheringHtmlData
     * line: 261 ~ 266
     * 
     * data 추출
     * </pre>
     */
    public static String extract(String subHtml, String allStr, RequestService service) {
        String extractData = RegExpUtils.getRegExpData(subHtml, allStr)
                .replace("<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "")
                .replace("\\p{Space}", "")
                .replace(",", "");

        if (RequestService.SDUL == service) {
            extractData = extractData.replace("'>", "");
        } else {
            extractData = extractData.replace("원", "");
        }

        return extractData;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.RegExp::getGatheringHtmlData
     * line: 235 ~ 245
     *
     * HTML 에서 tag index 부분만큼 cutting
     * </pre>
     */
    public static String cutByTag(String html, String startTag, String endTag) {
        if (!StringUtils.hasText(html)) {
            return html;
        }

        ParsingPoint parsingPoint = getParsingPoint(html, startTag, endTag);
        int startPoint = parsingPoint.getStartPoint();
        int endPoint = parsingPoint.getEndPoint();

        String cutted;
        if (startPoint > 0) {
            try {
                cutted = html.substring(startPoint, endPoint);
            } catch (Exception e) {
                cutted = html.substring(startPoint, startPoint + END_MARGIN);
            }
        } else {
            return "";
        }

        return cutted;
    }

    /**
     * <pre>
     * source: com.enuri.common.util.RegExp::getGatheringHtmlData
     * line: 216 ~ 234
     *
     * HTML 에서 startTag 인덱스와 endTag 인덱스를 추출
     * </pre>
     */
    public static ParsingPoint getParsingPoint(String html, String startTag, String endTag) {
        int startPoint;
        int endPoint;

        int startTagIndex = html.indexOf(startTag);
        if (startTagIndex > START_MARGIN) {
            startPoint = startTagIndex - startTag.length() - START_MARGIN;
        } else {
            startPoint = startTagIndex - startTag.length();
        }

        int endTagIndex = html.indexOf(endTag);
        if (endTagIndex + END_MARGIN >= html.length()) {
            endPoint = endTagIndex + endTag.length();
        } else {
            endPoint = endTagIndex + endTag.length() + END_MARGIN;
        }

        if (startPoint > endPoint) {
            endPoint = html.length();
        }

        return ParsingPoint.builder()
                .startPoint(startPoint)
                .endPoint(endPoint)
                .build();
    }


}
