package com.enuri.ctu.service.crawling.connect.preset;

import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.crawling.CrawlingUnit;
import com.enuri.ctu.exception.CtuException;
import com.enuri.ctu.service.crawling.header.HeaderService;
import com.enuri.ctu.vo.ProxyConnectInfoVO;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.transport.ProxyProvider;

import javax.net.ssl.SSLException;
import java.time.Duration;
import java.time.temporal.ChronoUnit;

@Slf4j
@Component
public class ProxyWebClientPreset extends AbstractWebClientPreset {

    public ProxyWebClientPreset(ConnectionProvider connectionProvider, ExchangeStrategies exchangeStrategies,
                                HeaderService ctuHeaderService) {
        super(connectionProvider, exchangeStrategies, ctuHeaderService);
    }

    /**
     * <pre>
     * Proxy 설정
     * source: com.enuri.common.util.WebConnect::httpsUrlConnectProc
     * line: 826 ~ 848
     * </pre>
     */
    @Override
    public WebClient getWebClient(ProxyConnectInfoVO proxyInfo, CrawlingUnit unit, boolean isHttps) {
        final String eliteProxyCode = "EL";
        final int timeOut = unit.getGatheringInfo().getGtrTimeOut();
        HttpClient httpClient;

        if (eliteProxyCode.equals(proxyInfo.getProxyCompanyCd())) {
            final String id = proxyInfo.getProxyId();
            final String pw = proxyInfo.getProxyPw();
            httpClient = HttpClient.create(this.connectionProvider)
                    .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, DEFAULT_CONNECT_TIMEOUT_MILLS)
                    .responseTimeout(Duration.of(timeOut, ChronoUnit.MILLIS))
                    .httpResponseDecoder(spec -> spec.maxHeaderSize(32 * 1024))
                    .secure(sslContextSpec -> {
                        try {
                            SslContext sslContext = SslContextBuilder
                                    .forClient()
                                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                                    .build();
                            sslContextSpec.sslContext(sslContext);
                        } catch (SSLException e) {
                            log.error("WebClient SSL Error: {}", e.getMessage());
                            throw new CtuException(ResultMessageCode.FAIL, "SSL Context Setting error");
                        }
                    })
                    .proxy(proxy -> proxy.type(ProxyProvider.Proxy.SOCKS5)
                    .host(proxyInfo.getProxyIp())
                    .port(Integer.parseInt(proxyInfo.getProxyPort()))
                    .username(id)
                    .password(u -> pw));
        } else {
            httpClient = HttpClient.create(this.connectionProvider)
                    .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, DEFAULT_CONNECT_TIMEOUT_MILLS)
                    .responseTimeout(Duration.of(timeOut, ChronoUnit.MILLIS))
                    .httpResponseDecoder(spec -> spec.maxHeaderSize(32 * 1024))
                    .secure(sslContextSpec -> {
                        try {
                            SslContext sslContext = SslContextBuilder
                                    .forClient()
                                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                                    .build();
                            sslContextSpec.sslContext(sslContext);
                        } catch (SSLException e) {
                            log.error("WebClient SSL Error: {}", e.getMessage());
                            throw new CtuException(ResultMessageCode.FAIL, "SSL Context Setting error");
                        }
                    })
                    .proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP)
                    .host(proxyInfo.getProxyIp())
                    .port(Integer.parseInt(proxyInfo.getProxyPort()))
            );
        }

        return this.webClientConfig(httpClient, unit);
    }


}
