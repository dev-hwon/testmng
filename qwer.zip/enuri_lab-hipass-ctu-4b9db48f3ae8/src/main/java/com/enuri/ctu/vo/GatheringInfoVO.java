package com.enuri.ctu.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GatheringInfoVO implements Serializable {
    private Long gtrCode;
    private String gtrName;
    private String gtrUrl;
    private int gtrTimeOut;
    private String gtrLang;
    private String ctuDevice;
    private String ctuService;
    private Long shopCode;
    private String gtrUrlRegexp;
}
