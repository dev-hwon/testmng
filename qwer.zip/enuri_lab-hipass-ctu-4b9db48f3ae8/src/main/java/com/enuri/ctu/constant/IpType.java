package com.enuri.ctu.constant;

import com.google.common.collect.ImmutableMap;
import org.springframework.util.StringUtils;

import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

public enum IpType {
    LOCAL,              // L
    DEVELOPMENT,        // D
    PRODUCTION,         // R
    NOT_ALLOWED_IP_TYPE;

    private static final ImmutableMap<String, IpType> IP_TYPE_MAP;

    static {
        final String patternDevelopment = "192.168.213.(172|173|228):8098";
        final String patternProduction = "192.168.213.(172|173|228):8088";
        final String patternLocal =
                "(10.10.10.\\d{1,3}:\\d{2,5})|(100.100.\\d{1,3}.\\d{1,3}:\\d{2,5})|(0:0:0:0:0:0:0:1:\\d{2,5})|(127.0.0.1:\\d{2,5})";
        final String patternDocker = "172.\\d{1,3}.\\d{1,3}.\\d{1,3}:\\d{2,5}";
        final String patternDocker2 = "192.\\d{1,3}.\\d{1,3}.\\d{1,3}:\\d{2,5}";

        IP_TYPE_MAP = ImmutableMap.<String, IpType>builder()
                .put(patternLocal, IpType.LOCAL)
                .put(patternDevelopment, IpType.DEVELOPMENT)
                .put(patternProduction, IpType.PRODUCTION)
                .put(patternDocker, IpType.PRODUCTION)
                .put(patternDocker2, IpType.PRODUCTION)
                .build();
    }

    /**
     * <pre>
     *     original method: com.enuri.common.util.GetIpType::getIpType
     * </pre>
     */
    public static IpType getIpType(String ipWithPort) {
        if (!StringUtils.hasText(ipWithPort)) {
            return IpType.NOT_ALLOWED_IP_TYPE;
        }

        Optional<Map.Entry<String, IpType>> optionalEntry = IP_TYPE_MAP.entrySet().stream()
                .filter(entry -> Pattern.matches(entry.getKey(), ipWithPort))
                .findFirst();

        if (optionalEntry.isPresent()) {
            return optionalEntry.get().getValue();
        }

        return IpType.NOT_ALLOWED_IP_TYPE;
    }

    public static Boolean isLocal(IpType ipType) {
        return LOCAL == ipType;
    }
}
