package com.enuri.ctu.service.crawling.regexp;

import com.enuri.ctu.aop.LoggingProcessTime;
import com.enuri.ctu.constant.IpType;
import com.enuri.ctu.constant.ResultMessageCode;
import com.enuri.ctu.dto.crawling.RegExpObj;
import com.enuri.ctu.dto.crawling.RegExpParameter;
import com.enuri.ctu.dto.crawling.ShopJob;
import com.enuri.ctu.exception.CtuDataNotFoundException;
import com.enuri.ctu.vo.CtuRegExpVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * source: com.enuri.common.util.WebSpider::getProxyWebSpiderContent
 * line: 272 ~ 307
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class HomePageDbRegExpService implements DbRegExpService {

    private final RegExpDataHandler regExpDataHandler;

    @Override
    @LoggingProcessTime
    public RegExpObj fetchRegExpList(RegExpParameter param) {
        // shopJob
        ShopJob shopJobData = this.regExpDataHandler.getShopJobData(param.getShopCode(), param.isSmartStore());
        log.info("ShopJobData SHOP_CODE[{}]: {}", param.getShopCode(), shopJobData.toString());
        // line: 280
        if (Boolean.TRUE.equals(IpType.isLocal(param.getIpType()))) {
            shopJobData.localTestSetting();
        }

        // 모두 N일때 INTENDED_FAIL 리턴
        // line: 288 ~ 292
        if (!shopJobData.isAvailable()) {
            log.error("shopJobData Not Found shopCode: {}", param.getShopCode());
            throw new CtuDataNotFoundException(ResultMessageCode.INTENDED_FAIL);
        }

        List<CtuRegExpVO> ctuRegExpList = this.regExpDataHandler.getCtuRegExpList(param, shopJobData.getMobileYn());
        log.info("CTU REG_EXP size : {}", ctuRegExpList.size());

        return new RegExpObj(ctuRegExpList, shopJobData);
    }

}
